# Lavalink setup
1. Install Java 17+ and download Lavalink v4 from https://github.com/lavalink-devs/Lavalink/releases
2. Copy `application.yml` next to `Lavalink.jar`, set the password, and set the youtube-source plugin version
   (https://github.com/lavalink-devs/youtube-source).
3. Start it: `java -jar Lavalink.jar`
4. In the bot's `.env`: `LAVALINK_HOST=127.0.0.1`, `LAVALINK_PORT=2333`, `LAVALINK_PASSWORD=<same password>`.

YouTube playback breaks from time to time (YouTube changes things). Keep the plugin updated; SoundCloud and direct links keep working.
Never reuse a Lavalink password from someone else's `.env`.
