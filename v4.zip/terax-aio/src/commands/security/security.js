import { PermissionFlagsBits as P } from 'discord.js';
import { db } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { secCfg, raid, isTrusted } from '../../core/security.js';
import { isOwner } from '../../core/config.js';
import { getMember, getRole, getChannel, clip, idOf } from '../../core/util.js';

const S = { category: 'security', cooldown: 3 };
const ADMIN = { ...S, perms: [P.ManageGuild] };
const PUNISH = ['delete', 'warn', 'timeout', 'kick'];
const sup = (g, col, v) => { secCfg(g); db.prepare(`UPDATE sec_cfg SET ${col}=? WHERE guild=?`).run(v, g); };
const ownerOnly = (run) => async (ctx) => {
  const m = ctx.message; if (m.author.id !== m.guild.ownerId && !isOwner(m.author.id) && !db.prepare('SELECT 1 FROM extraowners WHERE guild=? AND user=?').get(m.guild.id, m.author.id)) return m.reply(fail('Owner only', 'Only the server owner or an extra owner can change this.'));
  return run(ctx);
};
const rule = (name, desc, { val = null, valHint = '' } = {}) => ({ ...ADMIN, name, description: desc, usage: `${name} <on|off> [${PUNISH.join('|')}]${valHint}`, async run({ message, args, prefix, cmd }) {
  if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
  const punish = PUNISH.includes(args[1]) ? args[1] : 'delete', v = val && /^\d+$/.test(args[2] ?? '') ? args[2] : null;
  db.prepare('INSERT INTO am(guild,rule,enabled,punish,val) VALUES (?,?,?,?,?) ON CONFLICT(guild,rule) DO UPDATE SET enabled=excluded.enabled, punish=excluded.punish, val=COALESCE(excluded.val, am.val)').run(message.guild.id, name, args[0] === 'on' ? 1 : 0, punish, v);
  return message.reply(ok(name, `${args[0] === 'on' ? `Enabled • action: **${punish}**${v ? ` • limit: ${v}` : ''}` : 'Disabled'}`));
} });
const logSetter = (name) => ({ ...ADMIN, name, description: 'Set the security/automod log channel', usage: `${name} <#channel|off>`, async run({ message, args, prefix, cmd }) {
  const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix));
  sup(message.guild.id, 'log_channel', c?.id ?? null); return message.reply(ok('Security log', c ? `<#${c.id}>` : 'Disabled'));
} });

export default [
  { ...ADMIN, name: 'automod', description: 'Show automod and security status', usage: 'automod', async run({ message }) {
    const r = db.prepare('SELECT * FROM am WHERE guild=?').all(message.guild.id), c = secCfg(message.guild.id);
    return message.reply(card({ title: '🛡️ Automod & security', body: [...r.map((x) => `${x.enabled ? '🟢' : '⚫'} **${x.rule}** → ${x.punish}${x.val ? ` (${x.val})` : ''}`), '', `${c.nuke_on ? '🟢' : '⚫'} **antinuke** (limit ${c.nuke_limit}/30s)`, `${c.raid_on ? '🟢' : '⚫'} **antiraid** (${c.raid_limit} joins/10s)`, `${c.alt_days ? '🟢' : '⚫'} **antialt** (${c.alt_days || 'off'} days)`, `${c.antibot ? '🟢' : '⚫'} **antibot**`, `Log: ${c.log_channel ? `<#${c.log_channel}>` : 'not set'}`].join('\n') }));
  } },
  rule('antispam', 'Block message spam', { val: true, valHint: ' [msgs per 5s]' }),
  rule('antilink', 'Block links (see linkwhitelist)'),
  rule('antiinvite', 'Block Discord invites'),
  rule('antiswear', 'Block words from the wordlist'),
  rule('antiemoji', 'Block emoji spam', { val: true, valHint: ' [max emojis]' }),
  rule('anticaps', 'Block excessive capital letters'),
  rule('antimention', 'Block mass mentions', { val: true, valHint: ' [max mentions]' }),
  rule('antizalgo', 'Block zalgo/glitch text'),
  rule('antiphish', 'Block known scam / fake-Nitro patterns (best effort)'),
  { ...ADMIN, name: 'blacklistword', aliases: ['addword'], description: 'Add a blocked word', usage: 'blacklistword <word>', async run({ message, args, prefix, cmd }) {
    const w = args.join(' ').toLowerCase().trim(); if (!w || w.length > 40) return message.reply(usage(cmd, prefix));
    db.prepare('INSERT OR IGNORE INTO am_words VALUES (?,?)').run(message.guild.id, w); await message.delete().catch(() => {}); return message.channel.send(ok('Word added', 'Message deleted to keep the word private. Enable with `antiswear on`.'));
  } },
  { ...ADMIN, name: 'unblacklistword', aliases: ['delword'], description: 'Remove a blocked word', usage: 'unblacklistword <word>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM am_words WHERE guild=? AND word=?').run(message.guild.id, args.join(' ').toLowerCase().trim()); return message.reply(r.changes ? ok('Word removed') : fail('Not in the list'));
  } },
  { ...ADMIN, name: 'wordlist', description: 'Count of blocked words (list is hidden)', usage: 'wordlist', async run({ message }) {
    const n = db.prepare('SELECT COUNT(*) c FROM am_words WHERE guild=?').get(message.guild.id).c; return message.reply(card({ title: '🤬 Word list', body: `${n} blocked word(s). They are not displayed.` }));
  } },
  { ...ADMIN, name: 'linkwhitelist', aliases: ['lwl'], description: 'Allow domains when antilink is on', usage: 'linkwhitelist <add|remove|list> [domain]', async run({ message, args, prefix, cmd }) {
    const d = (args[1] ?? '').toLowerCase().replace(/^https?:\/\//, '').split('/')[0];
    if (args[0] === 'add' && d) { db.prepare('INSERT OR IGNORE INTO am_links VALUES (?,?)').run(message.guild.id, d); return message.reply(ok('Domain allowed', d)); }
    if (args[0] === 'remove' && d) { db.prepare('DELETE FROM am_links WHERE guild=? AND domain=?').run(message.guild.id, d); return message.reply(ok('Domain removed', d)); }
    if (args[0] === 'list') return message.reply(card({ title: '🔗 Allowed domains', body: db.prepare('SELECT domain FROM am_links WHERE guild=?').all(message.guild.id).map((x) => x.domain).join('\n') || 'None' }));
    return message.reply(usage(cmd, prefix));
  } },
  { ...ADMIN, name: 'punishment', description: 'Change the action of an automod rule', usage: `punishment <rule> <${PUNISH.join('|')}>`, async run({ message, args, prefix, cmd }) {
    if (!PUNISH.includes(args[1])) return message.reply(usage(cmd, prefix));
    const r = db.prepare('UPDATE am SET punish=? WHERE guild=? AND rule=?').run(args[1], message.guild.id, args[0]); return message.reply(r.changes ? ok('Punishment updated', `${args[0]} → ${args[1]}`) : fail('Unknown rule', 'Enable the rule first.'));
  } },
  logSetter('automodlog'), logSetter('antinukelog'),
  { ...ADMIN, name: 'whitelist', aliases: ['wl'], description: 'Exempt a user/role from automod and antinuke', usage: 'whitelist <@user|@role>', async run({ message, args, prefix, cmd }) {
    const t = (await getMember(message, args[0])) ?? getRole(message, args.join(' ')); if (!t) return message.reply(usage(cmd, prefix));
    db.prepare('INSERT OR IGNORE INTO wl VALUES (?,?)').run(message.guild.id, t.id); return message.reply(ok('Whitelisted', t.user?.username ?? t.name));
  } },
  { ...ADMIN, name: 'unwhitelist', aliases: ['uwl'], description: 'Remove a whitelist entry', usage: 'unwhitelist <@user|@role>', async run({ message, args, prefix, cmd }) {
    const id = idOf(args[0]) || ''; if (!id) return message.reply(usage(cmd, prefix));
    const r = db.prepare('DELETE FROM wl WHERE guild=? AND id=?').run(message.guild.id, (getRole(message, args.join(' '))?.id) ?? id); return message.reply(r.changes ? ok('Removed from whitelist') : fail('Not whitelisted'));
  } },
  { ...ADMIN, name: 'whitelisted', description: 'Show whitelisted users/roles', usage: 'whitelisted', async run({ message }) {
    const r = db.prepare('SELECT id FROM wl WHERE guild=?').all(message.guild.id); return message.reply(card({ title: '✅ Whitelist', body: r.map((x) => (message.guild.roles.cache.has(x.id) ? `<@&${x.id}>` : `<@${x.id}>`)).join('\n') || 'Empty' }));
  } },
  { ...S, name: 'extraowner', description: 'Trusted extra owners for security (server owner only)', usage: 'extraowner <add|remove|list> [@user]', async run(ctx) {
    return ownerOnly(async ({ message, args, prefix, cmd }) => {
      const t = await getMember(message, args[1]);
      if (args[0] === 'add' && t) { db.prepare('INSERT OR IGNORE INTO extraowners VALUES (?,?)').run(message.guild.id, t.id); return message.reply(ok('Extra owner added', t.user.username)); }
      if (args[0] === 'remove' && t) { db.prepare('DELETE FROM extraowners WHERE guild=? AND user=?').run(message.guild.id, t.id); return message.reply(ok('Extra owner removed', t.user.username)); }
      if (args[0] === 'list') return message.reply(card({ title: '👑 Extra owners', body: db.prepare('SELECT user FROM extraowners WHERE guild=?').all(message.guild.id).map((x) => `<@${x.user}>`).join('\n') || 'None' }));
      return message.reply(usage(cmd, prefix));
    })(ctx);
  } },
  { ...S, name: 'antinuke', description: 'Punish mass channel/role/ban/kick actions (owner only)', usage: 'antinuke <on|off> [limit 2-10]', botPerms: [P.BanMembers, P.ViewAuditLog, P.ManageRoles],
    async run(ctx) { return ownerOnly(async ({ message, args, prefix, cmd }) => {
      if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix)); const l = parseInt(args[1]);
      sup(message.guild.id, 'nuke_on', args[0] === 'on' ? 1 : 0); if (l >= 2 && l <= 10) sup(message.guild.id, 'nuke_limit', l);
      return message.reply(ok('Antinuke', args[0] === 'on' ? `Enabled • triggers at ${secCfg(message.guild.id).nuke_limit} actions in 30s. Keep my role above everyone else's.` : 'Disabled'));
    })(ctx); } },
  { ...ADMIN, name: 'antiraid', description: 'Auto-lockdown on join spikes', usage: 'antiraid <on|off> [joins per 10s, 3-30]', botPerms: [P.KickMembers], async run({ message, args, prefix, cmd }) {
    if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix)); const l = parseInt(args[1]); sup(message.guild.id, 'raid_on', args[0] === 'on' ? 1 : 0); if (l >= 3 && l <= 30) sup(message.guild.id, 'raid_limit', l);
    return message.reply(ok('Antiraid', args[0] === 'on' ? `Enabled • ${secCfg(message.guild.id).raid_limit} joins/10s triggers a 10-minute lockdown.` : 'Disabled'));
  } },
  { ...ADMIN, name: 'raidstatus', description: 'Is a raid lockdown active?', usage: 'raidstatus', async run({ message, args }) {
    if (args[0] === 'end') { raid.delete(message.guild.id); return message.reply(ok('Lockdown ended')); }
    const u = raid.get(message.guild.id), on = u > Date.now(); return message.reply(card({ title: on ? '🚨 Lockdown active' : '🟢 No raid', color: on ? 'error' : 'success', body: on ? `Ends <t:${Math.floor(u / 1000)}:R>. End it early with \`raidstatus end\`.` : 'Everything is normal.' }));
  } },
  { ...ADMIN, name: 'antialt', description: 'Kick accounts younger than N days', usage: 'antialt <days|off>', botPerms: [P.KickMembers], async run({ message, args, prefix, cmd }) {
    const d = args[0] === 'off' ? 0 : parseInt(args[0]); if (isNaN(d) || d < 0 || d > 90) return message.reply(usage(cmd, prefix)); sup(message.guild.id, 'alt_days', d); return message.reply(ok('Antialt', d ? `Accounts under ${d} days old are kicked.` : 'Disabled'));
  } },
  { ...ADMIN, name: 'antibot', description: 'Remove bots added by untrusted users', usage: 'antibot <on|off>', botPerms: [P.KickMembers, P.ViewAuditLog], async run({ message, args, prefix, cmd }) {
    if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix)); sup(message.guild.id, 'antibot', args[0] === 'on' ? 1 : 0); return message.reply(ok('Antibot', args[0]));
  } },
];
