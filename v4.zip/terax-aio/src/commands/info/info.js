import { config, isOwner } from '../../core/config.js';
import { db } from '../../core/db.js';
import { card, fail, ok } from '../../core/ui.js';
import { clip, fmtDuration, getMember, getChannel, getRole, ts, idOf } from '../../core/util.js';
import { helpHome, helpCategory, categories } from '../../core/help.js';

const I = { category: 'info' };
export default [
  { ...I, name: 'help', aliases: ['h', 'commands'], description: 'Show the command list', usage: 'help [command|category]',
    async run({ client, message, args, prefix }) {
      const q = args[0]?.toLowerCase(), own = isOwner(message.author.id);
      if (!q) return message.reply(helpHome(client, prefix, own));
      const cmd = client.commands.get(q) ?? client.commands.get(client.aliases.get(q));
      if (cmd && (cmd.category !== 'owner' || own)) {
        return message.reply(card({ title: `📖 ${prefix}${cmd.name}`, body: cmd.description, fields: [
          ['Usage', `\`${prefix}${cmd.usage || cmd.name}\``], ['Aliases', cmd.aliases?.map((a) => `\`${a}\``).join(', ') || 'None'],
          ['Category', cmd.category], ['Cooldown', `${cmd.cooldown ?? 3}s`]] }));
      }
      if (categories(client, own)[q]) return message.reply(helpCategory(client, q, prefix, own));
      return message.reply(fail('Not found', `No command or category called \`${q}\`.`));
    } },
  { ...I, name: 'ping', description: 'Bot latency', usage: 'ping',
    async run({ client, message }) {
      const t = Date.now(); const m = await message.reply(card({ title: '🏓 Pinging…' }));
      return m.edit(card({ title: '🏓 Pong', fields: [['API', `${client.ws.ping}ms`], ['Roundtrip', `${Date.now() - t}ms`]] }));
    } },
  { ...I, name: 'uptime', description: 'How long the bot has been online', usage: 'uptime',
    async run({ client, message }) { return message.reply(card({ title: '⏱️ Uptime', body: fmtDuration(Date.now() - client.startedAt) })); } },
  { ...I, name: 'botinfo', aliases: ['bi', 'about'], description: 'About this bot', usage: 'botinfo',
    async run({ client, message }) {
      return message.reply(card({ title: `🤖 ${config.branding.botName}`, thumb: client.user.displayAvatarURL({ size: 256 }), fields: [
        ['Owner', config.branding.owner], ['Lead Dev', config.branding.leadDev], ['Commands', client.commands.size],
        ['Library', 'discord.js v14'], ['Ping', `${client.ws.ping}ms`], ['Uptime', fmtDuration(Date.now() - client.startedAt)]] }));
    } },
  { ...I, name: 'userinfo', aliases: ['ui', 'user'], description: 'Information about a user', usage: 'userinfo [@user]',
    async run({ message, args }) {
      const m = (await getMember(message, args[0])) ?? message.member, u = m.user;
      const roles = m.roles.cache.filter((r) => r.id !== message.guild.id).sort((a, b) => b.position - a.position).map((r) => `<@&${r.id}>`);
      return message.reply(card({ title: `👤 ${u.username}`, thumb: m.displayAvatarURL({ size: 256 }), fields: [
        ['ID', u.id], ['Nickname', m.nickname ?? 'None'], ['Created', ts(u.createdTimestamp)], ['Joined', ts(m.joinedTimestamp)],
        ['Bot', u.bot ? 'Yes' : 'No'], [`Roles (${roles.length})`, clip(roles.slice(0, 12).join(' ') || 'None', 400)]] }));
    } },
  { ...I, name: 'serverinfo', aliases: ['si', 'guildinfo'], description: 'Information about this server', usage: 'serverinfo',
    async run({ message }) {
      const g = message.guild;
      return message.reply(card({ title: `🏠 ${g.name}`, thumb: g.iconURL({ size: 256 }) ?? undefined, fields: [
        ['ID', g.id], ['Owner', `<@${g.ownerId}>`], ['Members', g.memberCount], ['Channels', g.channels.cache.size], ['Roles', g.roles.cache.size],
        ['Boosts', `${g.premiumSubscriptionCount ?? 0} (tier ${g.premiumTier})`], ['Created', ts(g.createdTimestamp)]] }));
    } },
  { ...I, name: 'avatar', aliases: ['av', 'pfp'], description: 'Show a user avatar', usage: 'avatar [@user]',
    async run({ message, args }) {
      const m = (await getMember(message, args[0])) ?? message.member;
      return message.reply(card({ title: `🖼️ ${m.user.username}`, body: `[Open full size](${m.displayAvatarURL({ size: 1024 })})`, thumb: m.displayAvatarURL({ size: 512 }) }));
    } },
  { ...I, name: 'banner', description: 'Show a user banner', usage: 'banner [@user]',
    async run({ message, args }) {
      const m = (await getMember(message, args[0])) ?? message.member, u = await m.user.fetch(true);
      const url = u.bannerURL({ size: 1024 });
      return message.reply(url ? card({ title: `🎨 ${u.username}'s banner`, body: `[Open full size](${url})`, thumb: url }) : fail('No banner', 'That user has no banner.'));
    } },
  { ...I, name: 'servericon', aliases: ['sicon'], description: 'Show the server icon', usage: 'servericon',
    async run({ message }) {
      const url = message.guild.iconURL({ size: 1024 });
      return message.reply(url ? card({ title: `🏠 ${message.guild.name}`, body: `[Open full size](${url})`, thumb: url }) : fail('No icon', 'This server has no icon.'));
    } },
  { ...I, name: 'roleinfo', aliases: ['ri'], description: 'Information about a role', usage: 'roleinfo <@role|name>',
    async run({ message, args }) {
      const r = getRole(message, args.join(' '));
      if (!r) return message.reply(fail('Not found', 'Mention a role, or give its ID or exact name.'));
      return message.reply(card({ title: `🏷️ ${r.name}`, fields: [['ID', r.id], ['Color', r.hexColor], ['Members', r.members.size], ['Position', r.position],
        ['Hoisted', r.hoist ? 'Yes' : 'No'], ['Mentionable', r.mentionable ? 'Yes' : 'No'], ['Created', ts(r.createdTimestamp)]] }));
    } },
  { ...I, name: 'channelinfo', aliases: ['ci'], description: 'Information about a channel', usage: 'channelinfo [#channel]',
    async run({ message, args }) {
      const c = getChannel(message, args[0]) ?? message.channel;
      return message.reply(card({ title: `#️⃣ ${c.name}`, fields: [['ID', c.id], ['Type', c.type], ['Created', ts(c.createdTimestamp)], ['Topic', clip(c.topic ?? 'None', 200)], ['Slowmode', `${c.rateLimitPerUser ?? 0}s`]] }));
    } },
  { ...I, name: 'membercount', aliases: ['mc'], description: 'Member count', usage: 'membercount',
    async run({ message }) { return message.reply(card({ title: '👥 Members', body: `**${message.guild.memberCount}** members` })); } },
  { ...I, name: 'prefix', description: 'Show the current prefix', usage: 'prefix',
    async run({ message, prefix }) { return message.reply(card({ title: '🔧 Prefix', body: `The prefix here is \`${prefix}\`` })); } },
  { ...I, name: 'afk', description: 'Set an AFK status', usage: 'afk [reason]',
    async run({ message, args }) {
      const reason = clip(args.join(' ') || 'AFK', 150);
      db.prepare('INSERT OR REPLACE INTO afk(guild,user,reason,at) VALUES (?,?,?,?)').run(message.guild.id, message.author.id, reason, Date.now());
      return message.reply(ok('You are now AFK', reason));
    } },
  { ...I, name: 'snowflake', aliases: ['sf'], description: 'Get the creation date of a Discord ID', usage: 'snowflake <id>',
    async run({ message, args }) {
      const id = idOf(args[0]);
      if (!/^\d{15,22}$/.test(id)) return message.reply(fail('Invalid ID', 'Give a valid Discord ID.'));
      const t = Number((BigInt(id) >> 22n) + 1420070400000n);
      return message.reply(card({ title: '❄️ Snowflake', fields: [['ID', id], ['Created', `${ts(t, 'F')} (${ts(t)})`]] }));
    } },
];
