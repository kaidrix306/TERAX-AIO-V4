import { PermissionFlagsBits as P } from 'discord.js';
import { db, getGuild, addCase } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { tryDM } from '../../core/dm.js';
import { clip, parseDuration, fmtDuration, getMember, getUser, getRole, getChannel, ts, idOf } from '../../core/util.js';

const M = { category: 'moderation' };
const reasonOf = (a) => clip(a.join(' ') || 'No reason given', 400);

function block(message, target) {
  if (target.id === message.author.id) return 'You cannot do that to yourself.';
  if (target.id === message.client.user.id) return 'Nice try.';
  if (target.id === message.guild.ownerId) return 'You cannot target the server owner.';
  if (message.author.id !== message.guild.ownerId && target.roles.highest.position >= message.member.roles.highest.position) return 'That member is above or equal to your top role.';
  return null;
}
// DM notice policy: only if the server allows it, and the chat reply always says what happened.
async function notify(message, user, title, reason) {
  if (!getGuild(message.guild.id).dm_notices) return 'DM notices are off';
  return (await tryDM(user, card({ title, body: `Server: **${message.guild.name}**\nReason: ${reason}`, color: 'mod' }))) ? 'user notified by DM' : 'user has DMs closed';
}
async function finish(message, type, user, reason, note) {
  const id = addCase(message.guild.id, user.id, message.author.id, type, reason);
  const ch = getGuild(message.guild.id).log_channel;
  const log = ch && message.guild.channels.cache.get(ch);
  if (log?.isTextBased()) log.send(card({ title: `🛡️ ${type} • Case #${id}`, color: 'mod', fields: [['User', `<@${user.id}> (${user.id})`], ['Moderator', `<@${message.author.id}>`], ['Reason', reason]] })).catch(() => {});
  return message.reply(ok(`${type} • Case #${id}`, `**${user.username ?? user.user?.username}** — ${reason}${note ? `\n-# ${note}` : ''}`));
}
const needTarget = (message, args, prefix, cmd) => !args[0] && message.reply(usage(cmd, prefix));

export default [
  { ...M, name: 'ban', aliases: ['b'], description: 'Ban a member or user ID', usage: 'ban <user> [reason]', perms: [P.BanMembers], botPerms: [P.BanMembers],
    async run({ client, message, args, prefix, cmd }) {
      if (await needTarget(message, args, prefix, cmd)) return;
      const m = await getMember(message, args[0]), user = m?.user ?? await getUser(client, args[0]);
      if (!user) return message.reply(fail('Not found', 'I could not find that user.'));
      if (m) { const b = block(message, m); if (b) return message.reply(fail('Cannot ban', b)); if (!m.bannable) return message.reply(fail('Cannot ban', 'My role is too low for that member.')); }
      const reason = reasonOf(args.slice(1)), note = m ? await notify(message, user, '🔨 You were banned', reason) : null;
      await message.guild.members.ban(user.id, { reason: `${message.author.tag}: ${reason}` });
      return finish(message, 'Ban', user, reason, note);
    } },
  { ...M, name: 'unban', description: 'Unban a user by ID', usage: 'unban <id> [reason]', perms: [P.BanMembers], botPerms: [P.BanMembers],
    async run({ message, args, prefix, cmd }) {
      if (await needTarget(message, args, prefix, cmd)) return;
      const id = idOf(args[0]), ban = await message.guild.bans.fetch(id).catch(() => null);
      if (!ban) return message.reply(fail('Not banned', 'That user is not banned.'));
      const reason = reasonOf(args.slice(1));
      await message.guild.members.unban(id, `${message.author.tag}: ${reason}`);
      return finish(message, 'Unban', ban.user, reason);
    } },
  { ...M, name: 'kick', aliases: ['k'], description: 'Kick a member', usage: 'kick <member> [reason]', perms: [P.KickMembers], botPerms: [P.KickMembers],
    async run({ message, args, prefix, cmd }) {
      if (await needTarget(message, args, prefix, cmd)) return;
      const m = await getMember(message, args[0]);
      if (!m) return message.reply(fail('Not found', 'Member not found in this server.'));
      const b = block(message, m); if (b) return message.reply(fail('Cannot kick', b));
      if (!m.kickable) return message.reply(fail('Cannot kick', 'My role is too low for that member.'));
      const reason = reasonOf(args.slice(1)), note = await notify(message, m.user, '👢 You were kicked', reason);
      await m.kick(`${message.author.tag}: ${reason}`);
      return finish(message, 'Kick', m.user, reason, note);
    } },
  { ...M, name: 'softban', description: 'Ban then unban to delete a member\'s recent messages', usage: 'softban <member> [reason]', perms: [P.BanMembers], botPerms: [P.BanMembers],
    async run({ message, args, prefix, cmd }) {
      if (await needTarget(message, args, prefix, cmd)) return;
      const m = await getMember(message, args[0]);
      if (!m) return message.reply(fail('Not found', 'Member not found in this server.'));
      const b = block(message, m); if (b) return message.reply(fail('Cannot softban', b));
      if (!m.bannable) return message.reply(fail('Cannot softban', 'My role is too low for that member.'));
      const reason = reasonOf(args.slice(1)), note = await notify(message, m.user, '🧹 You were softbanned', reason);
      await message.guild.members.ban(m.id, { deleteMessageSeconds: 86400, reason: `Softban by ${message.author.tag}: ${reason}` });
      await message.guild.members.unban(m.id, 'Softban').catch(() => {});
      return finish(message, 'Softban', m.user, reason, note);
    } },
  { ...M, name: 'timeout', aliases: ['mute', 'to'], description: 'Timeout a member (max 28d)', usage: 'timeout <member> <10m|2h|1d> [reason]', perms: [P.ModerateMembers], botPerms: [P.ModerateMembers],
    async run({ message, args, prefix, cmd }) {
      const m = await getMember(message, args[0]), ms = parseDuration(args[1]);
      if (!m || !ms) return message.reply(usage(cmd, prefix));
      if (ms > 2419200000) return message.reply(fail('Too long', 'Maximum timeout is 28 days.'));
      const b = block(message, m); if (b) return message.reply(fail('Cannot timeout', b));
      if (!m.moderatable) return message.reply(fail('Cannot timeout', 'My role is too low for that member.'));
      const reason = reasonOf(args.slice(2)), note = await notify(message, m.user, `🔇 You were timed out (${fmtDuration(ms)})`, reason);
      await m.timeout(ms, `${message.author.tag}: ${reason}`);
      return finish(message, 'Timeout', m.user, `${reason} (${fmtDuration(ms)})`, note);
    } },
  { ...M, name: 'untimeout', aliases: ['unmute'], description: 'Remove a timeout', usage: 'untimeout <member>', perms: [P.ModerateMembers], botPerms: [P.ModerateMembers],
    async run({ message, args, prefix, cmd }) {
      const m = await getMember(message, args[0]);
      if (!m) return message.reply(usage(cmd, prefix));
      await m.timeout(null); return finish(message, 'Untimeout', m.user, reasonOf(args.slice(1)));
    } },
  { ...M, name: 'warn', description: 'Warn a member', usage: 'warn <member> <reason>', perms: [P.ModerateMembers],
    async run({ message, args, prefix, cmd }) {
      const m = await getMember(message, args[0]);
      if (!m || args.length < 2) return message.reply(usage(cmd, prefix));
      const b = block(message, m); if (b) return message.reply(fail('Cannot warn', b));
      const reason = reasonOf(args.slice(1)), note = await notify(message, m.user, '⚠️ You were warned', reason);
      const total = db.prepare("SELECT COUNT(*) c FROM cases WHERE guild=? AND user=? AND type='Warn'").get(message.guild.id, m.id).c + 1;
      return finish(message, 'Warn', m.user, reason, `${total} warning(s) total • ${note}`);
    } },
  { ...M, name: 'warnings', aliases: ['warns'], description: 'List warnings for a member', usage: 'warnings <user>', perms: [P.ModerateMembers],
    async run({ client, message, args, prefix, cmd }) {
      const u = (await getMember(message, args[0]))?.user ?? await getUser(client, args[0]);
      if (!u) return message.reply(usage(cmd, prefix));
      const rows = db.prepare("SELECT * FROM cases WHERE guild=? AND user=? AND type='Warn' ORDER BY id DESC LIMIT 15").all(message.guild.id, u.id);
      return message.reply(card({ title: `⚠️ Warnings • ${u.username}`, color: 'mod', body: rows.map((r) => `**#${r.id}** ${ts(r.at, 'd')} — ${clip(r.reason, 80)}`).join('\n') || 'No warnings.' }));
    } },
  { ...M, name: 'delwarn', description: 'Delete one warning by case ID', usage: 'delwarn <caseId>', perms: [P.ModerateMembers],
    async run({ message, args, prefix, cmd }) {
      if (!/^\d+$/.test(args[0] ?? '')) return message.reply(usage(cmd, prefix));
      const r = db.prepare("DELETE FROM cases WHERE id=? AND guild=? AND type='Warn'").run(args[0], message.guild.id);
      return message.reply(r.changes ? ok('Warning deleted', `Case #${args[0]}`) : fail('Not found', 'No warning with that case ID.'));
    } },
  { ...M, name: 'clearwarnings', aliases: ['clearwarns'], description: 'Clear all warnings for a member', usage: 'clearwarnings <user>', perms: [P.ModerateMembers],
    async run({ client, message, args, prefix, cmd }) {
      const u = (await getMember(message, args[0]))?.user ?? await getUser(client, args[0]);
      if (!u) return message.reply(usage(cmd, prefix));
      const r = db.prepare("DELETE FROM cases WHERE guild=? AND user=? AND type='Warn'").run(message.guild.id, u.id);
      return message.reply(ok('Warnings cleared', `${r.changes} removed for ${u.username}.`));
    } },
  { ...M, name: 'purge', aliases: ['clear', 'prune'], description: 'Delete 1-100 recent messages', usage: 'purge <1-100>', perms: [P.ManageMessages], botPerms: [P.ManageMessages],
    async run({ message, args, prefix, cmd }) {
      const n = parseInt(args[0], 10);
      if (!n || n < 1 || n > 100) return message.reply(usage(cmd, prefix));
      await message.delete().catch(() => {});
      const del = await message.channel.bulkDelete(n, true);
      const m = await message.channel.send(ok('Purged', `${del.size} message(s) deleted.`));
      setTimeout(() => m.delete().catch(() => {}), 4000);
    } },
  { ...M, name: 'slowmode', aliases: ['sm'], description: 'Set channel slowmode (0 = off)', usage: 'slowmode <seconds>', perms: [P.ManageChannels], botPerms: [P.ManageChannels],
    async run({ message, args, prefix, cmd }) {
      const s = parseInt(args[0], 10);
      if (isNaN(s) || s < 0 || s > 21600) return message.reply(usage(cmd, prefix));
      await message.channel.setRateLimitPerUser(s); return message.reply(ok('Slowmode', s ? `${s}s` : 'Disabled'));
    } },
  { ...M, name: 'lock', description: 'Lock a channel for @everyone', usage: 'lock [#channel]', perms: [P.ManageChannels], botPerms: [P.ManageChannels],
    async run({ message, args }) {
      const c = getChannel(message, args[0]) ?? message.channel;
      await c.permissionOverwrites.edit(message.guild.id, { SendMessages: false }); return message.reply(ok('Locked', `<#${c.id}>`));
    } },
  { ...M, name: 'unlock', description: 'Unlock a channel', usage: 'unlock [#channel]', perms: [P.ManageChannels], botPerms: [P.ManageChannels],
    async run({ message, args }) {
      const c = getChannel(message, args[0]) ?? message.channel;
      await c.permissionOverwrites.edit(message.guild.id, { SendMessages: null }); return message.reply(ok('Unlocked', `<#${c.id}>`));
    } },
  { ...M, name: 'hide', description: 'Hide a channel from @everyone', usage: 'hide [#channel]', perms: [P.ManageChannels], botPerms: [P.ManageChannels],
    async run({ message, args }) {
      const c = getChannel(message, args[0]) ?? message.channel;
      await c.permissionOverwrites.edit(message.guild.id, { ViewChannel: false }); return message.reply(ok('Hidden', `#${c.name}`));
    } },
  { ...M, name: 'unhide', description: 'Unhide a channel', usage: 'unhide [#channel]', perms: [P.ManageChannels], botPerms: [P.ManageChannels],
    async run({ message, args }) {
      const c = getChannel(message, args[0]) ?? message.channel;
      await c.permissionOverwrites.edit(message.guild.id, { ViewChannel: null }); return message.reply(ok('Visible again', `<#${c.id}>`));
    } },
  { ...M, name: 'addrole', aliases: ['ar'], description: 'Give a role to a member', usage: 'addrole <member> <role>', perms: [P.ManageRoles], botPerms: [P.ManageRoles],
    async run({ message, args, prefix, cmd }) {
      const m = await getMember(message, args[0]), r = getRole(message, args.slice(1).join(' '));
      if (!m || !r) return message.reply(usage(cmd, prefix));
      if (message.author.id !== message.guild.ownerId && r.position >= message.member.roles.highest.position) return message.reply(fail('Cannot', 'That role is above your top role.'));
      if (!r.editable) return message.reply(fail('Cannot', 'My role is too low to manage that role.'));
      await m.roles.add(r); return message.reply(ok('Role added', `${r.name} → ${m.user.username}`));
    } },
  { ...M, name: 'removerole', aliases: ['rr'], description: 'Remove a role from a member', usage: 'removerole <member> <role>', perms: [P.ManageRoles], botPerms: [P.ManageRoles],
    async run({ message, args, prefix, cmd }) {
      const m = await getMember(message, args[0]), r = getRole(message, args.slice(1).join(' '));
      if (!m || !r) return message.reply(usage(cmd, prefix));
      if (message.author.id !== message.guild.ownerId && r.position >= message.member.roles.highest.position) return message.reply(fail('Cannot', 'That role is above your top role.'));
      if (!r.editable) return message.reply(fail('Cannot', 'My role is too low to manage that role.'));
      await m.roles.remove(r); return message.reply(ok('Role removed', `${r.name} ← ${m.user.username}`));
    } },
  { ...M, name: 'setnick', aliases: ['nick'], description: 'Change a member nickname (empty resets)', usage: 'setnick <member> [nickname]', perms: [P.ManageNicknames], botPerms: [P.ManageNicknames],
    async run({ message, args, prefix, cmd }) {
      const m = await getMember(message, args[0]);
      if (!m) return message.reply(usage(cmd, prefix));
      const b = block(message, m); if (b && m.id !== message.author.id) return message.reply(fail('Cannot', b));
      await m.setNickname(args.slice(1).join(' ') || null); return message.reply(ok('Nickname updated', m.user.username));
    } },
  { ...M, name: 'note', description: 'Add a private moderator note', usage: 'note <member> <text>', perms: [P.ModerateMembers],
    async run({ client, message, args, prefix, cmd }) {
      const u = (await getMember(message, args[0]))?.user ?? await getUser(client, args[0]);
      if (!u || args.length < 2) return message.reply(usage(cmd, prefix));
      db.prepare('INSERT INTO notes(guild,user,mod,text,at) VALUES (?,?,?,?,?)').run(message.guild.id, u.id, message.author.id, clip(args.slice(1).join(' '), 400), Date.now());
      return message.reply(ok('Note added', u.username));
    } },
  { ...M, name: 'notes', description: 'View notes on a member', usage: 'notes <user>', perms: [P.ModerateMembers],
    async run({ client, message, args, prefix, cmd }) {
      const u = (await getMember(message, args[0]))?.user ?? await getUser(client, args[0]);
      if (!u) return message.reply(usage(cmd, prefix));
      const rows = db.prepare('SELECT * FROM notes WHERE guild=? AND user=? ORDER BY id DESC LIMIT 10').all(message.guild.id, u.id);
      return message.reply(card({ title: `📝 Notes • ${u.username}`, color: 'mod', body: rows.map((r) => `**#${r.id}** <@${r.mod}> ${ts(r.at, 'd')}: ${clip(r.text, 150)}`).join('\n') || 'No notes.' }));
    } },
  { ...M, name: 'modlogs', aliases: ['history'], description: 'Moderation history of a user', usage: 'modlogs <user>', perms: [P.ModerateMembers],
    async run({ client, message, args, prefix, cmd }) {
      const u = (await getMember(message, args[0]))?.user ?? await getUser(client, args[0]);
      if (!u) return message.reply(usage(cmd, prefix));
      const rows = db.prepare('SELECT * FROM cases WHERE guild=? AND user=? ORDER BY id DESC LIMIT 12').all(message.guild.id, u.id);
      return message.reply(card({ title: `🛡️ Mod logs • ${u.username}`, color: 'mod', body: rows.map((r) => `**#${r.id}** ${r.type} • ${ts(r.at, 'd')} — ${clip(r.reason, 70)}`).join('\n') || 'Clean record.' }));
    } },
  { ...M, name: 'case', description: 'Look up a case by ID', usage: 'case <id>', perms: [P.ModerateMembers],
    async run({ message, args, prefix, cmd }) {
      const r = /^\d+$/.test(args[0] ?? '') && db.prepare('SELECT * FROM cases WHERE id=? AND guild=?').get(args[0], message.guild.id);
      if (!args[0]) return message.reply(usage(cmd, prefix));
      if (!r) return message.reply(fail('Not found', 'No case with that ID.'));
      return message.reply(card({ title: `🛡️ Case #${r.id} • ${r.type}`, color: 'mod', fields: [['User', `<@${r.user}>`], ['Moderator', `<@${r.mod}>`], ['When', ts(r.at, 'F')], ['Reason', r.reason]] }));
    } },
  { ...M, name: 'banlist', description: 'Show recent bans', usage: 'banlist', perms: [P.BanMembers], botPerms: [P.BanMembers],
    async run({ message }) {
      const bans = await message.guild.bans.fetch({ limit: 20 });
      return message.reply(card({ title: `🔨 Bans (${bans.size} shown)`, color: 'mod', body: bans.map((b) => `${b.user.username} (\`${b.user.id}\`) — ${clip(b.reason ?? 'No reason', 50)}`).join('\n') || 'No bans.' }));
    } },
];

export { block, notify, finish };
