import { ChannelType, PermissionFlagsBits as P } from 'discord.js';
import { db, kvGet, kvSet, getGuild, addCase } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { confirm } from '../../core/ptero.js';
import { snipes, esnipes, get } from '../../core/snipe.js';
import { block, notify, finish } from './moderation.js';
import { clip, parseDuration, fmtDuration, getMember, getUser, getRole, getChannel, ts, idOf } from '../../core/util.js';

const M = { category: 'moderation', cooldown: 3 };
const who = async (client, message, arg) => (await getMember(message, arg))?.user ?? await getUser(client, arg);
const purgeBy = (name, desc, pred, usageStr = `${name} [amount]`) => ({ ...M, name, description: desc, usage: usageStr, perms: [P.ManageMessages], botPerms: [P.ManageMessages],
  async run({ message, args }) {
    const n = Math.min(parseInt(args.at(-1)) || 50, 100), uid = idOf(args[0]); await message.delete().catch(() => {});
    const msgs = (await message.channel.messages.fetch({ limit: 100 })).filter((m) => pred(m, uid)).first(n), del = await message.channel.bulkDelete(msgs, true);
    const r = await message.channel.send(ok('Purged', `${del.size} message(s).`)); setTimeout(() => r.delete().catch(() => {}), 4000);
  } });
const textChannels = (g) => g.channels.cache.filter((c) => c.type === ChannelType.GuildText).first(100);

export default [
  { ...M, name: 'tempban', description: 'Ban a member for a set time', usage: 'tempban <user> <1h|2d|1w> [reason]', perms: [P.BanMembers], botPerms: [P.BanMembers], async run({ client, message, args, prefix, cmd }) {
    const ms = parseDuration(args[1]), m = await getMember(message, args[0]), u = m?.user ?? await getUser(client, args[0]); if (!u || !ms) return message.reply(usage(cmd, prefix));
    if (ms > 31536e6) return message.reply(fail('Too long', 'Max 365 days.')); if (m) { const b = block(message, m); if (b) return message.reply(fail('Cannot ban', b)); if (!m.bannable) return message.reply(fail('Cannot ban', 'My role is too low.')); }
    const reason = clip(args.slice(2).join(' ') || 'No reason given', 300), note = m ? await notify(message, u, `🔨 You were banned for ${fmtDuration(ms)}`, reason) : null;
    await message.guild.members.ban(u.id, { reason: `${message.author.tag}: tempban ${fmtDuration(ms)} — ${reason}` }); db.prepare('INSERT OR REPLACE INTO tempbans VALUES (?,?,?)').run(message.guild.id, u.id, Date.now() + ms);
    return finish(message, 'Tempban', u, `${reason} (${fmtDuration(ms)})`, note);
  } },
  { ...M, name: 'massban', description: 'Ban up to 15 user IDs at once', usage: 'massban <id id id ...> [| reason]', perms: [P.BanMembers], botPerms: [P.BanMembers], cooldown: 15, async run({ message, args, prefix, cmd }) {
    const [list, ...r] = args.join(' ').split('|'), ids = [...new Set((list.match(/\d{15,22}/g) ?? []))]; if (!ids.length || ids.length > 15) return message.reply(usage(cmd, prefix));
    if (!(await confirm(message, `Ban **${ids.length}** user(s)?`))) return; const reason = clip(r.join('|').trim() || 'Massban', 300); let n = 0;
    for (const id of ids) { const m = message.guild.members.cache.get(id); if (m && (block(message, m) || !m.bannable)) continue; await message.guild.members.ban(id, { reason: `${message.author.tag}: ${reason}` }).then(() => { n++; addCase(message.guild.id, id, message.author.id, 'Ban', reason); }).catch(() => {}); }
    return message.channel.send(ok('Massban finished', `${n}/${ids.length} banned.`));
  } },
  { ...M, name: 'masskick', description: 'Kick up to 15 mentioned members', usage: 'masskick <@a @b ...> [| reason]', perms: [P.KickMembers], botPerms: [P.KickMembers], cooldown: 15, async run({ message, args, prefix, cmd }) {
    const [list, ...r] = args.join(' ').split('|'), ids = [...new Set(list.match(/\d{15,22}/g) ?? [])]; if (!ids.length || ids.length > 15) return message.reply(usage(cmd, prefix));
    if (!(await confirm(message, `Kick **${ids.length}** member(s)?`))) return; const reason = clip(r.join('|').trim() || 'Masskick', 300); let n = 0;
    for (const id of ids) { const m = message.guild.members.cache.get(id); if (!m || block(message, m) || !m.kickable) continue; await m.kick(`${message.author.tag}: ${reason}`).then(() => { n++; addCase(message.guild.id, id, message.author.id, 'Kick', reason); }).catch(() => {}); }
    return message.channel.send(ok('Masskick finished', `${n}/${ids.length} kicked.`));
  } },
  purgeBy('purgeuser', 'Delete recent messages from one user', (m, uid) => m.author.id === uid, 'purgeuser <@user> [amount]'),
  purgeBy('purgebots', 'Delete recent bot messages', (m) => m.author.bot), purgeBy('purgelinks', 'Delete recent messages with links', (m) => /https?:\/\//i.test(m.content)),
  purgeBy('purgeimages', 'Delete recent messages with attachments/images', (m) => m.attachments.size > 0 || m.embeds.some((e) => e.image || e.thumbnail)),
  { ...M, name: 'lockdown', description: 'Lock every text channel for @everyone', usage: 'lockdown', perms: [P.ManageGuild], botPerms: [P.ManageChannels], cooldown: 30, async run({ message }) {
    if (!(await confirm(message, 'Lock ALL text channels for @everyone?'))) return; let n = 0;
    for (const c of textChannels(message.guild)) await c.permissionOverwrites.edit(message.guild.id, { SendMessages: false }).then(() => n++).catch(() => {}); kvSet(message.guild.id, 'lockdown', '1'); return message.channel.send(ok('Server locked down', `${n} channels locked. Use \`unlockdown\` to undo.`));
  } },
  { ...M, name: 'unlockdown', description: 'Undo a server lockdown', usage: 'unlockdown', perms: [P.ManageGuild], botPerms: [P.ManageChannels], cooldown: 30, async run({ message }) {
    let n = 0; for (const c of textChannels(message.guild)) await c.permissionOverwrites.edit(message.guild.id, { SendMessages: null }).then(() => n++).catch(() => {}); kvSet(message.guild.id, 'lockdown', null); return message.reply(ok('Lockdown lifted', `${n} channels unlocked.`));
  } },
  { ...M, name: 'hardlock', description: 'Lock AND hide a channel', usage: 'hardlock [#channel]', perms: [P.ManageChannels], botPerms: [P.ManageChannels], async run({ message, args }) {
    const c = getChannel(message, args[0]) ?? message.channel; await c.permissionOverwrites.edit(message.guild.id, { SendMessages: false, ViewChannel: false }); return message.reply(ok('Hard-locked', `#${c.name} is hidden and locked. Undo with \`unlock\` and \`unhide\`.`));
  } },
  { ...M, name: 'snipe', description: 'Show the last deleted message here (10 min)', usage: 'snipe', perms: [P.ManageMessages], async run({ message }) {
    const s = get(snipes, message.channel.id); return message.reply(s ? card({ title: '🕵️ Sniped', body: `<@${s.author}>: ${clip(s.content || '*(attachment)*', 1500)}${s.files.length ? `\n📎 ${s.files.join(', ')}` : ''}`, fields: [['Deleted', ts(s.at)]] }) : fail('Nothing to snipe'));
  } },
  { ...M, name: 'editsnipe', aliases: ['esnipe'], description: 'Show the last edited message here (10 min)', usage: 'editsnipe', perms: [P.ManageMessages], async run({ message }) {
    const s = get(esnipes, message.channel.id); return message.reply(s ? card({ title: '✏️ Edit sniped', body: `<@${s.author}> originally wrote:\n${clip(s.content, 1500)}`, fields: [['Edited', ts(s.at)]] }) : fail('Nothing to snipe'));
  } },
  { ...M, name: 'delnote', description: 'Delete a moderator note', usage: 'delnote <id>', perms: [P.ModerateMembers], async run({ message, args }) { return message.reply(db.prepare('DELETE FROM notes WHERE id=? AND guild=?').run(parseInt(args[0]), message.guild.id).changes ? ok('Note deleted') : fail('Not found')); } },
  { ...M, name: 'clearnotes', description: 'Delete all notes on a user', usage: 'clearnotes <user>', perms: [P.ModerateMembers], async run({ client, message, args, prefix, cmd }) {
    const u = await who(client, message, args[0]); if (!u) return message.reply(usage(cmd, prefix)); return message.reply(ok('Notes cleared', `${db.prepare('DELETE FROM notes WHERE guild=? AND user=?').run(message.guild.id, u.id).changes} removed.`));
  } },
  { ...M, name: 'clearmodlogs', description: 'Delete ALL cases for a user', usage: 'clearmodlogs <user>', perms: [P.Administrator], async run({ client, message, args, prefix, cmd }) {
    const u = await who(client, message, args[0]); if (!u) return message.reply(usage(cmd, prefix)); if (!(await confirm(message, `Delete every case for **${u.username}**?`))) return;
    return message.channel.send(ok('Cases cleared', `${db.prepare('DELETE FROM cases WHERE guild=? AND user=?').run(message.guild.id, u.id).changes} removed.`));
  } },
  { ...M, name: 'setjailrole', description: 'Set the role used by jail/quarantine', usage: 'setjailrole <@role>', perms: [P.ManageGuild], async run({ message, args, prefix, cmd }) {
    const r = getRole(message, args.join(' ')); if (!r) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, 'jail_role', r.id); return message.reply(ok('Jail role set', `${r.name}. Deny it Send Messages / View in your channels (except a jail channel).`));
  } },
  { ...M, name: 'jail', description: 'Give the jail role to a member', usage: 'jail <member> [reason]', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]), rid = kvGet(message.guild.id, 'jail_role'); if (!m) return message.reply(usage(cmd, prefix)); if (!rid) return message.reply(fail('No jail role', 'Set one with `setjailrole`.'));
    const b = block(message, m); if (b) return message.reply(fail('Cannot jail', b)); await m.roles.add(rid); const reason = clip(args.slice(1).join(' ') || 'No reason given', 300); return finish(message, 'Jail', m.user, reason, await notify(message, m.user, '⛓️ You were jailed', reason));
  } },
  { ...M, name: 'unjail', description: 'Remove the jail role', usage: 'unjail <member>', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]), rid = kvGet(message.guild.id, 'jail_role'); if (!m || !rid) return message.reply(usage(cmd, prefix)); await m.roles.remove(rid); return finish(message, 'Unjail', m.user, 'Released');
  } },
  { ...M, name: 'quarantine', description: 'Strip a member\'s roles and jail them (restorable)', usage: 'quarantine <member> [reason]', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]), rid = kvGet(message.guild.id, 'jail_role'); if (!m) return message.reply(usage(cmd, prefix)); if (!rid) return message.reply(fail('No jail role', 'Set one with `setjailrole`.'));
    const b = block(message, m); if (b) return message.reply(fail('Cannot quarantine', b)); const roles = m.roles.cache.filter((r) => r.id !== message.guild.id && !r.managed && r.editable).map((r) => r.id);
    kvSet(message.guild.id, `quar:${m.id}`, JSON.stringify(roles)); await m.roles.set([...m.roles.cache.filter((r) => r.managed || !r.editable).keys(), rid].filter((x) => x !== message.guild.id), 'Quarantine'); const reason = clip(args.slice(1).join(' ') || 'No reason given', 300);
    return finish(message, 'Quarantine', m.user, reason, await notify(message, m.user, '☣️ You were quarantined', reason));
  } },
  { ...M, name: 'unquarantine', description: 'Restore a quarantined member\'s roles', usage: 'unquarantine <member>', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]); if (!m) return message.reply(usage(cmd, prefix)); const saved = kvGet(message.guild.id, `quar:${m.id}`); if (!saved) return message.reply(fail('Not quarantined'));
    const jail = kvGet(message.guild.id, 'jail_role'); await m.roles.set([...m.roles.cache.filter((r) => r.id !== jail && r.id !== message.guild.id).keys(), ...JSON.parse(saved).filter((id) => message.guild.roles.cache.has(id))]); kvSet(message.guild.id, `quar:${m.id}`, null); return finish(message, 'Unquarantine', m.user, 'Roles restored');
  } },
  { ...M, name: 'forcenick', description: 'Lock a member\'s nickname', usage: 'forcenick <member> <nickname|off>', perms: [P.ManageNicknames], botPerms: [P.ManageNicknames], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]); if (!m || !args[1]) return message.reply(usage(cmd, prefix)); const b = block(message, m); if (b) return message.reply(fail('Cannot', b));
    if (args[1] === 'off') { kvSet(message.guild.id, `forcenick:${m.id}`, null); return message.reply(ok('Forced nickname removed')); } const n = clip(args.slice(1).join(' '), 32); kvSet(message.guild.id, `forcenick:${m.id}`, n); await m.setNickname(n); return message.reply(ok('Nickname locked', `${m.user.username} → ${n}`));
  } },
  { ...M, name: 'mutelist', description: 'Members currently timed out', usage: 'mutelist', perms: [P.ModerateMembers], async run({ message }) {
    await message.guild.members.fetch().catch(() => {}); const l = message.guild.members.cache.filter((m) => m.communicationDisabledUntilTimestamp > Date.now());
    return message.reply(card({ title: `🔇 Timed out (${l.size})`, color: 'mod', body: l.map((m) => `<@${m.id}> — ends ${ts(m.communicationDisabledUntilTimestamp)}`).join('\n') || 'Nobody.' }));
  } },
  { ...M, name: 'modstats', description: 'Moderation statistics', usage: 'modstats [moderator]', perms: [P.ModerateMembers], async run({ message, args }) {
    const m = await getMember(message, args[0]), g = message.guild.id, rows = m ? db.prepare('SELECT type, COUNT(*) n FROM cases WHERE guild=? AND mod=? GROUP BY type').all(g, m.id) : db.prepare('SELECT type, COUNT(*) n FROM cases WHERE guild=? GROUP BY type').all(g);
    const top = m ? [] : db.prepare('SELECT mod, COUNT(*) n FROM cases WHERE guild=? GROUP BY mod ORDER BY n DESC LIMIT 3').all(g);
    return message.reply(card({ title: m ? `📈 ${m.user.username}` : '📈 Moderation stats', color: 'mod', body: rows.map((r) => `**${r.type}:** ${r.n}`).join('\n') || 'No cases yet.', fields: top.length ? [['Most active', top.map((t) => `<@${t.mod}> (${t.n})`).join(', ')]] : [] }));
  } },
  { ...M, name: 'strike', description: 'Give a strike (3 strikes = 24h timeout)', usage: 'strike <member> <reason>', perms: [P.ModerateMembers], botPerms: [P.ModerateMembers], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]); if (!m || args.length < 2) return message.reply(usage(cmd, prefix)); const b = block(message, m); if (b) return message.reply(fail('Cannot strike', b));
    const reason = clip(args.slice(1).join(' '), 300), n = db.prepare("SELECT COUNT(*) c FROM cases WHERE guild=? AND user=? AND type='Strike'").get(message.guild.id, m.id).c + 1; let extra = `${n} strike(s)`;
    if (n % 3 === 0 && m.moderatable) { await m.timeout(864e5, `3 strikes`).catch(() => {}); extra += ' • timed out 24h'; } return finish(message, 'Strike', m.user, reason, `${extra} • ${await notify(message, m.user, '⚡ You received a strike', reason)}`);
  } },
  { ...M, name: 'clearstrikes', description: 'Clear a member\'s strikes', usage: 'clearstrikes <user>', perms: [P.ModerateMembers], async run({ client, message, args, prefix, cmd }) {
    const u = await who(client, message, args[0]); if (!u) return message.reply(usage(cmd, prefix)); return message.reply(ok('Strikes cleared', `${db.prepare("DELETE FROM cases WHERE guild=? AND user=? AND type='Strike'").run(message.guild.id, u.id).changes} removed.`));
  } },
  { ...M, name: 'checkban', description: 'Check if a user ID is banned', usage: 'checkban <id>', perms: [P.BanMembers], botPerms: [P.BanMembers], async run({ message, args, prefix, cmd }) {
    const id = idOf(args[0]); if (!/^\d{15,22}$/.test(id)) return message.reply(usage(cmd, prefix)); const b = await message.guild.bans.fetch(id).catch(() => null);
    return message.reply(b ? card({ title: '🔨 Banned', color: 'mod', body: `**${b.user.username}** (${id})\nReason: ${clip(b.reason ?? 'No reason', 300)}` }) : ok('Not banned', `\`${id}\` is not banned here.`));
  } },
  { ...M, name: 'risk', description: 'Risk score for a member', usage: 'risk <member>', perms: [P.ModerateMembers], async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]); if (!m) return message.reply(usage(cmd, prefix)); const age = (Date.now() - m.user.createdTimestamp) / 864e5, joined = (Date.now() - m.joinedTimestamp) / 864e5, c = (t) => db.prepare('SELECT COUNT(*) c FROM cases WHERE guild=? AND user=? AND type=?').get(message.guild.id, m.id, t).c;
    const f = [[age < 7 ? 30 : age < 30 ? 15 : 0, `Account age ${Math.floor(age)}d`], [joined < 3 ? 15 : 0, `Joined ${Math.floor(joined)}d ago`], [Math.min(c('Warn') * 10, 30), `${c('Warn')} warning(s)`], [Math.min(c('Strike') * 15, 30), `${c('Strike')} strike(s)`], [m.user.avatar ? 0 : 10, m.user.avatar ? 'Has avatar' : 'Default avatar'], [m.communicationDisabledUntilTimestamp > Date.now() ? 10 : 0, 'Currently timed out']];
    const s = Math.min(100, f.reduce((a, x) => a + x[0], 0));
    return message.reply(card({ title: `🧮 Risk • ${m.user.username}`, color: s >= 60 ? 'error' : s >= 30 ? 'warning' : 'success', body: `**${s}/100** — ${s >= 60 ? 'High' : s >= 30 ? 'Medium' : 'Low'}\n${f.map((x) => `${x[0] ? `+${x[0]}` : '+0'} ${x[1]}`).join('\n')}` }));
  } },
];
