import { PermissionFlagsBits as P, ChannelType } from 'discord.js';
import { db, kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { getTicket } from '../../core/tickets.js';
import { getMember, getRole, getChannel, clip, idOf } from '../../core/util.js';

const T = { category: 'ticket', cooldown: 3, perms: [P.ManageGuild] };
const cfgSet = (name, col, desc, kind) => ({ ...T, name, description: desc, usage: `${name} <${kind === 'role' ? '@role' : kind === 'category' ? 'category ID' : kind === 'number' ? '1-5' : '#channel'}>`, async run({ message, args, prefix, cmd }) {
  db.prepare('INSERT OR IGNORE INTO ticket_cfg(guild) VALUES (?)').run(message.guild.id); let v, show;
  if (kind === 'role') { const r = getRole(message, args.join(' ')); if (!r) return message.reply(usage(cmd, prefix)); v = r.id; show = r.name; }
  else if (kind === 'category') { const c = message.guild.channels.cache.get(idOf(args[0])); if (c?.type !== ChannelType.GuildCategory) return message.reply(usage(cmd, prefix)); v = c.id; show = c.name; }
  else if (kind === 'number') { const n = parseInt(args[0]); if (!(n >= 1 && n <= 5)) return message.reply(usage(cmd, prefix)); v = n; show = `${n} per user`; }
  else { const c = getChannel(message, args[0]); if (!c?.isTextBased()) return message.reply(usage(cmd, prefix)); v = c.id; show = `<#${c.id}>`; }
  db.prepare(`UPDATE ticket_cfg SET ${col}=? WHERE guild=?`).run(v, message.guild.id); return message.reply(ok(name, show));
} });

export default [
  cfgSet('ticketcategory', 'category', 'Category where tickets are created', 'category'), cfgSet('ticketrole', 'staff_role', 'Staff role for tickets', 'role'),
  cfgSet('ticketlog', 'log_channel', 'Ticket log channel', 'channel'), cfgSet('ticketlimit', 'max_open', 'Max open tickets per user', 'number'),
  { ...T, name: 'ticketrating', description: 'Ask owners to rate tickets when they close', usage: 'ticketrating <on|off>', async run({ message, args, prefix, cmd }) {
    if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, 'tk_rating', args[0] === 'on' ? '1' : null); return message.reply(ok('Ticket ratings', args[0]));
  } },
  { ...T, perms: [P.ManageMessages], name: 'staffstats', description: 'Ticket stats for a staff member', usage: 'staffstats [member]', async run({ message, args }) {
    const m = (await getMember(message, args[0])) ?? message.member, r = db.prepare("SELECT COUNT(*) n, AVG(rating) a, COUNT(rating) rated FROM tickets WHERE guild=? AND claimed_by=?").get(message.guild.id, m.id);
    return message.reply(card({ title: `🎫 ${m.displayName}`, fields: [['Tickets claimed', r.n], ['Average rating', r.rated ? `${r.a.toFixed(2)} ⭐ (${r.rated} ratings)` : 'No ratings yet']] }));
  } },
  ...['ticketblacklist', 'ticketunblacklist'].map((name) => ({ ...T, name, perms: [P.ManageMessages], description: `${name === 'ticketblacklist' ? 'Block' : 'Unblock'} a member from opening tickets`, usage: `${name} <member>`, async run({ message, args, prefix, cmd }) {
    const m = await getMember(message, args[0]); if (!m) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, `tkbl:${m.id}`, name === 'ticketblacklist' ? '1' : null); return message.reply(ok(name, m.user.username));
  } })),
  { ...T, perms: [P.ManageMessages], name: 'tickettopic', description: 'Set the topic of this ticket', usage: 'tickettopic <text>', async run({ message, args, prefix, cmd }) {
    const t = getTicket(message.channel.id); if (!t) return message.reply(fail('Not a ticket')); if (!args.length) return message.reply(usage(cmd, prefix));
    const topic = clip(args.join(' '), 200); db.prepare('UPDATE tickets SET topic=? WHERE channel=?').run(topic, t.channel); await message.channel.setTopic(`${topic} • owner ${t.owner}`).catch(() => {}); return message.reply(ok('Ticket topic', topic));
  } },
  { ...T, name: 'ticketautoclose', description: 'Auto-close tickets after N hours of silence (0 = off)', usage: 'ticketautoclose <hours|off>', async run({ message, args, prefix, cmd }) {
    const h = args[0] === 'off' ? 0 : parseInt(args[0]); if (isNaN(h) || h < 0 || h > 720) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, 'tk_autoclose', h || null); return message.reply(ok('Ticket auto-close', h ? `After ${h}h of inactivity (a warning is sent at 75%).` : 'Disabled'));
  } },
];
