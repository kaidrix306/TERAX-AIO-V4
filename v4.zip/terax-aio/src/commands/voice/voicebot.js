import { PermissionFlagsBits as P } from 'discord.js';
import { kvSet } from '../../core/db.js';
import { ok, fail, usage } from '../../core/ui.js';
import { queues, connect, destroy, musicOnline } from '../../core/music.js';

const V = { category: 'voice', cooldown: 3 };
export default [
  { ...V, name: 'join', aliases: ['summon'], description: 'Make the bot join your voice channel', usage: 'join', async run({ client, message }) {
    if (!musicOnline(client)) return message.reply(fail('Voice is offline', 'No Lavalink node is connected.'));
    const vc = message.member.voice.channel; if (!vc) return message.reply(fail('Join a voice channel first'));
    if (!vc.permissionsFor(message.guild.members.me).has([P.Connect, P.Speak])) return message.reply(fail('Missing permissions', 'I need Connect and Speak there.'));
    await connect(client, message.guild, vc.id, message.channel); return message.reply(ok('Joined', `<#${vc.id}>`));
  } },
  { ...V, name: 'vcleave', aliases: ['leavevc'], description: 'Make the bot leave voice', usage: 'vcleave', perms: [P.MoveMembers], async run({ client, message }) {
    if (!queues.has(message.guild.id)) return message.reply(fail('I am not in a voice channel')); destroy(client, message.guild.id); kvSet(message.guild.id, '247', null); return message.reply(ok('Left the voice channel'));
  } },
  { ...V, name: '247', description: 'Keep the bot in your voice channel 24/7', usage: '247 <on|off>', perms: [P.ManageGuild], async run({ client, message, args, prefix, cmd }) {
    if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
    if (args[0] === 'off') { kvSet(message.guild.id, '247', null); return message.reply(ok('24/7 mode off', 'I will leave when idle.')); }
    const vc = message.member.voice.channel; if (!vc) return message.reply(fail('Join a voice channel first')); if (!musicOnline(client)) return message.reply(fail('Voice is offline'));
    await connect(client, message.guild, vc.id, message.channel); kvSet(message.guild.id, '247', vc.id); return message.reply(ok('24/7 mode on', `I will stay in <#${vc.id}>.`));
  } },
];
