import { PermissionFlagsBits as P } from 'discord.js';
import { getGuild, setGuild, kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { gemini, aiError } from '../../core/gemini.js';
import { clip } from '../../core/util.js';

const NOTE = 'Reply in plain text under 250 words. Do not use markdown headings.';
function make(name, aliases, description, usageStr, system, { fromChannel = false } = {}) {
  return {
    category: 'ai', name, aliases, description, usage: usageStr, cooldown: 8,
    async run({ message, args, prefix, cmd }) {
      if (!getGuild(message.guild.id).ai_enabled) return message.reply(fail('AI is off', 'An admin turned the AI off in this server.'));
      let text = args.join(' ');
      if (!text && message.reference) text = (await message.fetchReference().catch(() => null))?.content ?? '';
      if (!text && fromChannel) {
        const msgs = await message.channel.messages.fetch({ limit: 30 });
        text = [...msgs.values()].reverse().filter((m) => !m.author.bot && m.content).map((m) => `${m.author.username}: ${m.content}`).join('\n');
      }
      if (!text) return message.reply(usage(cmd, prefix));
      await message.channel.sendTyping().catch(() => {});
      try {
        const persona = kvGet(message.guild.id, 'ai_persona'); const out = await gemini({ system: `${persona ? `${persona}\n` : ''}${system} ${NOTE}`, prompt: clip(text, 6000) });
        return message.reply(card({ title: `🤖 ${name[0].toUpperCase() + name.slice(1)}`, body: clip(out, 2000), foot: true }));
      } catch (e) { return message.reply(fail('AI unavailable', aiError(e))); }
    },
  };
}

export default [
  make('ask', ['chat'], 'Ask the AI anything', 'ask <question>', 'You are a friendly, accurate assistant inside a Discord server.'),
  make('summarize', ['summary'], 'Summarize text or the last 30 messages', 'summarize [text]', 'Summarize the following clearly in 4-6 short bullet-style lines.', { fromChannel: true }),
  make('tldr', [], 'One-sentence summary', 'tldr <text>', 'Give a one or two sentence TL;DR of the text.'),
  make('translate', ['tr'], 'Translate text (start with the language)', 'translate <language> <text>', 'The first word is the target language; translate the rest into it. Output only the translation.'),
  make('explain', ['eli5'], 'Explain something simply', 'explain <topic>', 'Explain the topic simply, as to a curious beginner, with one short example.'),
  make('codehelp', ['code'], 'Get help with code', 'codehelp <question or code>', 'You are a senior developer. Give a concise fix or explanation and a short code snippet if useful.'),
  make('rewrite', [], 'Rewrite text more clearly', 'rewrite <text>', 'Rewrite the text to be clearer and more polished while keeping its meaning. Output only the rewrite.'),
  make('fixgrammar', ['grammar'], 'Fix spelling and grammar', 'fixgrammar <text>', 'Fix spelling and grammar. Output only the corrected text.'),
  { category: 'ai', name: 'aisetup', description: 'Turn the AI on or off for this server', usage: 'aisetup <on|off>', perms: [P.ManageGuild],
    async run({ message, args, prefix, cmd }) {
      if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
      setGuild(message.guild.id, 'ai_enabled', args[0] === 'on' ? 1 : 0); return message.reply(ok('AI', args[0] === 'on' ? 'Enabled' : 'Disabled'));
    } },
  { category: 'ai', name: 'aiprompt', aliases: ['aifaq'], description: 'Set the FAQ/rules the ticket AI uses', usage: 'aiprompt <text|show|clear>', perms: [P.ManageGuild],
    async run({ message, args, prefix, cmd }) {
      if (!args.length) return message.reply(usage(cmd, prefix));
      if (args[0] === 'show') return message.reply(card({ title: '🧠 AI server info', body: clip(getGuild(message.guild.id).ai_prompt || 'Nothing set.', 1800) }));
      if (args[0] === 'clear') { setGuild(message.guild.id, 'ai_prompt', null); return message.reply(ok('AI server info cleared')); }
      setGuild(message.guild.id, 'ai_prompt', clip(args.join(' '), 1800)); return message.reply(ok('AI server info saved', 'The ticket AI will use it to answer questions.'));
    } },
];
