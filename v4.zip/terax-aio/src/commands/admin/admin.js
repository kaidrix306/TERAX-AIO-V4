import { PermissionFlagsBits as P } from 'discord.js';
import { db, getGuild, setGuild } from '../../core/db.js';
import { ok, card, usage } from '../../core/ui.js';
import { getChannel } from '../../core/util.js';

const A = { category: 'admin', perms: [P.ManageGuild] };
export default [
  { ...A, name: 'setprefix', description: 'Change the prefix for this server', usage: 'setprefix <prefix>',
    async run({ message, args, prefix, cmd }) {
      if (!args[0] || args[0].length > 5) return message.reply(usage(cmd, prefix));
      setGuild(message.guild.id, 'prefix', args[0]); return message.reply(ok('Prefix updated', `New prefix: \`${args[0]}\``));
    } },
  { ...A, name: 'setlogchannel', aliases: ['logs'], description: 'Set the moderation log channel', usage: 'setlogchannel <#channel|off>',
    async run({ message, args, prefix, cmd }) {
      if (args[0] === 'off') { setGuild(message.guild.id, 'log_channel', null); return message.reply(ok('Logging disabled')); }
      const c = getChannel(message, args[0]);
      if (!c?.isTextBased()) return message.reply(usage(cmd, prefix));
      setGuild(message.guild.id, 'log_channel', c.id); return message.reply(ok('Log channel set', `<#${c.id}>`));
    } },
  { ...A, name: 'dmnotices', description: 'Toggle DM notices to punished members', usage: 'dmnotices <on|off>',
    async run({ message, args, prefix, cmd }) {
      if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
      setGuild(message.guild.id, 'dm_notices', args[0] === 'on' ? 1 : 0); return message.reply(ok('DM notices', args[0] === 'on' ? 'Enabled' : 'Disabled'));
    } },
  { ...A, name: 'config', aliases: ['settings'], description: "Show this server's settings", usage: 'config',
    async run({ message, prefix }) {
      const g = getGuild(message.guild.id), t = db.prepare('SELECT * FROM ticket_cfg WHERE guild=?').get(message.guild.id);
      return message.reply(card({ title: '⚙️ Server settings', fields: [
        ['Prefix', `\`${g.prefix || prefix}\``], ['Log channel', g.log_channel ? `<#${g.log_channel}>` : 'Not set'], ['DM notices', g.dm_notices ? 'On' : 'Off'],
        ['AI', g.ai_enabled ? 'On' : 'Off'], ['Ticket category', t?.category ? `<#${t.category}>` : 'Not set'], ['Ticket staff role', t?.staff_role ? `<@&${t.staff_role}>` : 'Not set']] }));
    } },
];
