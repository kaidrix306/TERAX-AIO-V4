import { db } from '../../core/db.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { dmWithNotice } from '../../core/dm.js';
import { api, cfgOf, def, confirm, plog, pending, resolveServer, level } from '../../core/ptero.js';
import { isOwner } from '../../core/config.js';
import { clip, getRole, getChannel } from '../../core/util.js';

const gOwner = (m) => isOwner(m.author.id) || m.author.id === m.guild.ownerId;
const ownerOnly = (run) => ({ category: 'hosting', cooldown: 5, run: async (ctx) => {
  if (!gOwner(ctx.message)) return ctx.message.reply(fail('Owner only', 'Only the server owner can manage the panel link.'));
  try { return await run(ctx); } catch (e) { return ctx.message.reply(fail('Error', clip(e.message, 300))); }
} });
const mb = (n) => (n ? `${n} MB` : 'Unlimited');
const bytes = (n) => `${(n / 1048576).toFixed(1)} MB`;
const A = (r) => r.data.map((d) => d.attributes);
const keyDM = (message, text) => dmWithNotice(message, message.author, card({ title: '🔐 Send your API key here', body: text + '\n\nReply in this DM with the key. It is validated, encrypted (AES-256-GCM) and never shown again. If you ever paste a key by mistake, regenerate it in the panel.', color: 'warning' }), 'I sent you instructions for sending the key privately.');

async function appServerId(gid, q) {
  if (/^\d+$/.test(q ?? '')) return q;
  const r = await api(gid, 'app', 'GET', `/servers?filter[uuidShort]=${encodeURIComponent(q ?? '')}`);
  if (!r.data.length) throw new Error('NO_SERVER');
  return r.data[0].attributes.id;
}
const power = (name, signal, label, needConfirm) => def({ lv: 1, name, description: `${label} a server`, usage: `${name} <server>`,
  async run({ client, message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, args.join(' '));
    if (needConfirm && !(await confirm(message, `${label} **${srv.name}**? Unsaved data may be lost.`))) return;
    await api(gid, 'client', 'POST', `/servers/${srv.identifier}/power`, { signal }, key);
    plog(client, gid, message.author, `${label} **${srv.name}** (${srv.identifier})`);
    return message.reply(ok(`${label} sent`, `**${srv.name}**`));
  } });

export default [
  // ---- Setup (server owner) ----
  { name: 'pteroset', description: 'Link your Pterodactyl panel (server owner only)', usage: 'pteroset <https://panel.example.com>',
    ...ownerOnly(async ({ message, args, prefix }) => {
      let url; try { url = new URL(args[0]); if (!/^https?:$/.test(url.protocol)) throw 0; } catch { return message.reply(usage({ usage: 'pteroset <https://panel.example.com>' }, prefix)); }
      db.prepare('INSERT INTO ptero_cfg(guild,url) VALUES (?,?) ON CONFLICT(guild) DO UPDATE SET url=excluded.url').run(message.guild.id, url.origin);
      pending.set(message.author.id, { guild: message.guild.id, mode: 'owner', until: Date.now() + 600000 });
      await message.reply(ok('Panel URL saved', url.origin));
      return keyDM(message, 'Send your **Application API key** (`ptla_…`, admin level) and your **Client API key** (`ptlc_…`) as two separate messages. You have 10 minutes.');
    }) },
  { name: 'pterorotate', description: 'Replace the saved panel API keys', usage: 'pterorotate',
    ...ownerOnly(async ({ message }) => {
      if (!cfgOf(message.guild.id)) return message.reply(fail('Not linked', 'Run `pteroset` first.'));
      pending.set(message.author.id, { guild: message.guild.id, mode: 'owner', until: Date.now() + 600000 });
      return keyDM(message, 'Send the new `ptla_…` and/or `ptlc_…` key.');
    }) },
  { name: 'pterocheck', description: 'Test the panel connection', usage: 'pterocheck',
    ...ownerOnly(async ({ message }) => {
      const c = cfgOf(message.guild.id); if (!c) return message.reply(fail('Not linked', 'Run `pteroset` first.'));
      const test = async (kind, path, has) => !has ? 'not set' : await api(message.guild.id, kind, 'GET', path).then(() => '✅ works', (e) => `❌ ${clip(e.message, 60)}`);
      return message.reply(card({ title: '🦕 Panel check', fields: [['URL', c.url], ['Application key', await test('app', '/nodes?per_page=1', c.app_key)], ['Client key', await test('client', '/?per_page=1', c.client_key)],
        ['Admin role', c.admin_role ? `<@&${c.admin_role}>` : 'owner only'], ['Staff role', c.staff_role ? `<@&${c.staff_role}>` : 'not set'], ['Customer role', c.customer_role ? `<@&${c.customer_role}>` : 'not set'], ['Log channel', c.log_channel ? `<#${c.log_channel}>` : 'not set']] }));
    }) },
  { name: 'pteroremove', description: 'Remove the panel link and all stored keys', usage: 'pteroremove',
    ...ownerOnly(async ({ message }) => {
      if (!(await confirm(message, 'Delete the panel link and ALL stored API keys (including linked customers)?'))) return;
      db.prepare('DELETE FROM ptero_cfg WHERE guild=?').run(message.guild.id); db.prepare('DELETE FROM ptero_links WHERE guild=?').run(message.guild.id);
      return message.channel.send(ok('Panel link removed'));
    }) },
  { name: 'pteroperms', description: 'Set which role has which panel access', usage: 'pteroperms <admin|staff|customer> <@role|none>',
    ...ownerOnly(async ({ message, args, prefix }) => {
      const col = { admin: 'admin_role', staff: 'staff_role', customer: 'customer_role' }[args[0]];
      if (!col || !cfgOf(message.guild.id)) return message.reply(usage({ usage: 'pteroperms <admin|staff|customer> <@role|none>' }, prefix));
      const r = args[1] === 'none' ? null : getRole(message, args.slice(1).join(' '));
      if (args[1] !== 'none' && !r) return message.reply(fail('Role not found'));
      db.prepare(`UPDATE ptero_cfg SET ${col}=? WHERE guild=?`).run(r?.id ?? null, message.guild.id);
      return message.reply(ok('Panel role updated', `${args[0]}: ${r ? r.name : 'none'}`));
    }) },
  { name: 'pterolog', description: 'Set the panel action log channel', usage: 'pterolog <#channel|off>',
    ...ownerOnly(async ({ message, args }) => {
      const c = args[0] === 'off' ? null : getChannel(message, args[0]);
      if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(fail('Invalid channel'));
      db.prepare('UPDATE ptero_cfg SET log_channel=? WHERE guild=?').run(c?.id ?? null, message.guild.id); return message.reply(ok('Panel log', c ? `<#${c.id}>` : 'Disabled'));
    }) },

  // ---- Admin via Application API ----
  def({ name: 'pterousers', description: 'List panel users', usage: 'pterousers [page]', async run({ message, args }) {
    const r = await api(message.guild.id, 'app', 'GET', `/users?per_page=20&page=${parseInt(args[0]) || 1}`);
    return message.reply(card({ title: `👥 Panel users (${r.meta.pagination.total})`, body: A(r).map((u) => `\`${u.id}\` **${u.username}** — ${u.email}${u.root_admin ? ' 👑' : ''}`).join('\n') || 'None' }));
  } }),
  def({ name: 'pterouser', description: 'Show one panel user (ID or email)', usage: 'pterouser <id|email>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const u = /^\d+$/.test(args[0]) ? (await api(message.guild.id, 'app', 'GET', `/users/${args[0]}`)).attributes : A(await api(message.guild.id, 'app', 'GET', `/users?filter[email]=${encodeURIComponent(args[0])}`))[0];
    if (!u) return message.reply(fail('Not found', 'No such panel user.'));
    return message.reply(card({ title: `👤 ${u.username}`, fields: [['ID', u.id], ['Email', u.email], ['Name', `${u.first_name} ${u.last_name}`], ['Root admin', u.root_admin ? 'Yes' : 'No'], ['2FA', u['2fa'] ? 'On' : 'Off'], ['Created', u.created_at]] }));
  } }),
  def({ name: 'pterocreateuser', description: 'Create a panel user', usage: 'pterocreateuser <email> <username> <first> <last>', async run({ client, message, args, prefix, cmd }) {
    if (args.length < 4) return message.reply(usage(cmd, prefix));
    const r = await api(message.guild.id, 'app', 'POST', '/users', { email: args[0], username: args[1], first_name: args[2], last_name: args[3] });
    plog(client, message.guild.id, message.author, `Created panel user **${args[1]}**`);
    return message.reply(ok('User created', `ID \`${r.attributes.id}\` — ${r.attributes.username}`));
  } }),
  def({ name: 'pterodeluser', description: 'Delete a panel user', usage: 'pterodeluser <id>', async run({ client, message, args, prefix, cmd }) {
    if (!/^\d+$/.test(args[0] ?? '')) return message.reply(usage(cmd, prefix));
    if (!(await confirm(message, `Delete panel user **#${args[0]}**? This cannot be undone.`))) return;
    await api(message.guild.id, 'app', 'DELETE', `/users/${args[0]}`); plog(client, message.guild.id, message.author, `Deleted panel user #${args[0]}`);
    return message.channel.send(ok('User deleted'));
  } }),
  def({ name: 'pteronodes', description: 'List nodes', usage: 'pteronodes', async run({ message }) {
    const r = await api(message.guild.id, 'app', 'GET', '/nodes?per_page=50');
    return message.reply(card({ title: '🖥️ Nodes', body: A(r).map((n) => `\`${n.id}\` **${n.name}** — ${n.fqdn} • ${mb(n.memory)} RAM • ${mb(n.disk)} disk${n.maintenance_mode ? ' 🛠️' : ''}`).join('\n') || 'None' }));
  } }),
  def({ name: 'pteronode', description: 'Node details', usage: 'pteronode <id>', async run({ message, args, prefix, cmd }) {
    if (!/^\d+$/.test(args[0] ?? '')) return message.reply(usage(cmd, prefix));
    const n = (await api(message.guild.id, 'app', 'GET', `/nodes/${args[0]}`)).attributes;
    return message.reply(card({ title: `🖥️ ${n.name}`, fields: [['ID', n.id], ['FQDN', `${n.scheme}://${n.fqdn}:${n.daemon_listen}`], ['Location', n.location_id], ['Memory', `${mb(n.memory)} (+${n.memory_overallocate}%)`], ['Disk', `${mb(n.disk)} (+${n.disk_overallocate}%)`], ['Maintenance', n.maintenance_mode ? 'Yes' : 'No']] }));
  } }),
  def({ name: 'pteronodeusage', description: 'Allocated resources vs capacity on a node', usage: 'pteronodeusage <id>', async run({ message, args, prefix, cmd }) {
    if (!/^\d+$/.test(args[0] ?? '')) return message.reply(usage(cmd, prefix));
    const r = await api(message.guild.id, 'app', 'GET', `/nodes/${args[0]}?include=servers,allocations`), n = r.attributes, sv = r.attributes.relationships.servers.data.map((s) => s.attributes);
    const ram = sv.reduce((a, s) => a + s.limits.memory, 0), disk = sv.reduce((a, s) => a + s.limits.disk, 0), al = r.attributes.relationships.allocations.data.map((x) => x.attributes);
    return message.reply(card({ title: `📈 ${n.name} usage`, fields: [['Servers', sv.length], ['RAM allocated', `${ram} / ${n.memory} MB`], ['Disk allocated', `${disk} / ${n.disk} MB`], ['Ports', `${al.filter((x) => x.assigned).length} used / ${al.length}`]] }));
  } }),
  def({ name: 'pteroallocations', description: 'Allocations on a node', usage: 'pteroallocations <nodeId>', async run({ message, args, prefix, cmd }) {
    if (!/^\d+$/.test(args[0] ?? '')) return message.reply(usage(cmd, prefix));
    const a = A(await api(message.guild.id, 'app', 'GET', `/nodes/${args[0]}/allocations?per_page=60`));
    return message.reply(card({ title: `🔌 Allocations (node ${args[0]})`, body: clip(a.map((x) => `${x.ip}:${x.port} ${x.assigned ? '🔴' : '🟢'}`).join(' • ') || 'None', 1800) }));
  } }),
  def({ name: 'pteronests', description: 'List nests', usage: 'pteronests', async run({ message }) {
    return message.reply(card({ title: '🪺 Nests', body: A(await api(message.guild.id, 'app', 'GET', '/nests')).map((n) => `\`${n.id}\` ${n.name}`).join('\n') || 'None' }));
  } }),
  def({ name: 'pteroeggs', description: 'List eggs in a nest', usage: 'pteroeggs <nestId>', async run({ message, args, prefix, cmd }) {
    if (!/^\d+$/.test(args[0] ?? '')) return message.reply(usage(cmd, prefix));
    return message.reply(card({ title: '🥚 Eggs', body: A(await api(message.guild.id, 'app', 'GET', `/nests/${args[0]}/eggs`)).map((e) => `\`${e.id}\` ${e.name}`).join('\n') || 'None' }));
  } }),
  def({ name: 'pterocreate', description: 'Create a server', usage: 'pterocreate <name> <userId> <nestId> <eggId> <nodeId> <ramMB> <diskMB> [cpu%]', async run({ client, message, args, prefix, cmd }) {
    const [name, user, nest, eggId, node, ram, disk, cpu = '100'] = args;
    if (args.length < 7 || [user, nest, eggId, node, ram, disk, cpu].some((x) => !/^\d+$/.test(x))) return message.reply(usage(cmd, prefix));
    const g = message.guild.id;
    const egg = (await api(g, 'app', 'GET', `/nests/${nest}/eggs/${eggId}?include=variables`)).attributes;
    const alloc = A(await api(g, 'app', 'GET', `/nodes/${node}/allocations?per_page=100`)).find((a) => !a.assigned);
    if (!alloc) return message.reply(fail('No free port', 'That node has no unassigned allocations.'));
    const environment = Object.fromEntries(egg.relationships.variables.data.map((v) => [v.attributes.env_variable, v.attributes.default_value]));
    const r = await api(g, 'app', 'POST', '/servers', { name, user: +user, egg: +eggId, docker_image: egg.docker_image, startup: egg.startup, environment,
      limits: { memory: +ram, swap: 0, disk: +disk, io: 500, cpu: +cpu }, feature_limits: { databases: 1, backups: 1, allocations: 1 }, allocation: { default: alloc.id } });
    plog(client, g, message.author, `Created server **${name}**`);
    return message.reply(ok('Server created', `**${r.attributes.name}** • ID \`${r.attributes.id}\` • \`${r.attributes.identifier}\` • port ${alloc.port}`));
  } }),
  def({ name: 'pterodelete', description: 'Delete a server', usage: 'pterodelete <id|identifier>', async run({ client, message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const id = await appServerId(message.guild.id, args[0]);
    if (!(await confirm(message, `Permanently delete server **${args[0]}** and its files?`))) return;
    await api(message.guild.id, 'app', 'DELETE', `/servers/${id}`); plog(client, message.guild.id, message.author, `Deleted server ${args[0]}`);
    return message.channel.send(ok('Server deleted'));
  } }),
  ...[['pterosuspend', 'suspend', 'Suspend'], ['pterounsuspend', 'unsuspend', 'Unsuspend'], ['pteroreinstall', 'reinstall', 'Reinstall']].map(([name, path, label]) => def({ name, description: `${label} a server`, usage: `${name} <id|identifier>`,
    async run({ client, message, args, prefix, cmd }) {
      if (!args[0]) return message.reply(usage(cmd, prefix));
      const id = await appServerId(message.guild.id, args[0]);
      if (path === 'reinstall' && !(await confirm(message, `Reinstall server **${args[0]}**? Its files will be reset.`))) return;
      await api(message.guild.id, 'app', 'POST', `/servers/${id}/${path}`); plog(client, message.guild.id, message.author, `${label} server ${args[0]}`);
      return message.channel.send(ok(`${label} requested`, args[0]));
    } })),
  def({ name: 'pteroresources', description: 'Panel-wide totals', usage: 'pteroresources', async run({ message }) {
    const t = async (p) => (await api(message.guild.id, 'app', 'GET', `${p}?per_page=1`)).meta.pagination.total;
    return message.reply(card({ title: '📊 Panel overview', fields: [['Users', await t('/users')], ['Servers', await t('/servers')], ['Nodes', await t('/nodes')], ['Nests', await t('/nests')]] }));
  } }),
  def({ name: 'pteroserverinfo', description: 'Full server details (admin)', usage: 'pteroserverinfo <id|identifier>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const s = (await api(message.guild.id, 'app', 'GET', `/servers/${await appServerId(message.guild.id, args[0])}`)).attributes;
    return message.reply(card({ title: `🦕 ${s.name}`, fields: [['ID', `${s.id} (\`${s.identifier}\`)`], ['Owner user', s.user], ['Node', s.node], ['Status', s.suspended ? 'Suspended' : (s.status ?? 'Active')], ['RAM', mb(s.limits.memory)], ['Disk', mb(s.limits.disk)], ['CPU', `${s.limits.cpu}%`], ['Created', s.created_at]] }));
  } }),
  def({ name: 'pterosearch', description: 'Search servers by name', usage: 'pterosearch <text>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const s = A(await api(message.guild.id, 'app', 'GET', `/servers?filter[name]=${encodeURIComponent(args.join(' '))}&per_page=20`));
    return message.reply(card({ title: `🔎 Results (${s.length})`, body: s.map((x) => `\`${x.id}\` **${x.name}** • \`${x.identifier}\`${x.suspended ? ' ⏸️' : ''}`).join('\n') || 'No servers found.' }));
  } }),

  // ---- Server control via Client API ----
  def({ lv: 1, name: 'pteroservers', description: 'List servers you can control', usage: 'pteroservers', async run({ message }) {
    const lv = level(message.member), l = db.prepare('SELECT client_key FROM ptero_links WHERE guild=? AND user=?').get(message.guild.id, message.author.id);
    if (lv < 2 && !l) throw new Error('NOT_LINKED_USER');
    const { dec } = await import('../../core/crypto.js');
    const r = await api(message.guild.id, 'client', 'GET', `/?per_page=50${lv >= 2 ? '&type=admin-all' : ''}`, null, lv < 2 ? dec(l.client_key) : undefined);
    return message.reply(card({ title: '🦕 Servers', body: A(r).map((s) => `\`${s.identifier}\` **${s.name}**${s.is_suspended ? ' ⏸️' : ''}`).join('\n') || 'None' }));
  } }),
  power('pterostart', 'start', 'Start'), power('pterostop', 'stop', 'Stop'), power('pterorestart', 'restart', 'Restart'), power('pterokill', 'kill', 'Kill', true),
  def({ lv: 1, name: 'pterocmd', description: 'Run a console command', usage: 'pterocmd <server> | <command>', async run({ client, message, args, prefix, cmd }) {
    const raw = args.join(' ').split('|'); if (raw.length < 2 || !raw[1].trim()) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, raw[0].trim());
    await api(gid, 'client', 'POST', `/servers/${srv.identifier}/command`, { command: raw.slice(1).join('|').trim() }, key);
    plog(client, gid, message.author, `Ran console command on **${srv.name}**: \`${clip(raw[1].trim(), 100)}\``);
    return message.reply(ok('Command sent', `\`${clip(raw[1].trim(), 100)}\` → **${srv.name}**`));
  } }),
  def({ lv: 1, name: 'pterostats', description: 'Live CPU / RAM / disk of a server', usage: 'pterostats <server>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, args.join(' '));
    const r = (await api(gid, 'client', 'GET', `/servers/${srv.identifier}/resources`, null, key)).attributes, u = r.resources;
    return message.reply(card({ title: `📊 ${srv.name}`, fields: [['State', r.current_state], ['CPU', `${u.cpu_absolute.toFixed(1)}%${srv.limits.cpu ? ` / ${srv.limits.cpu}%` : ''}`], ['RAM', `${bytes(u.memory_bytes)} / ${mb(srv.limits.memory)}`], ['Disk', `${bytes(u.disk_bytes)} / ${mb(srv.limits.disk)}`], ['Network', `↓ ${bytes(u.network_rx_bytes)}  ↑ ${bytes(u.network_tx_bytes)}`], ['Uptime', `${Math.floor(u.uptime / 60000)} min`]] }));
  } }),
  def({ lv: 1, name: 'pterofiles', description: 'List files in a directory', usage: 'pterofiles <server> [/dir]', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, args[0]), dir = args[1] ?? '/';
    const f = A(await api(gid, 'client', 'GET', `/servers/${srv.identifier}/files/list?directory=${encodeURIComponent(dir)}`, null, key));
    return message.reply(card({ title: `📁 ${srv.name} ${dir}`, body: clip(f.map((x) => `${x.is_file ? '📄' : '📁'} ${x.name}`).join('\n') || 'Empty', 1900) }));
  } }),
  def({ lv: 1, name: 'pterobackup', description: 'Create a backup', usage: 'pterobackup <server>', async run({ client, message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, args.join(' '));
    await api(gid, 'client', 'POST', `/servers/${srv.identifier}/backups`, {}, key); plog(client, gid, message.author, `Started backup of **${srv.name}**`);
    return message.reply(ok('Backup started', srv.name));
  } }),
  def({ lv: 1, name: 'pterobackups', description: 'List backups', usage: 'pterobackups <server>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, args.join(' '));
    const b = A(await api(gid, 'client', 'GET', `/servers/${srv.identifier}/backups`, null, key));
    return message.reply(card({ title: `💾 ${srv.name} backups`, body: b.map((x) => `\`${x.uuid.slice(0, 8)}\` ${x.name} • ${bytes(x.bytes)} • ${x.is_successful ? '✅' : '⏳'}`).join('\n') || 'No backups.' }));
  } }),
  def({ lv: 1, name: 'pterorestorebackup', description: 'Restore a backup (wipes current files)', usage: 'pterorestorebackup <server> <backup-id-prefix>', async run({ client, message, args, prefix, cmd }) {
    if (args.length < 2) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, args[0]);
    const b = A(await api(gid, 'client', 'GET', `/servers/${srv.identifier}/backups`, null, key)).find((x) => x.uuid.startsWith(args[1]));
    if (!b) return message.reply(fail('Not found', 'No backup with that ID prefix.'));
    if (!(await confirm(message, `Restore backup **${b.name}** on **${srv.name}**? Current files will be replaced.`))) return;
    await api(gid, 'client', 'POST', `/servers/${srv.identifier}/backups/${b.uuid}/restore`, { truncate: true }, key); plog(client, gid, message.author, `Restored backup on **${srv.name}**`);
    return message.channel.send(ok('Restore started', srv.name));
  } }),
  ...[['pterodbs', 'databases', '🗄️ Databases', (x) => `${x.name} • ${x.username}`], ['pteroschedules', 'schedules', '🗓️ Schedules', (x) => `${x.name} • ${x.is_active ? 'active' : 'off'}`], ['pterosubusers', 'users', '👥 Subusers', (x) => `${x.username} (${x.email})`], ['pteronetwork', 'network/allocations', '🔌 Network', (x) => `${x.ip_alias ?? x.ip}:${x.port}${x.is_default ? ' ⭐' : ''}`]]
    .map(([name, path, title, fmt]) => def({ lv: 1, name, description: `${title.replace(/^\S+ /, '')} of a server`, usage: `${name} <server>`, async run({ message, args, prefix, cmd }) {
      if (!args[0]) return message.reply(usage(cmd, prefix));
      const { srv, key, gid } = await resolveServer(message, args.join(' '));
      return message.reply(card({ title: `${title} • ${srv.name}`, body: clip(A(await api(gid, 'client', 'GET', `/servers/${srv.identifier}/${path}`, null, key)).map(fmt).join('\n') || 'None', 1900) }));
    } })),
  def({ lv: 1, name: 'pterorename', description: 'Rename a server', usage: 'pterorename <server> | <new name>', async run({ client, message, args, prefix, cmd }) {
    const p = args.join(' ').split('|'); if (p.length < 2 || !p[1].trim()) return message.reply(usage(cmd, prefix));
    const { srv, key, gid } = await resolveServer(message, p[0].trim());
    await api(gid, 'client', 'POST', `/servers/${srv.identifier}/settings/rename`, { name: p[1].trim() }, key); plog(client, gid, message.author, `Renamed **${srv.name}** → ${p[1].trim()}`);
    return message.reply(ok('Renamed', p[1].trim()));
  } }),

  // ---- Customer linking ----
  def({ lv: 0, name: 'pterolink', description: 'Link your own panel account (via DM)', usage: 'pterolink', async run({ message }) {
    if (!cfgOf(message.guild.id)?.url) throw new Error('NOT_LINKED');
    pending.set(message.author.id, { guild: message.guild.id, mode: 'user', until: Date.now() + 600000 });
    return keyDM(message, 'Send your **Client API key** (`ptlc_…`). Create one in the panel under Account → API Credentials. You will only be able to control servers your own account can access.');
  } }),
  def({ lv: 0, name: 'pterounlink', description: 'Remove your linked panel key', usage: 'pterounlink', async run({ message }) {
    const r = db.prepare('DELETE FROM ptero_links WHERE guild=? AND user=?').run(message.guild.id, message.author.id);
    return message.reply(r.changes ? ok('Unlinked', 'Your key was deleted.') : warn('Nothing to unlink'));
  } }),
  def({ lv: 0, name: 'pteromyservers', description: 'Your servers on the panel', usage: 'pteromyservers', async run({ message }) {
    const l = db.prepare('SELECT client_key FROM ptero_links WHERE guild=? AND user=?').get(message.guild.id, message.author.id); if (!l) throw new Error('NOT_LINKED_USER');
    const { dec } = await import('../../core/crypto.js');
    const r = A(await api(message.guild.id, 'client', 'GET', '/?per_page=50', null, dec(l.client_key)));
    return message.reply(card({ title: '🦕 My servers', body: r.map((s) => `\`${s.identifier}\` **${s.name}**`).join('\n') || 'No servers.' }));
  } }),
];
