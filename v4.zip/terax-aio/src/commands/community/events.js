import { PermissionFlagsBits as P, GuildScheduledEventPrivacyLevel, GuildScheduledEventEntityType } from 'discord.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { parseDuration, fmtDuration, clip, ts } from '../../core/util.js';

const C = { category: 'community', cooldown: 5, perms: [P.ManageEvents], botPerms: [P.ManageEvents] };
export default [
  { ...C, name: 'eventcreate', description: 'Create a Discord scheduled event', usage: 'eventcreate <starts in 1h|2d> <length 2h> <name> [| location]', async run({ message, args, prefix, cmd }) {
    const start = parseDuration(args[0]), len = parseDuration(args[1]), [name, ...loc] = args.slice(2).join(' ').split('|'); if (!start || !len || !name?.trim()) return message.reply(usage(cmd, prefix));
    if (start < 60000 || len > 6048e5) return message.reply(fail('Invalid time', 'Start at least 1 minute from now; max length 7 days.'));
    const e = await message.guild.scheduledEvents.create({ name: clip(name.trim(), 100), scheduledStartTime: new Date(Date.now() + start), scheduledEndTime: new Date(Date.now() + start + len), privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly, entityType: GuildScheduledEventEntityType.External, entityMetadata: { location: clip(loc.join('|').trim() || 'Discord', 100) } });
    return message.reply(ok('Event created', `**${e.name}** starts ${ts(e.scheduledStartTimestamp)} • lasts ${fmtDuration(len)}\n${e.url}`));
  } },
  { ...C, perms: [], name: 'eventlist', aliases: ['schedule'], description: 'Upcoming server events', usage: 'eventlist', async run({ message }) {
    const ev = await message.guild.scheduledEvents.fetch(); return message.reply(card({ title: `📅 Events (${ev.size})`, body: ev.map((e) => `\`${e.id}\` **${clip(e.name, 50)}** — ${ts(e.scheduledStartTimestamp)}`).join('\n') || 'No scheduled events.' }));
  } },
  { ...C, name: 'eventend', description: 'Delete a scheduled event', usage: 'eventend <eventId>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix)); const e = await message.guild.scheduledEvents.fetch(args[0]).catch(() => null); if (!e) return message.reply(fail('Event not found')); await e.delete(); return message.reply(ok('Event deleted', e.name));
  } },
];
