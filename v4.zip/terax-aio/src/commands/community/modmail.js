import { PermissionFlagsBits as P, ChannelType } from 'discord.js';
import { kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { buildTranscript } from '../../core/tickets.js';
import { tryDM } from '../../core/dm.js';
import { AttachmentBuilder } from 'discord.js';
import { getRole, getChannel, idOf, clip } from '../../core/util.js';

const C = { category: 'community', cooldown: 3 };
export default [
  { ...C, name: 'modmailsetup', description: 'Configure modmail (members DM the bot)', usage: 'modmailsetup <category <id>|role <@role>|log <#channel>|off>', perms: [P.ManageGuild], async run({ message, args, prefix }) {
    const g = message.guild.id, [sub, ...rest] = args, v = rest.join(' ');
    if (sub === 'category') { const c = message.guild.channels.cache.get(idOf(v)); if (c?.type !== ChannelType.GuildCategory) return message.reply(fail('Invalid category', 'Give a category ID.')); kvSet(g, 'mm_category', c.id); return message.reply(ok('Modmail category', c.name)); }
    if (sub === 'role') { const r = getRole(message, v); if (!r) return message.reply(fail('Invalid role')); kvSet(g, 'mm_role', r.id); return message.reply(ok('Modmail staff role', r.name)); }
    if (sub === 'log') { const c = getChannel(message, v); if (!c?.isTextBased()) return message.reply(fail('Invalid channel')); kvSet(g, 'mm_log', c.id); return message.reply(ok('Modmail log', `<#${c.id}>`)); }
    if (sub === 'off') { kvSet(g, 'mm_category', null); return message.reply(ok('Modmail disabled')); }
    return message.reply(card({ title: '📬 Modmail', body: `Members DM the bot and a private staff channel opens. Members always start the conversation; staff replies are mirrored by DM.\nUse \`${prefix}modmailsetup category <id>\`, \`role @staff\` and \`log #channel\`.`, fields: [['Category', kvGet(g, 'mm_category') ? `<#${kvGet(g, 'mm_category')}>` : 'Not set'], ['Staff role', kvGet(g, 'mm_role') ? `<@&${kvGet(g, 'mm_role')}>` : 'Not set'], ['Log', kvGet(g, 'mm_log') ? `<#${kvGet(g, 'mm_log')}>` : 'Not set']] }));
  } },
  { ...C, name: 'modmail', description: 'Modmail status', usage: 'modmail', perms: [P.ManageMessages], async run({ message }) {
    const c = kvGet(message.guild.id, 'mm_category'); return message.reply(card({ title: '📬 Modmail', body: c ? `Enabled • category <#${c}>\nMembers can DM me to contact staff.` : 'Not set up. Use `modmailsetup`.' }));
  } },
  { ...C, name: 'modmailclose', description: 'Close this modmail thread', usage: 'modmailclose [reason]', perms: [P.ManageMessages], async run({ client, message, args }) {
    const g = message.guild.id, uid = kvGet(g, `mm:chan:${message.channel.id}`); if (!uid) return message.reply(fail('Not a modmail channel'));
    const reason = clip(args.join(' ') || 'No reason given', 300), text = await buildTranscript(message.channel), log = kvGet(g, 'mm_log') && await client.channels.fetch(kvGet(g, 'mm_log')).catch(() => null);
    if (log?.isTextBased()) { await log.send(card({ title: '📪 Modmail closed', color: 'warning', fields: [['User', `<@${uid}>`], ['Closed by', `<@${message.author.id}>`], ['Reason', reason]] })).catch(() => {}); await log.send({ files: [new AttachmentBuilder(Buffer.from(text || 'Empty'), { name: `modmail-${uid}.txt` })] }).catch(() => {}); }
    const user = await client.users.fetch(uid).catch(() => null); if (user) await tryDM(user, card({ title: '📪 Conversation closed', body: `Staff closed this conversation.\nReason: ${reason}\nDM me again any time to open a new one.`, color: 'warning' }));
    kvSet(g, `mm:user:${uid}`, null); kvSet(g, `mm:chan:${message.channel.id}`, null);
    await message.channel.send(card({ title: '🔒 Closing', body: 'This channel will be deleted in 5 seconds.', color: 'warning' })); setTimeout(() => message.channel.delete().catch(() => {}), 5000);
  } },
];
