import { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits as P } from 'discord.js';
import { db, kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { endGiveaway } from '../../core/scheduler.js';
import { parseDuration, fmtDuration, getMember, getChannel, clip, ts } from '../../core/util.js';

const C = { category: 'community', cooldown: 3 };
const ADM = { ...C, perms: [P.ManageGuild] };
const g = (m) => m.guild.id;
const chanSetting = (name, key, desc, extra) => ({ ...ADM, name, description: desc, usage: `${name} <#channel|off>`, async run({ message, args, prefix, cmd }) {
  const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix));
  kvSet(g(message), key, c?.id ?? null); if (extra) extra(message, c, args); return message.reply(ok(name, c ? `<#${c.id}>` : 'Disabled'));
} });
const perChannelToggle = (name, key, desc) => ({ ...ADM, name, description: desc, usage: `${name} <#channel|off>`, async run({ message, args, prefix, cmd }) {
  const c = getChannel(message, args[0]) ?? (args[0] === 'off' ? message.channel : null); if (!c) return message.reply(usage(cmd, prefix));
  kvSet(g(message), `${key}:${c.id}`, args[0] === 'off' ? null : '1'); return message.reply(ok(name, `<#${c.id}> ${args[0] === 'off' ? 'disabled' : 'enabled'}`));
} });

export default [
  // ---- Giveaways ----
  { ...ADM, name: 'gstart', description: 'Start a giveaway', usage: 'gstart <duration e.g. 1h> <winners> <prize>', async run({ message, args, prefix, cmd }) {
    const ms = parseDuration(args[0]), w = parseInt(args[1]), prize = clip(args.slice(2).join(' '), 150);
    if (!ms || ms < 10000 || ms > 2592e6 || !(w >= 1 && w <= 20) || !prize) return message.reply(usage(cmd, prefix));
    const ends = Date.now() + ms, id = Number(db.prepare('INSERT INTO giveaways(guild,channel,message,prize,winners,host,ends) VALUES (?,?,?,?,?,?,?)').run(g(message), message.channel.id, '0', prize, w, message.author.id, ends).lastInsertRowid);
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`gw:${id}`).setLabel('Enter').setEmoji('🎉').setStyle(ButtonStyle.Success));
    const m = await message.channel.send(card({ title: `🎉 ${prize}`, body: `Press the button to enter!\nEnds ${ts(ends)}`, fields: [['Winners', w], ['Hosted by', `<@${message.author.id}>`], ['ID', id]], rows: [row] }));
    db.prepare('UPDATE giveaways SET message=? WHERE id=?').run(m.id, id); await message.delete().catch(() => {});
  } },
  { ...ADM, name: 'gend', description: 'End a giveaway now', usage: 'gend <id>', async run({ client, message, args, prefix, cmd }) {
    const row = db.prepare('SELECT * FROM giveaways WHERE id=? AND guild=? AND ended=0').get(parseInt(args[0]), g(message)); if (!row) return message.reply(args[0] ? fail('No active giveaway with that ID') : usage(cmd, prefix));
    await endGiveaway(client, row.id);
  } },
  { ...ADM, name: 'greroll', description: 'Pick new winners for an ended giveaway', usage: 'greroll <id>', async run({ client, message, args, prefix, cmd }) {
    const row = db.prepare('SELECT * FROM giveaways WHERE id=? AND guild=? AND ended=1').get(parseInt(args[0]), g(message)); if (!row) return message.reply(args[0] ? fail('No ended giveaway with that ID') : usage(cmd, prefix));
    await endGiveaway(client, row.id);
  } },
  { ...ADM, name: 'gdelete', description: 'Delete a giveaway', usage: 'gdelete <id>', async run({ client, message, args, prefix, cmd }) {
    const row = db.prepare('SELECT * FROM giveaways WHERE id=? AND guild=?').get(parseInt(args[0]), g(message)); if (!row) return message.reply(args[0] ? fail('Not found') : usage(cmd, prefix));
    const ch = await client.channels.fetch(row.channel).catch(() => null); await ch?.messages.delete(row.message).catch(() => {});
    db.prepare('DELETE FROM giveaways WHERE id=?').run(row.id); db.prepare('DELETE FROM gw_entries WHERE gid=?').run(row.id); return message.reply(ok('Giveaway deleted'));
  } },
  { ...C, name: 'glist', description: 'Active giveaways', usage: 'glist', async run({ message }) {
    const r = db.prepare('SELECT * FROM giveaways WHERE guild=? AND ended=0').all(g(message));
    return message.reply(card({ title: '🎉 Active giveaways', body: r.map((x) => `\`${x.id}\` **${x.prize}** — ends ${ts(x.ends)} (<#${x.channel}>)`).join('\n') || 'None.' }));
  } },
  { ...ADM, name: 'gedit', description: 'Change a giveaway prize', usage: 'gedit <id> <new prize>', async run({ client, message, args, prefix, cmd }) {
    const row = db.prepare('SELECT * FROM giveaways WHERE id=? AND guild=? AND ended=0').get(parseInt(args[0]), g(message)), prize = clip(args.slice(1).join(' '), 150); if (!row || !prize) return message.reply(usage(cmd, prefix));
    db.prepare('UPDATE giveaways SET prize=? WHERE id=?').run(prize, row.id);
    const m = await (await client.channels.fetch(row.channel).catch(() => null))?.messages.fetch(row.message).catch(() => null);
    await m?.edit(card({ title: `🎉 ${prize}`, body: `Press the button to enter!\nEnds ${ts(row.ends)}`, fields: [['Winners', row.winners], ['Hosted by', `<@${row.host}>`], ['ID', row.id]], rows: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`gw:${row.id}`).setLabel('Enter').setEmoji('🎉').setStyle(ButtonStyle.Success))] })).catch(() => {});
    return message.reply(ok('Prize updated', prize));
  } },
  // ---- Polls / dates ----
  { ...C, name: 'poll', description: 'Create a reaction poll (up to 9 options)', usage: 'poll <question> | <option 1> | <option 2> ...', perms: [P.ManageMessages], async run({ message, args, prefix, cmd }) {
    const p = args.join(' ').split('|').map((x) => x.trim()).filter(Boolean); if (p.length < 3 || p.length > 10) return message.reply(usage(cmd, prefix));
    const e = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'], m = await message.channel.send(card({ title: `📊 ${clip(p[0], 200)}`, body: p.slice(1).map((o, i) => `${e[i]} ${clip(o, 100)}`).join('\n') }));
    for (let i = 0; i < p.length - 1; i++) await m.react(e[i]); await message.delete().catch(() => {});
  } },
  { ...C, name: 'countdown', description: 'Countdown to a date', usage: 'countdown <YYYY-MM-DD> [HH:mm]', async run({ message, args, prefix, cmd }) {
    const d = new Date(`${args[0]}T${args[1] ?? '00:00'}:00Z`); if (isNaN(d)) return message.reply(usage(cmd, prefix));
    return message.reply(card({ title: '⏳ Countdown', body: `${ts(d.getTime(), 'F')} (UTC) — ${ts(d.getTime())}` }));
  } },
  { ...C, name: 'setbirthday', description: 'Set your birthday', usage: 'setbirthday <DD/MM>', async run({ message, args, prefix, cmd }) {
    const m = /^(\d{1,2})\/(\d{1,2})$/.exec(args[0] ?? ''); if (!m || +m[1] < 1 || +m[1] > 31 || +m[2] < 1 || +m[2] > 12) return message.reply(usage(cmd, prefix));
    db.prepare('INSERT OR REPLACE INTO birthdays VALUES (?,?,?,?)').run(g(message), message.author.id, +m[1], +m[2]); return message.reply(ok('Birthday saved', `${m[1]}/${m[2]}`));
  } },
  { ...C, name: 'birthday', description: 'Show a birthday', usage: 'birthday [member]', async run({ message, args }) {
    const t = (await getMember(message, args[0])) ?? message.member, r = db.prepare('SELECT * FROM birthdays WHERE guild=? AND user=?').get(g(message), t.id);
    return message.reply(r ? card({ title: `🎂 ${t.displayName}`, body: `${r.day}/${r.month}` }) : fail('No birthday saved'));
  } },
  { ...C, name: 'birthdays', description: 'Upcoming birthdays', usage: 'birthdays', async run({ message }) {
    const now = new Date(), key = (r) => { const d = new Date(now.getFullYear(), r.month - 1, r.day); if (d < new Date(now.getFullYear(), now.getMonth(), now.getDate())) d.setFullYear(d.getFullYear() + 1); return d; };
    const r = db.prepare('SELECT * FROM birthdays WHERE guild=?').all(g(message)).sort((a, b) => key(a) - key(b)).slice(0, 10);
    return message.reply(card({ title: '🎂 Upcoming birthdays', body: r.map((x) => `<@${x.user}> — ${x.day}/${x.month}`).join('\n') || 'None saved.' }));
  } },
  // ---- Social / server features ----
  chanSetting('starboardset', 'star_channel', 'Set the starboard channel', (m, c, a) => { if (+a[1] >= 1) kvSet(g(m), 'star_min', +a[1]); }),
  { ...C, name: 'starboard', description: 'Starboard settings', usage: 'starboard', async run({ message }) {
    const c = kvGet(g(message), 'star_channel'); return message.reply(card({ title: '⭐ Starboard', body: c ? `Channel: <#${c}>\nNeeds **${kvGet(g(message), 'star_min') ?? 3}** ⭐` : 'Not set. Use `starboardset #channel [stars]`.' }));
  } },
  chanSetting('confessionsetup', 'conf_channel', 'Set the anonymous confession channel'),
  { ...C, name: 'confession', description: 'Post an anonymous confession', usage: 'confession <text>', cooldown: 60, async run({ message, args, prefix, cmd }) {
    const ch = kvGet(g(message), 'conf_channel'), t = clip(args.join(' '), 1500); if (!ch) return message.reply(fail('Not set up', 'An admin must run `confessionsetup`.')); if (!t) return message.reply(usage(cmd, prefix));
    await message.delete().catch(() => {}); const n = +(kvGet(g(message), 'conf_n') ?? 0) + 1; kvSet(g(message), 'conf_n', n); kvSet(g(message), `conf:${n}`, message.author.id);
    const c = await message.client.channels.fetch(ch).catch(() => null); await c?.send(card({ title: `🤫 Confession #${n}`, body: t, foot: false, color: 'mod' }));
    const r = await message.channel.send(ok('Confession sent', 'It is anonymous to members. Staff can trace abuse.')); setTimeout(() => r.delete().catch(() => {}), 4000);
  } },
  { ...ADM, name: 'confessionwho', description: 'Trace a confession (staff, for abuse)', usage: 'confessionwho <number>', async run({ message, args, prefix, cmd }) {
    const u = kvGet(g(message), `conf:${parseInt(args[0])}`); if (!args[0]) return message.reply(usage(cmd, prefix)); return message.reply(u ? card({ title: `Confession #${parseInt(args[0])}`, body: `Author: <@${u}>` }) : fail('Not found'));
  } },
  chanSetting('countingsetup', 'count_channel', 'Set the counting channel', (m) => kvSet(g(m), 'count_state', JSON.stringify({ n: 0, u: null }))),
  { ...C, name: 'counting', description: 'Current count', usage: 'counting', async run({ message }) {
    const s = JSON.parse(kvGet(g(message), 'count_state') ?? '{"n":0}'); return message.reply(card({ title: '🔢 Counting', body: `Current count: **${s.n}**${kvGet(g(message), 'count_channel') ? `\nChannel: <#${kvGet(g(message), 'count_channel')}>` : ''}` }));
  } },
  { ...C, name: 'tag', description: 'Show a tag', usage: 'tag <name>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix)); const t = kvGet(g(message), `tag:${args[0].toLowerCase()}`); return message.reply(t ? card({ title: `🏷️ ${args[0].toLowerCase()}`, body: t, foot: false }) : fail('No such tag'));
  } },
  { ...C, name: 'tagcreate', description: 'Create a tag', usage: 'tagcreate <name> <content>', perms: [P.ManageMessages], async run({ message, args, prefix, cmd }) {
    if (args.length < 2 || args[0].length > 30) return message.reply(usage(cmd, prefix)); kvSet(g(message), `tag:${args[0].toLowerCase()}`, clip(args.slice(1).join(' '), 1500)); return message.reply(ok('Tag saved', args[0].toLowerCase()));
  } },
  { ...C, name: 'tagdelete', description: 'Delete a tag', usage: 'tagdelete <name>', perms: [P.ManageMessages], async run({ message, args }) {
    const r = db.prepare('DELETE FROM kv WHERE guild=? AND k=?').run(g(message), `tag:${(args[0] ?? '').toLowerCase()}`); return message.reply(r.changes ? ok('Tag deleted') : fail('No such tag'));
  } },
  { ...C, name: 'taglist', description: 'List tags', usage: 'taglist', async run({ message }) {
    const r = db.prepare("SELECT k FROM kv WHERE guild=? AND k LIKE 'tag:%'").all(g(message)); return message.reply(card({ title: '🏷️ Tags', body: r.map((x) => `\`${x.k.slice(4)}\``).join(' ') || 'No tags yet.' }));
  } },
  { ...ADM, name: 'sticky', description: 'Keep a message at the bottom of this channel', usage: 'sticky <text>', async run({ message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); kvSet(g(message), `sticky:${message.channel.id}`, clip(args.join(' '), 1500)); return message.reply(ok('Sticky set', 'It will re-post after each new message.'));
  } },
  { ...ADM, name: 'unsticky', description: 'Remove the sticky message', usage: 'unsticky', async run({ message }) {
    kvSet(g(message), `sticky:${message.channel.id}`, null); kvSet(g(message), `stickyid:${message.channel.id}`, null); return message.reply(ok('Sticky removed'));
  } },
  ...['approve', 'deny'].map((name) => ({ ...ADM, name, description: `${name[0].toUpperCase() + name.slice(1)} a suggestion by message ID`, usage: `${name} <suggestion message ID> [reason]`, async run({ message, args, prefix, cmd }) {
    const ch = kvGet(g(message), 'suggest_channel'), c = ch && await message.client.channels.fetch(ch).catch(() => null), m = c && args[0] && await c.messages.fetch(args[0]).catch(() => null);
    if (!args[0]) return message.reply(usage(cmd, prefix)); if (!m) return message.reply(fail('Not found', 'No suggestion with that message ID.'));
    const text = kvGet(g(message), `sug:${m.id}`) ?? '(suggestion)'; await m.edit(card({ title: name === 'approve' ? '✅ Suggestion approved' : '❌ Suggestion denied', body: `${text}\n\n**Staff:** ${clip(args.slice(1).join(' ') || 'No reason given', 300)}`, color: name === 'approve' ? 'success' : 'error' }));
    return message.reply(ok(`Suggestion ${name}d`));
  } })),
  perChannelToggle('autothread', 'autothread', 'Auto-create a thread for each message'),
  perChannelToggle('autopublish', 'autopublish', 'Auto-publish messages in an announcement channel'),
  { ...C, name: 'rules', description: 'Show or set the server rules', usage: 'rules [set <text>]', async run({ message, args }) {
    if (args[0] === 'set') { if (!message.member.permissions.has(P.ManageGuild)) return message.reply(fail('Missing permissions')); kvSet(g(message), 'rules', clip(args.slice(1).join(' '), 1800)); return message.reply(ok('Rules saved')); }
    return message.reply(card({ title: '📜 Server rules', body: kvGet(g(message), 'rules') ?? 'No rules set. Admins can use `rules set <text>`.' }));
  } },
  { ...C, name: 'todo', description: 'Your to-do list', usage: 'todo', async run({ message }) {
    const r = db.prepare('SELECT * FROM todos WHERE guild=? AND user=? ORDER BY id LIMIT 25').all(g(message), message.author.id); return message.reply(card({ title: '📝 To-do', body: r.map((x) => `${x.done ? '✅' : '⬜'} \`${x.id}\` ${clip(x.text, 80)}`).join('\n') || 'Nothing here. Add with `todoadd`.' }));
  } },
  { ...C, name: 'todoadd', description: 'Add a to-do', usage: 'todoadd <text>', async run({ message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); if (db.prepare('SELECT COUNT(*) c FROM todos WHERE guild=? AND user=?').get(g(message), message.author.id).c >= 25) return message.reply(fail('Limit reached', 'Max 25 items.'));
    const id = db.prepare('INSERT INTO todos(guild,user,text) VALUES (?,?,?)').run(g(message), message.author.id, clip(args.join(' '), 200)).lastInsertRowid; return message.reply(ok('Added', `\`${id}\` ${clip(args.join(' '), 80)}`));
  } },
  { ...C, name: 'tododone', description: 'Complete (and remove) a to-do', usage: 'tododone <id>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM todos WHERE id=? AND guild=? AND user=?').run(parseInt(args[0]), g(message), message.author.id); return message.reply(r.changes ? ok('Done! 🎉') : fail('Not found'));
  } },
  { ...C, name: 'marry', description: 'Propose to someone', usage: 'marry <member>', cooldown: 10, async run({ message, args, prefix, cmd }) {
    const t = await getMember(message, args[0]); if (!t || t.user.bot || t.id === message.author.id) return message.reply(usage(cmd, prefix));
    const has = (id) => db.prepare('SELECT 1 FROM marriages WHERE guild=? AND (a=? OR b=?)').get(g(message), id, id); if (has(message.author.id) || has(t.id)) return message.reply(fail('Already married', 'One of you is already married.'));
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('mr:y').setLabel('Accept').setEmoji('💍').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('mr:n').setLabel('Decline').setStyle(ButtonStyle.Secondary));
    const m = await message.reply({ ...card({ title: '💍 Proposal', body: `<@${t.id}>, will you marry **${message.member.displayName}**?`, rows: [row] }), allowedMentions: { users: [t.id] } });
    try { const i = await m.awaitMessageComponent({ filter: (x) => x.user.id === t.id, time: 60000 });
      if (i.customId === 'mr:y') { db.prepare('INSERT INTO marriages VALUES (?,?,?,?)').run(g(message), message.author.id, t.id, Date.now()); return i.update(card({ title: '💒 Married!', body: `**${message.member.displayName}** and **${t.displayName}** are now married!`, color: 'success' })); }
      return i.update(card({ title: '💔 Declined', color: 'error' }));
    } catch { return m.edit(warn('No answer', 'The proposal expired.')).catch(() => {}); }
  } },
  { ...C, name: 'divorce', description: 'End your marriage', usage: 'divorce', async run({ message }) {
    const r = db.prepare('DELETE FROM marriages WHERE guild=? AND (a=? OR b=?)').run(g(message), message.author.id, message.author.id); return message.reply(r.changes ? ok('Divorced') : fail('You are not married'));
  } },
  { ...C, name: 'family', description: 'Show your marriage', usage: 'family [member]', async run({ message, args }) {
    const t = (await getMember(message, args[0])) ?? message.member, r = db.prepare('SELECT * FROM marriages WHERE guild=? AND (a=? OR b=?)').get(g(message), t.id, t.id);
    return message.reply(r ? card({ title: `💞 ${t.displayName}`, body: `Married to <@${r.a === t.id ? r.b : r.a}> since ${ts(r.at)}` }) : card({ title: `👤 ${t.displayName}`, body: 'Not married.' }));
  } },
];
