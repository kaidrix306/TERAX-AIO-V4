import { inspect } from 'node:util';
import { config, env, saveConfig } from '../../core/config.js';
import { db } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { clip, fmtDuration, idOf } from '../../core/util.js';
import { loadCommands } from '../../core/loader.js';
import { restartStatus } from '../../core/status.js';

const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
const O = { category: 'owner', ownerOnly: true };

export default [
  { ...O, name: 'eval', aliases: ['ev'], description: 'Run JavaScript (owner only)', usage: 'eval <code>',
    async run({ client, message, args, prefix, cmd }) {
      if (!args.length) return message.reply(usage(cmd, prefix));
      const code = args.join(' ').replace(/^```(?:js)?\n?|```$/g, '');
      try {
        const fn = new AsyncFunction('client', 'message', 'db', 'config', /return|;/.test(code) ? code : `return (${code})`);
        let out = await fn(client, message, db, config);
        out = typeof out === 'string' ? out : inspect(out, { depth: 1 });
        if (env.token) out = out.split(env.token).join('[redacted]');
        return message.reply(card({ title: '🧪 Eval', body: '```js\n' + clip(out, 1900) + '\n```', color: 'success' }));
      } catch (e) { return message.reply(card({ title: '🧪 Eval error', body: '```\n' + clip(e.message, 1900) + '\n```', color: 'error' })); }
    } },
  { ...O, name: 'reload', aliases: ['rl'], description: 'Reload all commands', usage: 'reload',
    async run({ client, message }) { const n = await loadCommands(client); return message.reply(ok('Reloaded', `${n} commands loaded.`)); } },
  { ...O, name: 'blacklist', aliases: ['bl'], description: 'Blacklist a user or server', usage: 'blacklist <user|guild> <id> [reason]',
    async run({ message, args, prefix, cmd }) {
      const [type, id, ...r] = args;
      if (!['user', 'guild'].includes(type) || !/^\d{15,22}$/.test(idOf(id))) return message.reply(usage(cmd, prefix));
      db.prepare('INSERT OR REPLACE INTO blacklist(id,type,reason) VALUES (?,?,?)').run(idOf(id), type, r.join(' ') || 'No reason');
      return message.reply(ok('Blacklisted', `${type} \`${idOf(id)}\``));
    } },
  { ...O, name: 'unblacklist', aliases: ['ubl'], description: 'Remove a blacklist entry', usage: 'unblacklist <id>',
    async run({ message, args, prefix, cmd }) {
      if (!args[0]) return message.reply(usage(cmd, prefix));
      const r = db.prepare('DELETE FROM blacklist WHERE id=?').run(idOf(args[0]));
      return message.reply(r.changes ? ok('Removed', `\`${idOf(args[0])}\` is no longer blacklisted.`) : fail('Not found', 'That ID is not blacklisted.'));
    } },
  { ...O, name: 'servers', aliases: ['serverlist'], description: 'List servers the bot is in', usage: 'servers',
    async run({ client, message }) {
      const list = client.guilds.cache.map((g) => `${g.name} — \`${g.id}\` (${g.memberCount})`).join('\n');
      return message.reply(card({ title: `🌐 Servers (${client.guilds.cache.size})`, body: clip(list, 2000) }));
    } },
  { ...O, name: 'leaveserver', aliases: ['leaveguild'], description: 'Make the bot leave a server', usage: 'leaveserver <id>',
    async run({ client, message, args, prefix, cmd }) {
      const g = client.guilds.cache.get(idOf(args[0]));
      if (!g) return message.reply(args[0] ? fail('Not found', 'I am not in that server.') : usage(cmd, prefix));
      await g.leave(); return message.reply(ok('Left server', g.name));
    } },
  { ...O, name: 'allowguild', aliases: ['ag'], description: 'Add a server ID to the whitelist', usage: 'allowguild <id>',
    async run({ message, args, prefix, cmd }) {
      const id = idOf(args[0]);
      if (!/^\d{15,22}$/.test(id)) return message.reply(usage(cmd, prefix));
      if (!config.allowedGuilds.includes(id)) { config.allowedGuilds.push(id); saveConfig(); }
      return message.reply(ok('Server allowed', `\`${id}\` can now use the bot.`));
    } },
  { ...O, name: 'disallowguild', aliases: ['dag'], description: 'Remove a server from the whitelist (bot leaves it)', usage: 'disallowguild <id>',
    async run({ client, message, args, prefix, cmd }) {
      const id = idOf(args[0]);
      if (!/^\d{15,22}$/.test(id)) return message.reply(usage(cmd, prefix));
      config.allowedGuilds = config.allowedGuilds.filter((x) => x !== id); saveConfig();
      await client.guilds.cache.get(id)?.leave().catch(() => {});
      return message.reply(ok('Server removed', `\`${id}\` is no longer whitelisted.`));
    } },
  { ...O, name: 'allowedguilds', aliases: ['ags'], description: 'Show whitelisted server IDs', usage: 'allowedguilds',
    async run({ message }) { return message.reply(card({ title: '📋 Whitelisted servers', body: `Mode: **${config.allowAllServers ? 'ALL servers (whitelist off)' : 'whitelist only'}**\n` + (config.allowedGuilds.map((x) => `\`${x}\``).join('\n') || 'No IDs listed') })); } },
  { ...O, name: 'setstatus', description: 'Change the bot status text', usage: 'setstatus <text>',
    async run({ client, message, args, prefix, cmd }) {
      if (!args.length) return message.reply(usage(cmd, prefix));
      config.status.text = args.join(' '); config.statusRotate ??= {}; config.statusRotate.enabled = false; saveConfig();
      restartStatus(client);
      return message.reply(ok('Status pinned', `${config.status.text}\n-# Rotation is now off. Turn it back on with \`statusrotate on\`.`));
    } },
  { ...O, name: 'setname', description: 'Change the bot username', usage: 'setname <name>',
    async run({ client, message, args, prefix, cmd }) {
      if (!args.length) return message.reply(usage(cmd, prefix));
      await client.user.setUsername(args.join(' ')); return message.reply(ok('Name updated'));
    } },
  { ...O, name: 'setavatar', description: 'Change the bot avatar (URL or attachment)', usage: 'setavatar <url>',
    async run({ client, message, args, prefix, cmd }) {
      const url = args[0] || message.attachments.first()?.url;
      if (!url) return message.reply(usage(cmd, prefix));
      await client.user.setAvatar(url); return message.reply(ok('Avatar updated'));
    } },
  { ...O, name: 'maintenance', description: 'Toggle maintenance mode', usage: 'maintenance <on|off>',
    async run({ client, message, args, prefix, cmd }) {
      if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
      client.maintenance = args[0] === 'on'; return message.reply(ok('Maintenance', client.maintenance ? 'Enabled' : 'Disabled'));
    } },
  { ...O, name: 'stats', description: 'Bot statistics', usage: 'stats',
    async run({ client, message }) {
      return message.reply(card({ title: '📊 Stats', fields: [
        ['Servers', client.guilds.cache.size], ['Users', client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)],
        ['Commands', client.commands.size], ['Ping', `${client.ws.ping}ms`], ['Uptime', fmtDuration(Date.now() - client.startedAt)],
        ['Memory', `${(process.memoryUsage().rss / 1048576).toFixed(1)} MB`], ['Node', process.version]] }));
    } },
  { ...O, name: 'restart', description: 'Restart the bot (needs pm2/docker to relaunch)', usage: 'restart',
    async run({ message }) { await message.reply(ok('Restarting…')); process.exit(0); } },
  { ...O, name: 'shutdown', description: 'Shut the bot down', usage: 'shutdown',
    async run({ client, message }) { await message.reply(ok('Shutting down…')); await client.destroy(); process.exit(0); } },
];
