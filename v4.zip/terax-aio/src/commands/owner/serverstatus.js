import { config, saveConfig, isAllowed } from '../../core/config.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { confirm } from '../../core/ptero.js';
import { restartStatus, rotateNow, fillStatus } from '../../core/status.js';
import { clip } from '../../core/util.js';

const O = { category: 'owner', ownerOnly: true };
export default [
  { ...O, name: 'allowall', description: 'Switch between whitelist-only and all-servers mode', usage: 'allowall <on|off>', async run({ client, message, args, prefix, cmd }) {
    if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
    if (args[0] === 'on') { config.allowAllServers = true; saveConfig(); return message.reply(warn('All-servers mode ON', 'The whitelist is disabled: the bot now works in every server it is invited to. Turn it off any time with `allowall off`.')); }
    const wouldLeave = client.guilds.cache.filter((g) => !config.allowedGuilds.includes(g.id));
    if (wouldLeave.size && !(await confirm(message, `Whitelist mode will make me leave **${wouldLeave.size}** server(s) that are not in \`allowedGuilds\`. Continue?`))) return;
    config.allowAllServers = false; saveConfig(); for (const g of wouldLeave.values()) await g.leave().catch(() => {});
    return message.channel.send(ok('Whitelist mode ON', `Left ${wouldLeave.size} unlisted server(s). Only IDs in \`allowedGuilds\` work now.`));
  } },
  { ...O, name: 'statusrotate', aliases: ['statuses'], description: 'Rotating bot status', usage: 'statusrotate <list|on|off|now|interval <min>|add <text>|remove <n>>', async run({ client, message, args, prefix, cmd }) {
    config.statusRotate ??= { enabled: true, intervalMinutes: 15 }; config.statuses ??= []; const [sub, ...rest] = args, r = config.statusRotate;
    if (!sub || sub === 'list') return message.reply(card({ title: '🔄 Status rotation', fields: [['Rotation', r.enabled ? `On • every ${r.intervalMinutes} min` : 'Off'], ['Statuses', config.statuses.map((s, i) => `${i + 1}. ${clip(s, 60)}`).join('\n') || 'None (uses the pinned status)'], ['Placeholders', '{servers} {users} {commands} {prefix}']] }));
    if (sub === 'on' || sub === 'off') { r.enabled = sub === 'on'; saveConfig(); restartStatus(client); return message.reply(ok('Status rotation', sub)); }
    if (sub === 'now') { rotateNow(client); return message.reply(ok('Status changed')); }
    if (sub === 'interval') { const m = parseInt(rest[0]); if (!(m >= 1 && m <= 1440)) return message.reply(fail('Invalid interval', 'Pick 1 to 1440 minutes.')); r.intervalMinutes = m; saveConfig(); restartStatus(client); return message.reply(ok('Interval set', `Every ${m} minute(s).`)); }
    if (sub === 'add') { const t = rest.join(' ').trim(); if (!t || t.length > 128) return message.reply(usage(cmd, prefix)); if (config.statuses.length >= 20) return message.reply(fail('Limit reached', 'Max 20 statuses.')); config.statuses.push(t); saveConfig(); return message.reply(ok('Status added', fillStatus(client, t))); }
    if (sub === 'remove') { const n = parseInt(rest[0]); if (!(n >= 1 && n <= config.statuses.length)) return message.reply(fail('Invalid number')); const [x] = config.statuses.splice(n - 1, 1); saveConfig(); return message.reply(ok('Status removed', clip(x, 80))); }
    return message.reply(usage(cmd, prefix));
  } },
];
