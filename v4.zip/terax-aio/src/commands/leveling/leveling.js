import { PermissionFlagsBits as P } from 'discord.js';
import { db } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { need, lcfg, lrow, addXp, grantRoles } from '../../core/levels.js';
import { getMember, getRole, getChannel, parseDuration, fmtDuration, clip } from '../../core/util.js';

const L = { category: 'leveling', cooldown: 3 };
const A = { ...L, perms: [P.ManageGuild] };
const bar = (p) => '█'.repeat(Math.round(p * 12)) + '░'.repeat(12 - Math.round(p * 12));
const upd = (g, col, val) => { lcfg(g); db.prepare(`UPDATE level_cfg SET ${col}=? WHERE guild=?`).run(val, g); };
const toggle = (name, col, desc) => ({ ...A, name, description: desc, usage: `${name} <on|off>`, async run({ message, args, prefix, cmd }) {
  if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix)); upd(message.guild.id, col, args[0] === 'on' ? 1 : 0); return message.reply(ok(name, args[0]));
} });
const listOp = (name, col, desc, kind) => ({ ...A, name, description: desc, usage: `${name} <${kind === 'channel' ? '#channel' : '@role'}>`, async run({ message, args, prefix, cmd }) {
  const t = kind === 'channel' ? getChannel(message, args[0]) : getRole(message, args.join(' ')); if (!t) return message.reply(usage(cmd, prefix));
  const set = new Set(lcfg(message.guild.id)[col].split(',').filter(Boolean)); const had = set.delete(t.id); if (!had) set.add(t.id); upd(message.guild.id, col, [...set].join(','));
  return message.reply(ok(name, `${kind === 'channel' ? `<#${t.id}>` : t.name} is now ${had ? 'earning XP again' : 'excluded from XP'}.`));
} });
const setter = (name, desc, fn) => ({ ...A, name, description: desc, usage: `${name} <member> <amount>`, async run({ message, args, prefix, cmd }) {
  const m = await getMember(message, args[0]), n = parseInt(args[1]); if (!m || isNaN(n) || n < 0 || n > 100000) return message.reply(usage(cmd, prefix));
  await fn(message, m, n); const r = lrow(message.guild.id, m.id); return message.reply(ok(name, `${m.user.username} is now level **${r.level}** (${r.xp}/${need(r.level)} XP).`));
} });

export default [
  { ...L, name: 'rank', aliases: ['level', 'lvl'], description: 'Show your rank card', usage: 'rank [member]', async run({ message, args }) {
    const m = (await getMember(message, args[0])) ?? message.member, r = lrow(message.guild.id, m.id);
    const pos = db.prepare('SELECT COUNT(*) c FROM levels WHERE guild=? AND (level>? OR (level=? AND xp>?))').get(message.guild.id, r.level, r.level, r.xp).c + 1;
    return message.reply(card({ title: `⭐ ${m.user.username}`, thumb: m.displayAvatarURL(), color: lcfg(message.guild.id).color || 'info', body: `Level **${r.level}** • Rank **#${pos}**\n\`${bar(r.xp / need(r.level))}\` ${r.xp}/${need(r.level)} XP` }));
  } },
  { ...L, name: 'levels', aliases: ['leaderboard', 'top'], description: 'Server XP leaderboard', usage: 'levels', async run({ message }) {
    const r = db.prepare('SELECT * FROM levels WHERE guild=? ORDER BY level DESC, xp DESC LIMIT 10').all(message.guild.id);
    return message.reply(card({ title: '🏆 Leaderboard', body: r.map((x, i) => `**${i + 1}.** <@${x.user}> — level ${x.level} (${x.xp} XP)`).join('\n') || 'No one has XP yet.' }));
  } },
  setter('setlevel', 'Set a member level', (m, t, n) => { lrow(m.guild.id, t.id); db.prepare('UPDATE levels SET level=?, xp=0 WHERE guild=? AND user=?').run(n, m.guild.id, t.id); return grantRoles(m.guild, t.id, n); }),
  setter('setxp', 'Set a member XP within their level', (m, t, n) => { lrow(m.guild.id, t.id); db.prepare('UPDATE levels SET xp=? WHERE guild=? AND user=?').run(Math.min(n, need(lrow(m.guild.id, t.id).level) - 1), m.guild.id, t.id); }),
  setter('addxp', 'Add XP to a member', (m, t, n) => addXp(m.client, m.guild.id, t.id, n, m.channel)),
  { ...A, name: 'resetlevels', description: 'Reset all XP in this server', usage: 'resetlevels confirm', async run({ message, args }) {
    if (args[0] !== 'confirm') return message.reply(fail('Are you sure?', 'This deletes everyone\'s XP. Run `resetlevels confirm`.'));
    db.prepare('DELETE FROM levels WHERE guild=?').run(message.guild.id); return message.reply(ok('All levels reset'));
  } },
  { ...L, name: 'levelroles', description: 'Roles given at levels', usage: 'levelroles', async run({ message }) {
    const r = db.prepare('SELECT * FROM level_roles WHERE guild=? ORDER BY level').all(message.guild.id);
    return message.reply(card({ title: '🎖️ Level roles', body: r.map((x) => `Level **${x.level}** → <@&${x.role}>`).join('\n') || 'None set.' }));
  } },
  { ...A, name: 'addlevelrole', description: 'Give a role at a level', usage: 'addlevelrole <level> <@role>', botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const lv = parseInt(args[0]), r = getRole(message, args.slice(1).join(' ')); if (!(lv >= 1) || !r) return message.reply(usage(cmd, prefix));
    if (!r.editable) return message.reply(fail('Cannot', 'That role is above my top role.')); db.prepare('INSERT OR REPLACE INTO level_roles VALUES (?,?,?)').run(message.guild.id, lv, r.id); return message.reply(ok('Level role added', `Level ${lv} → ${r.name}`));
  } },
  { ...A, name: 'removelevelrole', description: 'Remove a level role', usage: 'removelevelrole <level>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM level_roles WHERE guild=? AND level=?').run(message.guild.id, parseInt(args[0])); return message.reply(r.changes ? ok('Removed') : fail('No role at that level'));
  } },
  { ...A, name: 'xpmultiplier', description: 'Set the server XP multiplier (0.1-5)', usage: 'xpmultiplier <number>', async run({ message, args, prefix, cmd }) {
    const n = parseFloat(args[0]); if (!(n >= 0.1 && n <= 5)) return message.reply(usage(cmd, prefix)); upd(message.guild.id, 'multiplier', n); return message.reply(ok('XP multiplier', `${n}×`));
  } },
  { ...A, name: 'xpboost', description: 'Temporary XP boost', usage: 'xpboost <multiplier> <duration e.g. 2h>', async run({ message, args, prefix, cmd }) {
    const n = parseFloat(args[0]), ms = parseDuration(args[1]); if (!(n >= 1.1 && n <= 5) || !ms) return message.reply(usage(cmd, prefix));
    upd(message.guild.id, 'boost_mult', n); upd(message.guild.id, 'boost_until', Date.now() + ms); return message.reply(ok('XP boost active', `${n}× for ${fmtDuration(ms)}`));
  } },
  toggle('voicexp', 'voicexp', 'Toggle XP for voice time (5 XP/min)'),
  toggle('levelup', 'announce', 'Toggle level-up announcements'),
  { ...A, name: 'levelchannel', description: 'Channel for level-up messages (off = same channel)', usage: 'levelchannel <#channel|off>', async run({ message, args, prefix, cmd }) {
    const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix)); upd(message.guild.id, 'channel', c?.id ?? null); return message.reply(ok('Level channel', c ? `<#${c.id}>` : 'Same channel'));
  } },
  { ...A, name: 'levelmsg', description: 'Level-up text. Use {user} and {level}', usage: 'levelmsg <text|reset>', async run({ message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); upd(message.guild.id, 'msg', args[0] === 'reset' ? null : clip(args.join(' '), 300)); return message.reply(ok('Level message saved'));
  } },
  listOp('noxpchannel', 'no_channels', 'Toggle a channel as no-XP', 'channel'),
  listOp('noxprole', 'no_roles', 'Toggle a role as no-XP', 'role'),
  { ...A, name: 'rankcolor', description: 'Rank card accent color (hex)', usage: 'rankcolor <#hex>', async run({ message, args, prefix, cmd }) {
    if (!/^#?[0-9a-f]{6}$/i.test(args[0] ?? '')) return message.reply(usage(cmd, prefix)); upd(message.guild.id, 'color', args[0].startsWith('#') ? args[0] : `#${args[0]}`); return message.reply(ok('Rank color saved'));
  } },
];
