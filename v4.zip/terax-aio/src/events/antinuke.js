import { AuditLogEvent as A } from 'discord.js';
import { isAllowed } from '../core/config.js';
import { secCfg, isTrusted, slog, raid } from '../core/security.js';

const counts = new Map();
async function who(guild, type, targetId) {
  await new Promise((r) => setTimeout(r, 900));
  const logs = await guild.fetchAuditLogs({ type, limit: 5 }).catch(() => null);
  const e = logs?.entries.find((x) => Date.now() - x.createdTimestamp < 8000 && (!targetId || x.target?.id === targetId));
  return e?.executor ?? null;
}
async function punish(client, guild, user, label) {
  const cfg = secCfg(guild.id), k = `${guild.id}:${user.id}`, now = Date.now(), t = (counts.get(k) ?? []).filter((x) => now - x < 30000); t.push(now); counts.set(k, t);
  if (t.length < cfg.nuke_limit) return;
  counts.delete(k);
  const m = await guild.members.fetch(user.id).catch(() => null);
  let result = 'could not punish (my role is too low)';
  if (m?.bannable) { await m.ban({ reason: `Antinuke: ${label} x${t.length}` }); result = 'banned'; }
  else if (m?.manageable) { await m.roles.set([], 'Antinuke'); result = 'all roles removed'; }
  slog(client, guild, '🚨 Antinuke triggered', `<@${user.id}> — **${label}** ×${t.length} in 30s → ${result}`, 'error');
}
const watch = (name, type, label, targetOf = (x) => x.id) => ({ name, async run(client, a, b) {
  const x = b ?? a, guild = x.guild; if (!guild || !isAllowed(guild.id) || !secCfg(guild.id).nuke_on) return;
  const ex = await who(guild, type, targetOf(x)); if (!ex || ex.id === client.user.id || isTrusted(guild, ex.id)) return;
  await punish(client, guild, ex, label);
} });

export default [
  watch('channelDelete', A.ChannelDelete, 'channel deletes'),
  watch('channelCreate', A.ChannelCreate, 'channel creates'),
  watch('roleDelete', A.RoleDelete, 'role deletes'),
  watch('roleCreate', A.RoleCreate, 'role creates'),
  { name: 'guildBanAdd', async run(client, ban) {
    const guild = ban.guild; if (!isAllowed(guild.id) || !secCfg(guild.id).nuke_on) return;
    const ex = await who(guild, A.MemberBanAdd, ban.user.id); if (!ex || ex.id === client.user.id || isTrusted(guild, ex.id)) return; await punish(client, guild, ex, 'mass bans');
  } },
  { name: 'guildMemberRemove', async run(client, member) {
    const guild = member.guild; if (!isAllowed(guild.id) || !secCfg(guild.id).nuke_on) return;
    const ex = await who(guild, A.MemberKick, member.id); if (!ex || ex.id === client.user.id || isTrusted(guild, ex.id)) return; await punish(client, guild, ex, 'mass kicks');
  } },
  { name: 'guildMemberAdd', async run(client, member) {
    const guild = member.guild; if (!isAllowed(guild.id)) return; const cfg = secCfg(guild.id);
    if (cfg.antibot && member.user.bot) {
      const ex = await who(guild, A.BotAdd, member.id);
      if (!ex || !isTrusted(guild, ex.id)) { await member.kick('Antibot: unauthorized bot').catch(() => {}); slog(client, guild, '🤖 Antibot', `Removed bot **${member.user.tag}** added by ${ex ? `<@${ex.id}>` : 'unknown'}.`, 'error'); return; }
    }
    if (cfg.alt_days > 0 && !member.user.bot && Date.now() - member.user.createdTimestamp < cfg.alt_days * 864e5) {
      await member.kick(`Antialt: account younger than ${cfg.alt_days} days`).catch(() => {}); slog(client, guild, '👶 Antialt', `Kicked <@${member.id}> (account under ${cfg.alt_days} days old).`); return;
    }
    if (cfg.raid_on) {
      const now = Date.now(), k = `join:${guild.id}`, t = (counts.get(k) ?? []).filter((x) => now - x < 10000); t.push(now); counts.set(k, t);
      if (t.length >= cfg.raid_limit && !(raid.get(guild.id) > now)) { raid.set(guild.id, now + 600000); slog(client, guild, '🚨 Raid detected', `${t.length} joins in 10 seconds. New members will be kicked for 10 minutes.`, 'error'); }
      if (raid.get(guild.id) > now && !member.user.bot) { await member.kick('Antiraid lockdown').catch(() => {}); }
    }
  } },
];
