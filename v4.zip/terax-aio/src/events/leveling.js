import { db, getGuild } from '../core/db.js';
import { isAllowed, config } from '../core/config.js';
import { addXp, lcfg } from '../core/levels.js';

const last = new Map();
export default {
  name: 'messageCreate',
  async run(client, message) {
    if (message.author.bot || !message.guild || !isAllowed(message.guild.id) || !message.content) return;
    const prefix = getGuild(message.guild.id).prefix || config.prefix;
    if (message.content.startsWith(prefix)) return;
    const key = `${message.guild.id}:${message.author.id}`;
    if (Date.now() - (last.get(key) ?? 0) < 60000) return;
    const cfg = lcfg(message.guild.id);
    if (cfg.no_channels.split(',').includes(message.channel.id)) return;
    if (message.member && cfg.no_roles.split(',').some((r) => r && message.member.roles.cache.has(r))) return;
    last.set(key, Date.now());
    await addXp(client, message.guild.id, message.author.id, 15 + Math.floor(Math.random() * 11), message.channel);
  },
};
