import { ChannelType } from 'discord.js';
import { kvGet, kvSet } from '../core/db.js';
import { isAllowed } from '../core/config.js';
import { card, fail, eph } from '../core/ui.js';
import { db } from '../core/db.js';
import { clip } from '../core/util.js';

export default [
  { name: 'messageCreate', async run(client, message) {
    if (!message.guild || !isAllowed(message.guild.id)) return;
    const g = message.guild.id, ch = message.channel.id;
    // sticky messages (bot messages excluded so we never loop)
    if (!message.author.bot) {
      const st = kvGet(g, `sticky:${ch}`);
      if (st) { const old = kvGet(g, `stickyid:${ch}`); if (old) await message.channel.messages.delete(old).catch(() => {}); const m = await message.channel.send(card({ title: '📌 Sticky', body: st, foot: false })).catch(() => null); if (m) kvSet(g, `stickyid:${ch}`, m.id); }
      if (kvGet(g, `autothread:${ch}`)) message.startThread({ name: clip(message.content, 50) || 'Discussion' }).catch(() => {});
      // counting game
      if (kvGet(g, 'count_channel') === ch && /^\d+$/.test(message.content.trim())) {
        const n = +message.content.trim(), s = JSON.parse(kvGet(g, 'count_state') ?? '{"n":0,"u":null}');
        if (message.author.id === s.u || n !== s.n + 1) { message.react('❌').catch(() => {}); message.channel.send(fail('Count ruined!', `Ruined at **${s.n}** by <@${message.author.id}>. Start again from **1**.`)); kvSet(g, 'count_state', JSON.stringify({ n: 0, u: null })); }
        else { message.react('✅').catch(() => {}); kvSet(g, 'count_state', JSON.stringify({ n, u: message.author.id })); }
      }
    }
    if (message.channel.type === ChannelType.GuildAnnouncement && kvGet(g, `autopublish:${ch}`)) message.crosspost().catch(() => {});
  } },
  { name: 'messageReactionAdd', async run(client, reaction, user) {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch().catch(() => {}); if (reaction.message.partial) await reaction.message.fetch().catch(() => {});
    const msg = reaction.message, g = msg.guild?.id; if (!g || !isAllowed(g) || reaction.emoji.name !== '⭐') return;
    const star = kvGet(g, 'star_channel'); if (!star || msg.channel.id === star || kvGet(g, `star:${msg.id}`)) return;
    if (reaction.count < +(kvGet(g, 'star_min') ?? 3)) return;
    const ch = await client.channels.fetch(star).catch(() => null); if (!ch) return; kvSet(g, `star:${msg.id}`, '1');
    const img = msg.attachments.find((a) => a.contentType?.startsWith('image/'))?.url;
    ch.send(card({ title: `⭐ ${reaction.count} • ${msg.author?.username ?? 'Unknown'}`, body: `${clip(msg.content || '*(no text)*', 1500)}\n\n[Jump to message](${msg.url})`, image: img, color: 'warning' })).catch(() => {});
  } },
  { name: 'interactionCreate', async run(client, i) {
    if (!i.guild || !isAllowed(i.guild.id) || !i.isButton()) return;
    if (i.customId.startsWith('gw:')) {
      const id = +i.customId.slice(3), g = db.prepare('SELECT * FROM giveaways WHERE id=?').get(id);
      if (!g || g.ended || g.ends < Date.now()) return i.reply(eph(fail('Giveaway ended')));
      const had = db.prepare('SELECT 1 FROM gw_entries WHERE gid=? AND user=?').get(id, i.user.id);
      if (had) db.prepare('DELETE FROM gw_entries WHERE gid=? AND user=?').run(id, i.user.id); else db.prepare('INSERT INTO gw_entries VALUES (?,?)').run(id, i.user.id);
      return i.reply(eph(card({ title: had ? 'Left the giveaway' : '🎉 You are in!', color: had ? 'warning' : 'success', body: `${db.prepare('SELECT COUNT(*) c FROM gw_entries WHERE gid=?').get(id).c} total entries` })));
    }
  } },
];
