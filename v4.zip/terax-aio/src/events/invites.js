import { db } from '../core/db.js';
import { isAllowed } from '../core/config.js';

const cache = new Map(); // guildId -> Map(code -> uses)
const load = async (guild) => { const inv = await guild.invites.fetch().catch(() => null); if (inv) cache.set(guild.id, new Map(inv.map((i) => [i.code, i.uses ?? 0]))); };
export default [
  { name: 'clientReady', once: true, async run(client) { for (const g of client.guilds.cache.values()) if (isAllowed(g.id)) await load(g); } },
  { name: 'inviteCreate', async run(client, i) { if (i.guild && isAllowed(i.guild.id)) (cache.get(i.guild.id) ?? cache.set(i.guild.id, new Map()).get(i.guild.id)).set(i.code, i.uses ?? 0); } },
  { name: 'inviteDelete', async run(client, i) { cache.get(i.guild?.id)?.delete(i.code); } },
  { name: 'guildMemberAdd', async run(client, m) {
    if (!isAllowed(m.guild.id) || m.user.bot) return; const before = cache.get(m.guild.id), inv = await m.guild.invites.fetch().catch(() => null); if (!inv) return;
    const used = before && inv.find((i) => (before.get(i.code) ?? 0) < (i.uses ?? 0));
    cache.set(m.guild.id, new Map(inv.map((i) => [i.code, i.uses ?? 0])));
    db.prepare('INSERT INTO invite_log VALUES (?,?,?,?,?)').run(m.guild.id, m.id, used?.inviter?.id ?? null, used?.code ?? null, Date.now());
  } },
];
