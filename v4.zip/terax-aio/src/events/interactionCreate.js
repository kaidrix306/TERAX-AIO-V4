import { MessageFlags } from 'discord.js';
import { config, isAllowed, isOwner } from '../core/config.js';
import { db, getGuild } from '../core/db.js';
import { ok, fail, warn, card, eph } from '../core/ui.js';
import { createTicket, closeTicket, getTicket, getCfg, isStaff } from '../core/tickets.js';
import { helpCategory } from '../core/help.js';

export default {
  name: 'interactionCreate',
  async run(client, i) {
    if (!i.guild || !isAllowed(i.guild.id)) return;
    if (i.isStringSelectMenu() && i.customId === 'help:menu') {
      const prefix = getGuild(i.guild.id).prefix || config.prefix;
      return i.update(helpCategory(client, i.values[0], prefix, isOwner(i.user.id)));
    }
    if (!i.isButton() || !i.customId.startsWith('tk:')) return;

    if (i.customId === 'tk:create') {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const r = await createTicket(i.guild, i.member).catch((e) => ({ error: e.message }));
      return i.editReply(r.error ? fail('Cannot open ticket', r.error) : ok('Ticket created', `Head to <#${r.channel.id}>`));
    }
    const t = getTicket(i.channel.id);
    if (!t) return i.reply(eph(fail('Not a ticket', 'This is not an open ticket.')));
    const cfg = getCfg(t.guild), staff = isStaff(i.member, cfg);

    if (i.customId === 'tk:close') {
      if (!staff && i.user.id !== t.owner) return i.reply(eph(fail('Not allowed', 'Only staff or the ticket owner can close this.')));
      await i.reply(eph(ok('Closing ticket…')));
      return closeTicket(i.channel, i.user, `Closed by ${i.user.tag}`);
    }
    if (i.customId === 'tk:claim') {
      if (!staff) return i.reply(eph(fail('Staff only', 'Only staff can claim tickets.')));
      if (t.claimed_by) return i.reply(eph(warn('Already claimed', `Claimed by <@${t.claimed_by}>.`)));
      db.prepare('UPDATE tickets SET claimed_by=?, ai_on=0 WHERE channel=?').run(i.user.id, t.channel);
      return i.reply(card({ title: '🙋 Ticket claimed', body: `<@${i.user.id}> is handling this ticket. The AI assistant is now off.`, color: 'success' }));
    }
    if (i.customId === 'tk:human') {
      if (!staff && i.user.id !== t.owner) return i.reply(eph(fail('Not allowed', 'Only the ticket owner or staff can do this.')));
      db.prepare('UPDATE tickets SET ai_on=0 WHERE channel=?').run(t.channel);
      return i.reply({ ...card({ title: '👤 Human requested', body: `AI replies are off. ${cfg?.staff_role ? `<@&${cfg.staff_role}>` : 'Staff'} will be with you soon.`, color: 'warning' }), allowedMentions: { roles: cfg?.staff_role ? [cfg.staff_role] : [] } });
    }
  },
};
