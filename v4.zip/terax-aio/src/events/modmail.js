// Modmail: members DM the bot; staff talk to them from a private channel. The user starts the DM, and every
// exchange is mirrored in the staff channel. API keys sent for the panel flow are never forwarded.
import { ChannelType, PermissionFlagsBits as P } from 'discord.js';
import { db, kvGet, kvSet, getGuild } from '../core/db.js';
import { config, isAllowed } from '../core/config.js';
import { pending } from '../core/ptero.js';
import { card } from '../core/ui.js';
import { tryDM } from '../core/dm.js';
import { clip, ts } from '../core/util.js';

const files = (m) => (m.attachments.size ? '\n' + [...m.attachments.values()].map((a) => `📎 ${a.url}`).join('\n') : '');
export default [
  { name: 'messageCreate', async run(client, message) {
    if (message.guild || message.author.bot) return;
    if (pending.has(message.author.id) || /ptl[ac]_[A-Za-z0-9]/.test(message.content)) return;
    if (db.prepare('SELECT 1 FROM blacklist WHERE id=?').get(message.author.id)) return;
    for (const gid of [...client.guilds.cache.keys()].filter(isAllowed)) {
      const guild = client.guilds.cache.get(gid), cat = guild && kvGet(gid, 'mm_category'); if (!cat) continue;
      const member = await guild.members.fetch(message.author.id).catch(() => null); if (!member) continue;
      const body = clip(message.content || '*(no text)*', 1800) + files(message);
      let chId = kvGet(gid, `mm:user:${member.id}`), ch = chId && await client.channels.fetch(chId).catch(() => null);
      if (!ch) {
        const role = kvGet(gid, 'mm_role'), base = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles];
        ch = await guild.channels.create({ name: `modmail-${member.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 90) || 'modmail', type: ChannelType.GuildText, parent: cat, topic: `Modmail with ${member.user.tag} (${member.id})`,
          permissionOverwrites: [{ id: guild.id, deny: [P.ViewChannel] }, { id: guild.members.me.id, allow: [...base, P.ManageChannels] }, ...(role ? [{ id: role, allow: base }] : [])] }).catch(() => null);
        if (!ch) return;
        kvSet(gid, `mm:user:${member.id}`, ch.id); kvSet(gid, `mm:chan:${ch.id}`, member.id);
        await ch.send({ ...card({ title: '📬 New modmail', body: `From **${member.user.username}** (<@${member.id}>)\nAccount created ${ts(member.user.createdTimestamp)} • joined ${ts(member.joinedTimestamp)}\nReply in this channel to answer them. Use \`modmailclose\` when finished.`, color: 'success' }), allowedMentions: { roles: role ? [role] : [] }, content: undefined }).catch(() => {});
        await tryDM(message.author, card({ title: '📨 Message sent to staff', body: 'Your message was delivered. Staff replies will arrive here.', color: 'success' }));
      }
      return ch.send(card({ title: `💬 ${member.user.username}`, body, thumb: member.user.displayAvatarURL(), foot: false })).then(() => message.react('✅')).catch(() => {});
    }
  } },
  // staff -> user
  { name: 'messageCreate', async run(client, message) {
    if (!message.guild || message.author.bot || !isAllowed(message.guild.id) || !message.content && !message.attachments.size) return;
    const uid = kvGet(message.guild.id, `mm:chan:${message.channel.id}`); if (!uid) return;
    if (message.content.startsWith(getGuild(message.guild.id).prefix || config.prefix)) return;
    const user = await client.users.fetch(uid).catch(() => null);
    const sent = user && await tryDM(user, card({ title: `📨 Reply from ${message.guild.name} staff`, body: clip(message.content || '*(attachment)*', 1800) + files(message), color: 'info', foot: false }));
    message.react(sent ? '✅' : '❌').catch(() => {});
    if (!sent) message.channel.send(card({ title: 'Could not deliver', body: 'The member has their DMs closed.', color: 'warning', foot: false })).catch(() => {});
  } },
];
