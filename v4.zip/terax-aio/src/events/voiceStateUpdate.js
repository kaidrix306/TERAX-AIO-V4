import { ChannelType, PermissionFlagsBits as P } from 'discord.js';
import { db } from '../core/db.js';
import { isAllowed } from '../core/config.js';
import { addXp, lcfg } from '../core/levels.js';

const joined = new Map();
export default {
  name: 'voiceStateUpdate',
  async run(client, o, n) {
    const guild = n.guild; if (!isAllowed(guild.id) || n.member?.user.bot) return;
    const key = `${guild.id}:${n.id}`;
    if (o.channelId && o.channelId !== n.channelId) {
      const t = joined.get(key); joined.delete(key);
      if (t) {
        const sec = Math.floor((Date.now() - t) / 1000);
        db.prepare('INSERT INTO voice_time(guild,user,seconds) VALUES (?,?,?) ON CONFLICT(guild,user) DO UPDATE SET seconds=seconds+excluded.seconds').run(guild.id, n.id, sec);
        if (lcfg(guild.id).voicexp && sec >= 60) addXp(client, guild.id, n.id, Math.floor(sec / 60) * 5, null).catch(() => {});
      }
      // delete empty temp channels
      const tmp = db.prepare('SELECT 1 FROM tempvc WHERE channel=?').get(o.channelId);
      if (tmp && o.channel && o.channel.members.size === 0) { db.prepare('DELETE FROM tempvc WHERE channel=?').run(o.channelId); o.channel.delete('Temp VC empty').catch(() => {}); }
    }
    if (n.channelId && n.channelId !== o.channelId) {
      joined.set(key, Date.now());
      const cfg = db.prepare('SELECT * FROM tempvc_cfg WHERE guild=?').get(guild.id);
      if (cfg?.lobby === n.channelId) {
        const ch = await guild.channels.create({ name: `${n.member.displayName}'s room`.slice(0, 90), type: ChannelType.GuildVoice, parent: cfg.category || n.channel.parentId,
          permissionOverwrites: [{ id: n.id, allow: [P.ManageChannels, P.MoveMembers, P.Connect, P.ViewChannel] }] }).catch(() => null);
        if (ch) { db.prepare('INSERT INTO tempvc(channel,guild,owner) VALUES (?,?,?)').run(ch.id, guild.id, n.id); await n.setChannel(ch).catch(() => {}); }
      }
    }
  },
};
