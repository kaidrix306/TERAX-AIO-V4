import { isAllowed } from '../core/config.js';
import { botlog } from '../core/botlog.js';

export default [
  { name: 'guildCreate', async run(client, guild) {
    if (!isAllowed(guild.id)) { console.log(`Blocked join: ${guild.name} (${guild.id})`); botlog(client, '🚫 Blocked server', `${guild.name} (\`${guild.id}\`) — not whitelisted, left.`, 'warning'); await guild.leave().catch(() => {}); return; }
    botlog(client, '✅ Joined server', `${guild.name} (\`${guild.id}\`) • ${guild.memberCount} members`, 'success');
  } },
  { name: 'guildDelete', async run(client, guild) { botlog(client, '👋 Left server', `${guild.name ?? 'Unknown'} (\`${guild.id}\`)`, 'warning'); } },
];
