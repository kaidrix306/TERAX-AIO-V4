import { db, kvGet } from '../core/db.js';
import { isAllowed } from '../core/config.js';
import { card } from '../core/ui.js';

const fill = (t, m) => t.replace(/\{user\}/g, `<@${m.id}>`).replace(/\{username\}/g, m.user.username).replace(/\{server\}/g, m.guild.name).replace(/\{count\}/g, m.guild.memberCount);
const emojiKey = (e) => e.id ?? e.name;
async function rr(reaction, user, add) {
  if (user.bot) return; if (reaction.partial) await reaction.fetch().catch(() => {}); const msg = reaction.message; if (msg.partial) await msg.fetch().catch(() => {});
  if (!msg.guild || !isAllowed(msg.guild.id)) return;
  const row = db.prepare('SELECT role FROM rr WHERE guild=? AND message=? AND emoji=?').get(msg.guild.id, msg.id, emojiKey(reaction.emoji)); if (!row) return;
  const m = await msg.guild.members.fetch(user.id).catch(() => null); await (add ? m?.roles.add(row.role) : m?.roles.remove(row.role))?.catch(() => {});
}
const sendTo = async (client, guild, key, msgKey, member, title, color) => {
  const ch = kvGet(guild.id, key), text = kvGet(guild.id, msgKey) ?? (key === 'welcome_ch' ? 'Welcome {user} to **{server}**! You are member #{count}.' : '**{username}** left **{server}**.');
  const c = ch && await client.channels.fetch(ch).catch(() => null); c?.send({ ...card({ title, body: fill(text, member), color, thumb: member.user.displayAvatarURL(), foot: false }), allowedMentions: { users: [member.id] } }).catch(() => {});
};
const cd = new Map();

export default [
  { name: 'guildMemberAdd', async run(client, m) {
    if (!isAllowed(m.guild.id)) return;
    const role = kvGet(m.guild.id, m.user.bot ? 'botautorole' : 'autorole'); if (role) m.roles.add(role).catch(() => {});
    if (!m.user.bot) sendTo(client, m.guild, 'welcome_ch', 'welcome_msg', m, '👋 Welcome!', 'success');
  } },
  { name: 'guildMemberRemove', async run(client, m) { if (isAllowed(m.guild.id) && !m.user.bot) sendTo(client, m.guild, 'leave_ch', 'leave_msg', m, '👋 Goodbye', 'warning'); } },
  { name: 'messageReactionAdd', run: (c, r, u) => rr(r, u, true) },
  { name: 'messageReactionRemove', run: (c, r, u) => rr(r, u, false) },
  { name: 'messageCreate', async run(client, message) {
    if (message.author.bot || !message.guild || !isAllowed(message.guild.id) || !message.content) return;
    const resp = kvGet(message.guild.id, `ar:${message.content.trim().toLowerCase()}`); if (!resp) return;
    const k = `${message.channel.id}`; if (Date.now() - (cd.get(k) ?? 0) < 5000) return; cd.set(k, Date.now());
    message.reply(card({ title: '\u200b', body: fill(resp, message.member), foot: false })).catch(() => {});
  } },
];
