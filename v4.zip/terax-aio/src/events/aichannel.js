import { getGuild, kvGet } from '../core/db.js';
import { config, env, isAllowed } from '../core/config.js';
import { gemini } from '../core/gemini.js';
import { aiMem } from '../core/aimem.js';
import { card } from '../core/ui.js';
import { clip } from '../core/util.js';

const cool = new Map();
export default {
  name: 'messageCreate',
  async run(client, message) {
    if (message.author.bot || !message.guild || !message.content || !isAllowed(message.guild.id)) return;
    const g = message.guild.id; if (kvGet(g, 'ai_channel') !== message.channel.id) return;
    const row = getGuild(g); if (!row.ai_enabled || !env.gemini || message.content.startsWith(row.prefix || config.prefix)) return;
    const k = `${message.channel.id}:${message.author.id}`, now = Date.now(); if (now - (cool.get(k) ?? 0) < 8000) return; cool.set(k, now);
    const hist = aiMem.get(k) ?? []; hist.push(`User: ${clip(message.content, 700)}`); await message.channel.sendTyping().catch(() => {});
    const persona = kvGet(g, 'ai_persona'), system = `${persona ? `${persona}\n` : ''}You are a helpful assistant in the Discord server "${message.guild.name}". Keep answers under 150 words, plain text. Never ask for passwords or tokens.\n${row.ai_prompt ? `Server info:\n${row.ai_prompt}` : ''}`;
    try {
      const out = await gemini({ system, prompt: `Conversation:\n${hist.join('\n')}\nAssistant:` });
      hist.push(`Assistant: ${clip(out, 700)}`); aiMem.set(k, hist.slice(-config.ai.maxHistory));
      await message.reply(card({ title: '🤖', body: clip(out, 1800), foot: false }));
    } catch { /* quota or network: stay quiet in a public chat channel */ }
  },
};
