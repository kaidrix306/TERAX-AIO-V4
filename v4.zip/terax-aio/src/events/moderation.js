import { isAllowed } from '../core/config.js';
import { kvGet } from '../core/db.js';
import { snipes, esnipes, put } from '../core/snipe.js';

export default [
  { name: 'messageDelete', async run(client, m) {
    if (!m.guild || !isAllowed(m.guild.id) || m.author?.bot || (!m.content && !m.attachments?.size)) return;
    put(snipes, m.channel.id, { content: m.content ?? '', author: m.author?.id, files: [...(m.attachments?.values() ?? [])].map((a) => a.name) });
  } },
  { name: 'messageUpdate', async run(client, o, n) {
    if (!n.guild || !isAllowed(n.guild.id) || o.author?.bot || !o.content || o.content === n.content) return;
    put(esnipes, n.channel.id, { content: o.content, author: o.author?.id });
  } },
  { name: 'guildMemberUpdate', async run(client, o, n) {
    if (!isAllowed(n.guild.id) || o.nickname === n.nickname) return;
    const forced = kvGet(n.guild.id, `forcenick:${n.id}`); if (forced && n.nickname !== forced) n.setNickname(forced, 'Forced nickname').catch(() => {});
  } },
];
