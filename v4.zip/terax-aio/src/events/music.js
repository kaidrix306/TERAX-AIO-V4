import { isAllowed } from '../core/config.js';
import { queues, advance, destroy } from '../core/music.js';
import { kvGet } from '../core/db.js';
import { ok, fail, eph } from '../core/ui.js';

const alone = new Map();
export default [
  { name: 'interactionCreate', async run(client, i) {
    if (!i.guild || !isAllowed(i.guild.id) || !i.isButton() || !i.customId.startsWith('mu:')) return;
    const q = queues.get(i.guild.id);
    if (!q?.current) return i.reply(eph(fail('Nothing is playing')));
    if (i.member.voice.channelId !== q.voiceId) return i.reply(eph(fail('Join my voice channel first')));
    const dj = kvGet(i.guild.id, 'dj_role'); if (dj && !i.member.roles.cache.has(dj) && !i.member.permissions.has('ManageGuild')) return i.reply(eph(fail('DJ only')));
    const a = i.customId.slice(3);
    if (a === 'pause') { const p = !q.player.paused; await q.player.setPaused(p); return i.reply(eph(ok(p ? 'Paused' : 'Resumed'))); }
    if (a === 'skip') { await i.reply(eph(ok('Skipped'))); return advance(client, q, true); }
    if (a === 'stop') { await i.reply(eph(ok('Stopped'))); return destroy(client, i.guild.id); }
    if (a === 'loop') { q.loop = { off: 'track', track: 'queue', queue: 'off' }[q.loop]; return i.reply(eph(ok('Loop', q.loop))); }
    if (a === 'shuffle') { for (let x = q.tracks.length - 1; x > 0; x--) { const j = Math.floor(Math.random() * (x + 1)); [q.tracks[x], q.tracks[j]] = [q.tracks[j], q.tracks[x]]; } return i.reply(eph(ok('Shuffled'))); }
  } },
  // leave if everyone else left (unless 24/7)
  { name: 'voiceStateUpdate', async run(client, o, n) {
    const q = queues.get(n.guild.id); if (!q || !isAllowed(n.guild.id)) return;
    const ch = n.guild.channels.cache.get(q.voiceId); if (!ch) return;
    const humans = ch.members.filter((m) => !m.user.bot).size;
    if (humans === 0 && !kvGet(n.guild.id, '247')) { if (!alone.has(n.guild.id)) alone.set(n.guild.id, setTimeout(() => { alone.delete(n.guild.id); const c = n.guild.channels.cache.get(q.voiceId); if (c && c.members.filter((m) => !m.user.bot).size === 0) destroy(client, n.guild.id); }, 60000)); }
    else if (alone.has(n.guild.id)) { clearTimeout(alone.get(n.guild.id)); alone.delete(n.guild.id); }
  } },
];
