import { PermissionFlagsBits as P } from 'discord.js';
import { db } from '../core/db.js';
import { isAllowed } from '../core/config.js';
import { isWhitelisted, slog } from '../core/security.js';
import { addCase } from '../core/db.js';
import { card } from '../core/ui.js';

const spam = new Map();
const PHISH = [/(?:disc[o0]rd|d[il1]sc[o0]rd|dlscord)[-.]?(?:nitro|gifts?|app|promo)\.[a-z]{2,}/i, /steam(?:communlty|communitty|comnunity)\.[a-z]{2,}/i, /free\s+nitro/i, /(?:nitro|gift).{0,40}(?:claim|giveaway).{0,60}https?:\/\//i, /https?:\/\/\S*\.(?:ru|tk|ml|ga|cf)\/\S*(?:nitro|gift|steam|airdrop)/i];
const EMOJI = /\p{Extended_Pictographic}|<a?:\w+:\d+>/gu;

export default {
  name: 'messageCreate',
  async run(client, message) {
    if (message.author.bot || !message.guild || !message.member || !isAllowed(message.guild.id) || !message.content) return;
    const gid = message.guild.id, rows = db.prepare('SELECT * FROM am WHERE guild=? AND enabled=1').all(gid);
    if (!rows.length || message.member.permissions.has(P.ManageMessages) || isWhitelisted(gid, message.member)) return;
    const R = Object.fromEntries(rows.map((r) => [r.rule, r])), c = message.content;
    let hit = null;
    if (R.antispam) {
      const k = `${gid}:${message.author.id}`, now = Date.now(), t = (spam.get(k) ?? []).filter((x) => now - x < 5000); t.push(now); spam.set(k, t);
      if (t.length >= (+R.antispam.val || 5)) { hit = 'antispam'; spam.delete(k); }
    }
    if (!hit && R.antiinvite && /(?:discord\.gg|discord(?:app)?\.com\/invite)\/[a-z0-9-]+/i.test(c)) hit = 'antiinvite';
    if (!hit && R.antilink && /(?:https?:\/\/|www\.)\S+/i.test(c)) {
      const ok = db.prepare('SELECT domain FROM am_links WHERE guild=?').all(gid).some((d) => c.toLowerCase().includes(d.domain));
      if (!ok) hit = 'antilink';
    }
    if (!hit && R.antiphish && PHISH.some((r) => r.test(c))) hit = 'antiphish';
    if (!hit && R.antiswear) { const words = db.prepare('SELECT word FROM am_words WHERE guild=?').all(gid).map((w) => w.word), low = c.toLowerCase(); if (words.some((w) => new RegExp(`(^|[^a-z0-9])${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`).test(low))) hit = 'antiswear'; }
    if (!hit && R.antiemoji && (c.match(EMOJI)?.length ?? 0) > (+R.antiemoji.val || 8)) hit = 'antiemoji';
    if (!hit && R.anticaps && c.length >= 10) { const l = c.replace(/[^a-z]/gi, ''); if (l.length >= 8 && l.replace(/[^A-Z]/g, '').length / l.length > 0.7) hit = 'anticaps'; }
    if (!hit && R.antimention && message.mentions.users.size + message.mentions.roles.size > (+R.antimention.val || 5)) hit = 'antimention';
    if (!hit && R.antizalgo && /[\u0300-\u036f]{4,}/.test(c)) hit = 'antizalgo';
    if (!hit) return;

    const punish = R[hit].punish;
    await message.delete().catch(() => {});
    let extra = '';
    if (punish === 'warn') { addCase(gid, message.author.id, client.user.id, 'Warn', `Automod: ${hit}`); extra = ' (warned)'; }
    if (punish === 'timeout') { await message.member.timeout(600000, `Automod: ${hit}`).catch(() => {}); extra = ' (timed out 10m)'; }
    if (punish === 'kick') { await message.member.kick(`Automod: ${hit}`).catch(() => {}); extra = ' (kicked)'; }
    const n = await message.channel.send(card({ title: '🛡️ Automod', body: `<@${message.author.id}>, that message was removed (**${hit}**)${extra}.`, color: 'mod', foot: false })).catch(() => null);
    if (n) setTimeout(() => n.delete().catch(() => {}), 5000);
    slog(client, message.guild, `🛡️ Automod • ${hit}`, `User: <@${message.author.id}>\nChannel: <#${message.channel.id}>\nAction: ${punish}`, 'mod');
  },
};
