import { Client, GatewayIntentBits as I, Partials } from 'discord.js';
import { Shoukaku, Connectors } from 'shoukaku';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { env } from './core/config.js';
import { loadCommands } from './core/loader.js';
import { rejoin247 } from './core/music.js';

if (!env.token) { console.error('Missing DISCORD_TOKEN. Copy .env.example to .env and fill it in.'); process.exit(1); }

const client = new Client({
  intents: [I.Guilds, I.GuildMembers, I.GuildMessages, I.DirectMessages, I.GuildMessageReactions, I.GuildInvites, I.MessageContent, I.GuildVoiceStates, I.GuildModeration],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
  allowedMentions: { parse: [], repliedUser: false },
});
client.startedAt = Date.now();
client.maintenance = false;
client.cooldowns = new Map();

// Lavalink (music). Shoukaku must be created before login.
client.shoukaku = null;
if (process.env.LAVALINK_HOST) {
  const shoukaku = new Shoukaku(new Connectors.DiscordJS(client), [{
    name: 'main', url: `${process.env.LAVALINK_HOST}:${process.env.LAVALINK_PORT || 2333}`,
    auth: process.env.LAVALINK_PASSWORD, secure: process.env.LAVALINK_SECURE === 'true',
  }], { resume: true, resumeTimeout: 30, reconnectTries: 10, moveOnDisconnect: true });
  shoukaku.on('ready', (name) => { console.log(`Lavalink node "${name}" ready`); rejoin247(client).catch((e) => console.error('[247]', e)); });
  shoukaku.on('error', (name, e) => console.error(`[lavalink ${name}]`, e?.message ?? e));
  client.shoukaku = shoukaku;
} else console.warn('LAVALINK_HOST is not set: music commands are disabled.');

console.log(`Loaded ${await loadCommands(client)} commands`);
for (const f of fs.readdirSync('src/events').filter((f) => f.endsWith('.js'))) {
  const mod = (await import(pathToFileURL(path.resolve('src/events', f)).href)).default;
  for (const ev of [].concat(mod)) client[ev.once ? 'once' : 'on'](ev.name, (...a) => ev.run(client, ...a).catch((e) => console.error(`[${ev.name}]`, e)));
}
process.on('unhandledRejection', (e) => console.error('[unhandled]', e));
client.login(env.token);
