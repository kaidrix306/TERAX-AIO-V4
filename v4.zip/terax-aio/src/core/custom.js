import { kvGet } from './db.js';
import { card } from './ui.js';
import { clip } from './util.js';

export async function runCustom(message, name) {
  const t = kvGet(message.guild.id, `cc:${name}`);
  if (!t) return false;
  const body = t.replace(/\{user\}/g, `<@${message.author.id}>`).replace(/\{username\}/g, message.author.username).replace(/\{server\}/g, message.guild.name).replace(/\{count\}/g, message.guild.memberCount);
  await message.reply(card({ title: `📌 ${clip(name, 40)}`, body, foot: false })); return true;
}
