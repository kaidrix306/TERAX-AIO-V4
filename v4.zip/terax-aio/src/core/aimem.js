export const aiMem = new Map(); // `${channelId}:${userId}` -> recent lines
