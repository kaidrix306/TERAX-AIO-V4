export const clip = (s, n = 1000) => { s = String(s ?? ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
export const ts = (ms, f = 'R') => `<t:${Math.floor(ms / 1000)}:${f}>`;
export const idOf = (arg) => String(arg ?? '').replace(/[<@!&#>]/g, '');

export function parseDuration(s) {
  const m = /^(\d+)(s|m|h|d|w)$/i.exec(s || '');
  if (!m) return null;
  return +m[1] * { s: 1e3, m: 6e4, h: 36e5, d: 864e5, w: 6048e5 }[m[2].toLowerCase()];
}
export function fmtDuration(ms) {
  const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
  return [d && `${d}d`, h && `${h}h`, m && `${m}m`, (s || !ms) && `${s}s`].filter(Boolean).join(' ');
}
export async function getMember(message, arg) {
  if (!arg) return null;
  const id = idOf(arg);
  return message.guild.members.cache.get(id) ?? (/^\d{15,22}$/.test(id) ? await message.guild.members.fetch(id).catch(() => null) : null);
}
export async function getUser(client, arg) {
  const id = idOf(arg);
  return /^\d{15,22}$/.test(id) ? client.users.fetch(id).catch(() => null) : null;
}
export const getChannel = (message, arg) => message.guild.channels.cache.get(idOf(arg));
export function getRole(message, arg) {
  if (!arg) return null;
  return message.guild.roles.cache.get(idOf(arg)) ?? message.guild.roles.cache.find((r) => r.name.toLowerCase() === arg.toLowerCase());
}
