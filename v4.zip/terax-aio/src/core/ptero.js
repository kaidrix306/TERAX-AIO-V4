import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { db } from './db.js';
import { dec } from './crypto.js';
import { isOwner } from './config.js';
import { card, fail } from './ui.js';
import { clip } from './util.js';

export const cfgOf = (g) => db.prepare('SELECT * FROM ptero_cfg WHERE guild=?').get(g);
export const pending = new Map(); // userId -> { guild, mode: 'owner'|'user', until }

// Per-guild rate limit so command spam cannot hammer the panel (20 requests / 10s).
const buckets = new Map();
function limit(g) {
  const now = Date.now(), b = (buckets.get(g) ?? []).filter((t) => now - t < 10000);
  if (b.length >= 20) throw new Error('RATE');
  b.push(now); buckets.set(g, b);
}
export async function api(guild, kind, method, path, body, keyOverride) {
  const cfg = cfgOf(guild);
  if (!cfg?.url) throw new Error('NOT_LINKED');
  const raw = keyOverride ?? (kind === 'app' ? cfg.app_key : cfg.client_key);
  if (!raw) throw new Error(`NO_KEY_${kind}`);
  limit(guild);
  const key = keyOverride ? raw : dec(raw);
  const res = await fetch(`${cfg.url.replace(/\/$/, '')}/api/${kind === 'app' ? 'application' : 'client'}${path}`, {
    method, signal: AbortSignal.timeout(15000),
    headers: { Authorization: `Bearer ${key}`, Accept: 'Application/vnd.pterodactyl.v1+json', 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const j = await res.json().catch(() => null);
  if (!res.ok) { const e = new Error(j?.errors?.[0]?.detail || `HTTP ${res.status}`); e.status = res.status; throw e; }
  return j;
}
export function level(member) {
  if (isOwner(member.id) || member.id === member.guild.ownerId) return 3;
  const c = cfgOf(member.guild.id); if (!c) return 0;
  const has = (r) => r && member.roles.cache.has(r);
  return has(c.admin_role) ? 3 : has(c.staff_role) ? 2 : has(c.customer_role) ? 1 : 0;
}
export async function resolveServer(message, q) {
  const lv = level(message.member), gid = message.guild.id;
  let key;
  if (lv < 2) {
    const l = db.prepare('SELECT client_key FROM ptero_links WHERE guild=? AND user=?').get(gid, message.author.id);
    if (!l) throw new Error('NOT_LINKED_USER');
    key = dec(l.client_key);
  }
  const list = await api(gid, 'client', 'GET', `/?per_page=100${lv >= 2 ? '&type=admin-all' : ''}`, null, key);
  const all = list.data.map((d) => d.attributes), n = String(q ?? '').toLowerCase();
  const srv = all.find((x) => x.identifier === q || x.uuid === q) ?? all.find((x) => x.name.toLowerCase() === n) ?? all.find((x) => x.name.toLowerCase().includes(n));
  if (!srv || !q) throw new Error('NO_SERVER');
  return { srv, key, gid };
}
export function perr(e) {
  const m = { NOT_LINKED: 'No panel is linked. The server owner must run `pteroset <panel url>`.', RATE: 'Too many panel requests. Wait a few seconds.',
    NO_SERVER: 'I could not find that server. Use `pteroservers` to see the list.', NOT_LINKED_USER: 'Link your panel account first with `pterolink`.',
    NO_KEY_app: 'No Application API key saved. Run `pterorotate` and send a `ptla_` key.', NO_KEY_client: 'No Client API key saved. Run `pterorotate` and send a `ptlc_` key.' };
  if (m[e.message]) return m[e.message];
  if (e.name === 'TimeoutError') return 'The panel did not respond in time.';
  if (e.status === 401 || e.status === 403) return 'The panel rejected the API key (wrong key or missing permission).';
  return clip(e.message, 300);
}
export async function plog(client, guild, user, text) {
  const c = cfgOf(guild); if (!c?.log_channel) return;
  const ch = await client.channels.fetch(c.log_channel).catch(() => null);
  ch?.send(card({ title: '🦕 Panel action', body: text, fields: [['By', `<@${user.id}> (${user.id})`]], color: 'mod' })).catch(() => {});
}
export async function confirm(message, text) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('cf:y').setLabel('Confirm').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('cf:n').setLabel('Cancel').setStyle(ButtonStyle.Secondary));
  const m = await message.reply(card({ title: '⚠️ Please confirm', body: text, color: 'warning', rows: [row] }));
  try {
    const i = await m.awaitMessageComponent({ filter: (x) => x.user.id === message.author.id, time: 30000 });
    await i.update(card({ title: i.customId === 'cf:y' ? 'Confirmed' : 'Cancelled', color: 'info' }));
    return i.customId === 'cf:y';
  } catch { await m.edit(card({ title: 'Timed out', color: 'warning' })).catch(() => {}); return false; }
}
// Wrap a command: permission level check + friendly errors.
export function def({ lv = 3, run, ...rest }) {
  return { category: 'hosting', cooldown: 4, ...rest, async run(ctx) {
    if (level(ctx.message.member) < lv) return ctx.message.reply(fail('No access', lv >= 3 ? 'This needs the panel **admin** role.' : lv === 2 ? 'This needs the panel **staff** role or higher.' : 'You need the panel **customer** role or higher.'));
    try { return await run(ctx); } catch (e) { return ctx.message.reply(fail('Panel error', perr(e))); }
  } };
}
