import { config } from './config.js';
import { card } from './ui.js';

export async function botlog(client, title, body, color = 'info') {
  if (!config.botLogChannel) return;
  (await client.channels.fetch(config.botLogChannel).catch(() => null))?.send(card({ title, body, color })).catch(() => {});
}
