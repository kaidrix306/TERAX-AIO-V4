import Database from 'better-sqlite3';
import fs from 'node:fs';

fs.mkdirSync('data', { recursive: true });
export const db = new Database('data/terax.db');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS guild (id TEXT PRIMARY KEY, prefix TEXT, log_channel TEXT, ai_enabled INTEGER DEFAULT 1, ai_prompt TEXT, dm_notices INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS blacklist (id TEXT PRIMARY KEY, type TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS cases (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, user TEXT, mod TEXT, type TEXT, reason TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, user TEXT, mod TEXT, text TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS afk (guild TEXT, user TEXT, reason TEXT, at INTEGER, PRIMARY KEY (guild, user));
CREATE TABLE IF NOT EXISTS ticket_cfg (guild TEXT PRIMARY KEY, category TEXT, staff_role TEXT, log_channel TEXT, max_open INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS tickets (channel TEXT PRIMARY KEY, guild TEXT, owner TEXT, claimed_by TEXT, priority TEXT DEFAULT 'normal', ai_on INTEGER DEFAULT 1, status TEXT DEFAULT 'open', topic TEXT, created INTEGER, closed INTEGER);
CREATE TABLE IF NOT EXISTS ticket_notes (id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT, mod TEXT, text TEXT, at INTEGER);
`);

export function getGuild(id) {
  db.prepare('INSERT OR IGNORE INTO guild(id) VALUES (?)').run(id);
  return db.prepare('SELECT * FROM guild WHERE id=?').get(id);
}
const GUILD_COLS = new Set(['prefix', 'log_channel', 'ai_enabled', 'ai_prompt', 'dm_notices']);
export function setGuild(id, col, val) {
  if (!GUILD_COLS.has(col)) throw new Error('bad column');
  getGuild(id);
  db.prepare(`UPDATE guild SET ${col}=? WHERE id=?`).run(val, id);
}
export const addCase = (guild, user, mod, type, reason) =>
  Number(db.prepare('INSERT INTO cases(guild,user,mod,type,reason,at) VALUES (?,?,?,?,?,?)').run(guild, user, mod, type, reason, Date.now()).lastInsertRowid);

db.exec(`
CREATE TABLE IF NOT EXISTS ptero_cfg (guild TEXT PRIMARY KEY, url TEXT, app_key TEXT, client_key TEXT, admin_role TEXT, staff_role TEXT, customer_role TEXT, log_channel TEXT);
CREATE TABLE IF NOT EXISTS ptero_links (guild TEXT, user TEXT, client_key TEXT, PRIMARY KEY (guild,user));
CREATE TABLE IF NOT EXISTS monitors (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, name TEXT, kind TEXT, host TEXT, port INTEGER, state TEXT DEFAULT 'unknown', since INTEGER, ms INTEGER);
CREATE TABLE IF NOT EXISTS monitor_cfg (guild TEXT PRIMARY KEY, alert_channel TEXT, status_channel TEXT, status_message TEXT);
CREATE TABLE IF NOT EXISTS eco (guild TEXT, user TEXT, wallet INTEGER DEFAULT 0, bank INTEGER DEFAULT 0, PRIMARY KEY (guild,user));
CREATE TABLE IF NOT EXISTS eco_cd (guild TEXT, user TEXT, k TEXT, until INTEGER, PRIMARY KEY (guild,user,k));
CREATE TABLE IF NOT EXISTS inventory (guild TEXT, user TEXT, item TEXT, qty INTEGER DEFAULT 0, PRIMARY KEY (guild,user,item));
CREATE TABLE IF NOT EXISTS shop (guild TEXT, item TEXT, price INTEGER, descr TEXT, PRIMARY KEY (guild,item));
CREATE TABLE IF NOT EXISTS loans (guild TEXT, user TEXT, amount INTEGER, PRIMARY KEY (guild,user));
CREATE TABLE IF NOT EXISTS levels (guild TEXT, user TEXT, xp INTEGER DEFAULT 0, level INTEGER DEFAULT 0, PRIMARY KEY (guild,user));
CREATE TABLE IF NOT EXISTS level_cfg (guild TEXT PRIMARY KEY, channel TEXT, multiplier REAL DEFAULT 1, msg TEXT, announce INTEGER DEFAULT 1, voicexp INTEGER DEFAULT 0, no_channels TEXT DEFAULT '', no_roles TEXT DEFAULT '', boost_until INTEGER DEFAULT 0, boost_mult REAL DEFAULT 1, color TEXT);
CREATE TABLE IF NOT EXISTS level_roles (guild TEXT, level INTEGER, role TEXT, PRIMARY KEY (guild,level));
CREATE TABLE IF NOT EXISTS voice_time (guild TEXT, user TEXT, seconds INTEGER DEFAULT 0, PRIMARY KEY (guild,user));
CREATE TABLE IF NOT EXISTS tempvc_cfg (guild TEXT PRIMARY KEY, lobby TEXT, category TEXT);
CREATE TABLE IF NOT EXISTS tempvc (channel TEXT PRIMARY KEY, guild TEXT, owner TEXT);
CREATE TABLE IF NOT EXISTS giveaways (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, channel TEXT, message TEXT, prize TEXT, winners INTEGER, host TEXT, ends INTEGER, ended INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS gw_entries (gid INTEGER, user TEXT, PRIMARY KEY (gid,user));
CREATE TABLE IF NOT EXISTS reminders (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, channel TEXT, user TEXT, at INTEGER, text TEXT);
CREATE TABLE IF NOT EXISTS am (guild TEXT, rule TEXT, enabled INTEGER DEFAULT 0, punish TEXT DEFAULT 'delete', val TEXT, PRIMARY KEY (guild,rule));
CREATE TABLE IF NOT EXISTS am_words (guild TEXT, word TEXT, PRIMARY KEY (guild,word));
CREATE TABLE IF NOT EXISTS am_links (guild TEXT, domain TEXT, PRIMARY KEY (guild,domain));
CREATE TABLE IF NOT EXISTS wl (guild TEXT, id TEXT, PRIMARY KEY (guild,id));
CREATE TABLE IF NOT EXISTS sec_cfg (guild TEXT PRIMARY KEY, log_channel TEXT, nuke_on INTEGER DEFAULT 0, nuke_limit INTEGER DEFAULT 3, raid_on INTEGER DEFAULT 0, raid_limit INTEGER DEFAULT 8, alt_days INTEGER DEFAULT 0, antibot INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS extraowners (guild TEXT, user TEXT, PRIMARY KEY (guild,user));
`);

db.exec(`
CREATE TABLE IF NOT EXISTS kv (guild TEXT, k TEXT, v TEXT, PRIMARY KEY (guild,k));
CREATE TABLE IF NOT EXISTS todos (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, user TEXT, text TEXT, done INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS marriages (guild TEXT, a TEXT, b TEXT, at INTEGER, PRIMARY KEY (guild,a));
CREATE TABLE IF NOT EXISTS birthdays (guild TEXT, user TEXT, day INTEGER, month INTEGER, PRIMARY KEY (guild,user));
`);
export const kvGet = (g, k) => db.prepare('SELECT v FROM kv WHERE guild=? AND k=?').get(g, k)?.v ?? null;
export const kvSet = (g, k, v) => (v == null ? db.prepare('DELETE FROM kv WHERE guild=? AND k=?').run(g, k) : db.prepare('INSERT OR REPLACE INTO kv VALUES (?,?,?)').run(g, k, String(v)));

db.exec(`
CREATE TABLE IF NOT EXISTS playlists (id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, name TEXT, UNIQUE(user,name));
CREATE TABLE IF NOT EXISTS playlist_tracks (pid INTEGER, pos INTEGER, title TEXT, uri TEXT, length INTEGER);
CREATE TABLE IF NOT EXISTS tempbans (guild TEXT, user TEXT, until INTEGER, PRIMARY KEY (guild,user));
CREATE TABLE IF NOT EXISTS backups (id INTEGER PRIMARY KEY AUTOINCREMENT, guild TEXT, name TEXT, data TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS rr (guild TEXT, message TEXT, emoji TEXT, role TEXT, PRIMARY KEY (guild,message,emoji));
CREATE TABLE IF NOT EXISTS invite_log (guild TEXT, user TEXT, inviter TEXT, code TEXT, at INTEGER);
`);
try { db.exec('ALTER TABLE tickets ADD COLUMN rating INTEGER'); } catch {}
