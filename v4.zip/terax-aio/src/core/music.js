// Lavalink music manager (Shoukaku v4). One queue object per guild.
import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { config } from './config.js';
import { kvGet } from './db.js';
import { card, fail } from './ui.js';
import { safeHost } from './netguard.js';
import { clip } from './util.js';

export const queues = new Map();
export const fmtTime = (ms) => {
  if (!Number.isFinite(ms)) return 'LIVE';
  const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return `${h ? `${h}:${String(m).padStart(2, '0')}` : m}:${String(x).padStart(2, '0')}`;
};
export const musicOnline = (client) => !!client.shoukaku?.getIdealNode();
const btn = (id, emoji, style = ButtonStyle.Secondary) => new ButtonBuilder().setCustomId(id).setEmoji(emoji).setStyle(style);
export const controls = () => new ActionRowBuilder().addComponents(btn('mu:pause', '⏯️'), btn('mu:skip', '⏭️'), btn('mu:stop', '⏹️', ButtonStyle.Danger), btn('mu:loop', '🔁'), btn('mu:shuffle', '🔀'));

// Resolve a query or URL into normalized tracks.
export async function resolveQuery(client, query) {
  const node = client.shoukaku?.getIdealNode(); if (!node) throw new Error('NO_NODE');
  const isUrl = /^https?:\/\//i.test(query);
  if (isUrl) await safeHost(new URL(query).hostname); // never let Lavalink fetch internal addresses
  let r = await node.rest.resolve(isUrl ? query : `${config.music.defaultSource}:${query}`);
  if (!isUrl && (!r || r.loadType === 'empty' || r.loadType === 'error')) {
    for (const src of config.music.fallbackSources) { r = await node.rest.resolve(`${src}:${query}`); if (r?.loadType === 'search' && r.data.length) break; }
  }
  if (!r || r.loadType === 'empty') return { type: 'empty', tracks: [] };
  if (r.loadType === 'error') return { type: 'error', tracks: [], error: r.data?.message };
  if (r.loadType === 'track') return { type: 'track', tracks: [r.data] };
  if (r.loadType === 'playlist') return { type: 'playlist', tracks: r.data.tracks, name: r.data.info?.name };
  return { type: 'search', tracks: r.data };
}

export async function connect(client, guild, voiceId, text) {
  let q = queues.get(guild.id); if (q) return q;
  if (!client.shoukaku?.getIdealNode()) throw new Error('NO_NODE');
  const player = await client.shoukaku.joinVoiceChannel({ guildId: guild.id, channelId: voiceId, shardId: guild.shardId ?? 0, deaf: true });
  q = { guildId: guild.id, player, tracks: [], current: null, history: [], loop: 'off', volume: 100, autoplay: false, filters: {}, text, voiceId, idle: null };
  player.on('end', (e) => { if (['finished', 'loadFailed'].includes(e.reason)) advance(client, q).catch((x) => console.error('[music]', x)); });
  player.on('exception', (e) => { q.text?.send(fail('Playback error', clip(e?.exception?.message ?? 'The track could not be played.', 200))).catch(() => {}); });
  player.on('stuck', () => advance(client, q, true).catch(() => {}));
  player.on('closed', () => destroy(client, guild.id));
  queues.set(guild.id, q); return q;
}
export function destroy(client, guildId) {
  const q = queues.get(guildId); if (!q) return;
  clearTimeout(q.idle); queues.delete(guildId);
  try { client.shoukaku?.leaveVoiceChannel(guildId); } catch { /* already gone */ }
}
function nowPlaying(q) {
  const t = q.current.info;
  return card({ title: '🎶 Now playing', body: `**[${clip(t.title, 90)}](${t.uri})**\n${clip(t.author, 60)}`, thumb: t.artworkUrl || undefined,
    fields: [['Length', t.isStream ? 'LIVE' : fmtTime(t.length)], ['Requested by', `<@${q.current.requester}>`], ['Queue', `${q.tracks.length} up next`], ['Loop', q.loop]], rows: [controls()], foot: false, color: 'success' });
}
async function related(client, q) {
  const last = q.history.at(-1); if (!last) return null;
  const r = await resolveQuery(client, `${last.info.author} ${last.info.title.split(/[-(\[]/)[0]}`).catch(() => null);
  const seen = new Set(q.history.map((h) => h.info.uri));
  const t = r?.tracks.filter((x) => !seen.has(x.info.uri))[0];
  return t ? { ...t, requester: last.requester } : null;
}
export async function advance(client, q, skip = false) {
  clearTimeout(q.idle);
  if (q.current && !(q.loop === 'track' && !skip)) {
    q.history.push(q.current); if (q.history.length > 25) q.history.shift();
    if (q.loop === 'queue') q.tracks.push(q.current);
    q.current = null;
  }
  q.current ??= q.tracks.shift() ?? null;
  if (!q.current && q.autoplay) q.current = await related(client, q);
  if (!q.current) {
    await q.player.stopTrack().catch(() => {});
    q.text?.send(card({ title: '⏹️ Queue finished', body: 'Add more with `play`.', foot: false })).catch(() => {});
    q.idle = setTimeout(() => { if (!kvGet(q.guildId, '247')) destroy(client, q.guildId); }, config.music.idleLeaveSeconds * 1000);
    return false;
  }
  await q.player.playTrack({ track: { encoded: q.current.encoded } });
  q.text?.send(nowPlaying(q)).catch(() => {});
  return true;
}
export async function applyFilters(q) {
  const f = Object.values(q.filters).reduce((a, x) => ({ ...a, ...x, equalizer: [...(a.equalizer ?? []), ...(x.equalizer ?? [])] }), {});
  if (!f.equalizer?.length) delete f.equalizer;
  await (Object.keys(f).length ? q.player.setFilters(f) : q.player.clearFilters());
}
export async function rejoin247(client) {
  const { db } = await import('./db.js');
  for (const r of db.prepare("SELECT guild, v FROM kv WHERE k='247'").all()) {
    const g = client.guilds.cache.get(r.guild), vc = g?.channels.cache.get(r.v);
    if (g && vc && !queues.has(g.id)) await connect(client, g, vc.id, null).catch(() => {});
  }
}
