import fs from 'node:fs';
import path from 'node:path';
import 'dotenv/config';

const file = path.resolve('config.json');
export const config = JSON.parse(fs.readFileSync(file, 'utf8'));
export const env = { token: process.env.DISCORD_TOKEN, gemini: process.env.GEMINI_API_KEY };

export const saveConfig = () => fs.writeFileSync(file, JSON.stringify(config, null, 2));
export const isOwner = (id) => config.ownerIds.includes(id);
// allowAllServers=true disables the whitelist entirely; otherwise only IDs in allowedGuilds work.
export const isAllowed = (guildId) => config.allowAllServers === true || config.allowedGuilds.includes(guildId);
