import { ActivityType } from 'discord.js';
import { config } from './config.js';

let timer = null, idx = 0;
export const fillStatus = (client, t) => t
  .replace(/\{servers\}/g, client.guilds.cache.size).replace(/\{users\}/g, client.guilds.cache.reduce((a, g) => a + g.memberCount, 0))
  .replace(/\{commands\}/g, client.commands?.size ?? 0).replace(/\{prefix\}/g, config.prefix);
export function setPresence(client, text) {
  client.user.setPresence({ status: config.status.type, activities: [{ name: 'custom', state: fillStatus(client, text).slice(0, 128), type: ActivityType.Custom }] });
}
export function rotateNow(client) {
  const list = config.statuses?.length ? config.statuses : [config.status.text];
  setPresence(client, list[idx++ % list.length]);
}
// (Re)start rotation from config. Safe to call any time settings change.
export function restartStatus(client) {
  clearInterval(timer); timer = null;
  const r = config.statusRotate ?? {};
  if (!r.enabled) return setPresence(client, config.status.text);
  rotateNow(client);
  timer = setInterval(() => rotateNow(client), Math.min(Math.max(+r.intervalMinutes || 15, 1), 1440) * 60000);
}
export const startStatus = restartStatus;
