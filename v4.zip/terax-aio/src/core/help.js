import { ActionRowBuilder, StringSelectMenuBuilder } from 'discord.js';
import { card } from './ui.js';
import { clip } from './util.js';

export const CAT = {
  owner: ['👑', 'Owner'], admin: ['⚙️', 'Admin'], moderation: ['🛡️', 'Moderation'], ticket: ['🎫', 'Tickets'],
  ai: ['🤖', 'AI'], info: ['📚', 'Info'], hosting: ['🦕', 'Hosting & Pterodactyl'], voice: ['🔊', 'Voice'], economy: ['🪙', 'Economy'], leveling: ['⭐', 'Leveling'], fun: ['🎮', 'Fun & Games'], security: ['🔒', 'Automod & Security'], community: ['🎉', 'Community'], utility: ['🧰', 'Utility'],
};
export function categories(client, showOwner) {
  const out = {};
  for (const c of client.commands.values()) {
    if (c.category === 'owner' && !showOwner) continue;
    (out[c.category] ??= []).push(c);
  }
  return out;
}
const menu = (cats) => new ActionRowBuilder().addComponents(
  new StringSelectMenuBuilder().setCustomId('help:menu').setPlaceholder('Choose a category')
    .addOptions(Object.keys(cats).map((k) => ({ label: CAT[k]?.[1] ?? k, value: k, emoji: CAT[k]?.[0] ?? '📁', description: `${cats[k].length} commands` }))));

export function helpHome(client, prefix, showOwner) {
  const cats = categories(client, showOwner);
  const total = Object.values(cats).flat().length;
  return card({
    title: '📖 Help', body: `Prefix: \`${prefix}\` • **${total}** commands\nUse \`${prefix}help <command>\` for details, or pick a category below.`,
    fields: Object.entries(cats).map(([k, v]) => [`${CAT[k]?.[0] ?? '📁'} ${CAT[k]?.[1] ?? k}`, `${v.length} commands`]),
    rows: [menu(cats)],
  });
}
export function helpCategory(client, key, prefix, showOwner) {
  const cats = categories(client, showOwner);
  const list = (cats[key] ?? []).map((c) => `\`${c.name}\``).join(' ');
  return card({ title: `${CAT[key]?.[0] ?? '📁'} ${CAT[key]?.[1] ?? key}`, body: clip(list || 'Nothing here.', 2000) + `\n\n-# ${prefix}help <command> for details`, rows: [menu(cats)] });
}
