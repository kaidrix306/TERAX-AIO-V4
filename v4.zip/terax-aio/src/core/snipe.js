export const snipes = new Map(), esnipes = new Map();
const TTL = 10 * 60 * 1000;
export const put = (map, ch, v) => map.set(ch, { ...v, at: Date.now() });
export const get = (map, ch) => { const v = map.get(ch); return v && Date.now() - v.at < TTL ? v : null; };
