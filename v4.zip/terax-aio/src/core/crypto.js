import crypto from 'node:crypto';
let key;
const k = () => {
  if (!process.env.ENCRYPTION_KEY) throw new Error('Set ENCRYPTION_KEY in .env first (any long random string).');
  return (key ??= crypto.scryptSync(process.env.ENCRYPTION_KEY, 'terax-aio-v1', 32));
};
export function enc(text) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', k(), iv);
  const e = Buffer.concat([c.update(text, 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), e].map((b) => b.toString('base64')).join('.');
}
export function dec(s) {
  const [iv, tag, e] = s.split('.').map((x) => Buffer.from(x, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', k(), iv); d.setAuthTag(tag);
  return Buffer.concat([d.update(e), d.final()]).toString('utf8');
}
