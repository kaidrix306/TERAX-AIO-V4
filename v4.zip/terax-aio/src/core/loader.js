import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// Each command file may export one command object or an array of them.
export async function loadCommands(client, dir = 'src/commands') {
  client.commands = new Map();
  client.aliases = new Map();
  const walk = async (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { await walk(p); continue; }
      if (!e.name.endsWith('.js')) continue;
      const mod = await import(`${pathToFileURL(path.resolve(p)).href}?v=${Date.now()}`);
      for (const c of [].concat(mod.default)) {
        if (!c?.name) continue;
        c.category ??= path.basename(path.dirname(p));
        client.commands.set(c.name, c);
        for (const a of c.aliases ?? []) client.aliases.set(a, c.name);
      }
    }
  };
  await walk(dir);
  return client.commands.size;
}
