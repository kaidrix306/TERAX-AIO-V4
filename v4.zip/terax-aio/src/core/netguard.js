// Blocks private/internal targets so network tools cannot be used to scan your own network.
import dns from 'node:dns/promises';
import net from 'node:net';

export function privateIP(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const l = ip.toLowerCase();
  return l === '::1' || l === '::' || l.startsWith('fe80') || l.startsWith('fc') || l.startsWith('fd') || (l.startsWith('::ffff:') && privateIP(l.slice(7)));
}
export async function safeHost(input) {
  let h = String(input ?? '').trim().toLowerCase().replace(/^[a-z]+:\/\//, '').split('/')[0];
  if (!net.isIP(h)) h = h.replace(/:\d+$/, '');
  if (!net.isIP(h) && !/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/.test(h)) throw new Error('Invalid host.');
  const ips = net.isIP(h) ? [h] : (await dns.lookup(h, { all: true }).catch(() => [])).map((a) => a.address);
  if (!ips.length) throw new Error('That host did not resolve.');
  if (ips.some(privateIP)) throw new Error('Private or internal addresses are blocked.');
  return { host: h, ip: ips[0], ips };
}
