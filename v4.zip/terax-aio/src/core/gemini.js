import { config, env } from './config.js';

export async function gemini({ system, prompt, maxTokens = 700 }) {
  if (!env.gemini) throw new Error('NO_KEY');
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${config.ai.model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.gemini },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { maxOutputTokens: maxTokens, temperature: 0.6 },
    }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`GEMINI_${res.status}`);
  const j = await res.json();
  const out = j.candidates?.[0]?.content?.parts?.map((p) => p.text).join('').trim();
  if (!out) throw new Error('GEMINI_EMPTY');
  return out;
}
export function aiError(e) {
  if (e.message === 'NO_KEY') return 'The Gemini API key is not configured.';
  if (e.message === 'GEMINI_429') return 'The free AI quota is used up for now. Try again in a minute.';
  return 'The AI could not answer right now. Please try again later.';
}
