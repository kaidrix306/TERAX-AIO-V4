import { db } from './db.js';
import { card } from './ui.js';
import { isOwner } from './config.js';

export const secCfg = (g) => { db.prepare('INSERT OR IGNORE INTO sec_cfg(guild) VALUES (?)').run(g); return db.prepare('SELECT * FROM sec_cfg WHERE guild=?').get(g); };
export const raid = new Map(); // guildId -> lockdown-until timestamp
export function isWhitelisted(guildId, member) {
  const ids = [member.id, ...member.roles.cache.keys()];
  return ids.some((id) => db.prepare('SELECT 1 FROM wl WHERE guild=? AND id=?').get(guildId, id));
}
export const isTrusted = (guild, id) => id === guild.ownerId || isOwner(id) || !!db.prepare('SELECT 1 FROM extraowners WHERE guild=? AND user=?').get(guild.id, id) || !!db.prepare('SELECT 1 FROM wl WHERE guild=? AND id=?').get(guild.id, id);
export async function slog(client, guild, title, body, color = 'warning') {
  const c = secCfg(guild.id).log_channel; if (!c) return;
  (await client.channels.fetch(c).catch(() => null))?.send(card({ title, body, color })).catch(() => {});
}
