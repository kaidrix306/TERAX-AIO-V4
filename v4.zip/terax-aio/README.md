# TeraX AIO

Multipurpose prefix-only Discord bot by **TeraX Development** — Lead Dev: **Kaidrix**.
Built on discord.js v14, Components V2 replies, SQLite (better-sqlite3).

## Setup
1. Node 20+. Run `npm install`.
2. Copy `.env.example` to `.env`, then add `DISCORD_TOKEN` and `GEMINI_API_KEY` (free: https://aistudio.google.com/apikey).
3. Edit `config.json`: add your user ID to `ownerIds` and your server ID(s) to `allowedGuilds`.
4. In the Developer Portal enable the **Server Members** and **Message Content** intents.
5. `npm start` (use pm2 for 24/7 and for the `restart` command).

## Server whitelist
The bot only works in servers listed in `config.json -> allowedGuilds`. It leaves any other server on startup and on join.
Owner commands: `allowguild <id>`, `disallowguild <id>`, `allowedguilds`.

## DM policy
Nothing is DM-only. When the bot DMs someone it also posts a short notice in chat (e.g. "Check your DMs"); if DMs are closed it says so in chat.
Admins can turn punishment DMs off with `dmnotices off`.

## Tickets + AI
`ticketsetup category <id>`, `ticketsetup role @staff`, `ticketsetup log #logs`, then `ticketpanel`.
The AI answers the ticket owner until staff claim, speak, or the user runs `human`. Add FAQ/rules with `aiprompt <text>`.
AI uses a per-ticket cooldown and falls back to "Staff will be with you shortly" if the free quota is hit.

## Adding commands
Drop a file in `src/commands/<category>/`. It can export one command object or an array. Run `reload` as owner.

## v2 additions
- **Hosting & Pterodactyl (70):** `pteroset <url>` (server owner only) links the panel; the Application (`ptla_`) and Client (`ptlc_`) keys are sent by DM, validated, and stored AES-256-GCM encrypted (set `ENCRYPTION_KEY` in `.env`).
  Roles: `pteroperms admin|staff|customer @role`. Customers use `pterolink` to link their own client key and only control servers their own account can access.
  Destructive actions (`pterokill`, `pterodelete`, `pterorestorebackup`, `pteroreinstall`, `pteroremove`, `pterodeluser`) need a confirm button and are logged to `pterolog`.
  Network tools block private/internal IPs. Monitoring: `vpsadd`, `monitor`, `statuspage`, `monitoralerts`.
- **Voice (31), Economy (40), Leveling (18), Fun (46), Security (26), Community (35), Utility (30).**
- Enable the **Server Members**, **Message Content** intents; Direct Messages and reactions work with the default intents.
- Antinuke/antibot need the **View Audit Log**, **Ban Members**, **Manage Roles** permissions, and the bot's role must sit above the roles it protects.

## Not built yet
Music (needs Lavalink), image-manipulation commands, modmail, invite tracking, welcome/autorole/reaction roles/custom commands, backups, and some extra owner/moderation commands.

## v3 additions
- **Music via Lavalink (40 commands):** play/search/queue/loop/seek/filters/playlists/DJ role/music channel, control buttons, 24/7 mode, auto-leave when alone.
  Run a Lavalink **v4** node (see `lavalink/`), then set `LAVALINK_HOST`, `LAVALINK_PORT`, `LAVALINK_PASSWORD` in `.env`. YouTube needs the youtube-source plugin and breaks occasionally; SoundCloud/direct links are more stable.
  The `lyrics` command links to a lyrics site instead of copying lyrics text.
- **Admin/config:** welcome/leave, autorole, reaction roles, custom commands, autoresponders, roles/channels backup & restore, nuke, roleall, disable/ignore settings.
- **Moderation (51):** tempban, massban/masskick, purge filters, lockdown, snipe, jail/quarantine, strikes, risk score and more.
- **Tickets (28):** ratings, blacklist, staff stats, auto-close with a warning. **Modmail** (members DM the bot; staff reply from a private channel), **invite tracking**, **scheduled events**, **AI channel + persona**.
- **Owner extras:** broadcast, addowner/removeowner, noprefix, botlogs, setbanner, cache.
- No image-manipulation commands (by request).

## Known gaps
Appeals (banned users are not in the server, so they cannot be reached without DMs), panel node-offline alerts, setlang/translations, and the premium system.
Everything was tested with stub packages only; run it against a real Discord bot and Lavalink node and report errors.

## v4 additions
- **All-servers switch:** `config.json -> allowAllServers`. `false` (default) = only IDs in `allowedGuilds` work; `true` = whitelist off, works everywhere. Owner command `allowall on|off` flips it live.
  An empty `allowedGuilds` with the switch off means the bot is allowed **nowhere**.
- **Rotating status:** `statuses` + `statusRotate` in `config.json` (default every 15 min). Placeholders: `{servers} {users} {commands} {prefix}`.
  Owner command `statusrotate list|on|off|now|interval <min>|add <text>|remove <n>`. `setstatus` pins one status and turns rotation off.
