import dns from 'node:dns/promises';
import net from 'node:net';
import tls from 'node:tls';
import dgram from 'node:dgram';
import { execFile } from 'node:child_process';
import { db } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { safeHost, privateIP } from '../../core/netguard.js';
import { tcp, check } from '../../core/monitor.js';
import { clip, getChannel } from '../../core/util.js';
import { PermissionFlagsBits as P } from 'discord.js';

// Wrap a command so network errors become friendly replies.
const H = (o) => ({ category: 'hosting', cooldown: 6, ...o, async run(ctx) {
  try { return await o.run(ctx); } catch (e) { return ctx.message.reply(fail('Lookup failed', clip(e.code === 'ENOTFOUND' ? 'Host not found.' : e.message, 250))); }
} });
const need = (c, ctx) => !ctx.args[0] && ctx.message.reply(usage(c, ctx.prefix));
const domainOk = (d) => /^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/i.test(d ?? '');
const json = async (url) => { const r = await fetch(url, { signal: AbortSignal.timeout(10000) }); if (!r.ok) throw new Error(`Service returned HTTP ${r.status}`); return r.json(); };
const whoisQ = (server, q) => new Promise((res, rej) => {
  const s = net.connect({ host: server, port: 43, timeout: 8000 }); let d = '';
  s.on('connect', () => s.write(`${q}\r\n`)); s.on('data', (c) => (d += c)); s.on('end', () => res(d));
  s.on('timeout', () => { s.destroy(); rej(new Error('WHOIS timed out')); }); s.on('error', rej);
});
const hostPort = (a) => { const m = String(a ?? '').match(/^(.*?)(?::(\d{1,5}))?$/); return [m[1], m[2] ? +m[2] : null]; };

async function followRedirects(start) {
  const hops = []; let url = start;
  for (let i = 0; i < 8; i++) {
    const u = new URL(url); await safeHost(u.hostname);
    const t = Date.now(), r = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(8000) });
    hops.push({ url, status: r.status, ms: Date.now() - t, headers: r.headers });
    const loc = r.headers.get('location'); if (r.status < 300 || r.status >= 400 || !loc) break;
    url = new URL(loc, url).href;
  }
  return hops;
}
function a2s(ip, port) {
  return new Promise((res, rej) => {
    const s = dgram.createSocket('udp4'), q = (ch) => Buffer.concat([Buffer.from([0xff, 0xff, 0xff, 0xff, 0x54]), Buffer.from('Source Engine Query\0'), ch ?? Buffer.alloc(0)]);
    const timer = setTimeout(() => { s.close(); rej(new Error('No response (check the query port).')); }, 5000);
    s.on('message', (m) => {
      if (m[4] === 0x41) return s.send(q(m.subarray(5, 9)), port, ip);
      clearTimeout(timer); s.close();
      let o = 6; const str = () => { const e = m.indexOf(0, o); const v = m.toString('utf8', o, e); o = e + 1; return v; };
      const name = str(), map = str(); str(); str(); o += 2; res({ name, map, players: m[o], max: m[o + 1] });
    });
    s.on('error', (e) => { clearTimeout(timer); rej(e); }); s.send(q(), port, ip);
  });
}

export default [
  H({ name: 'dns', description: 'DNS records for a domain', usage: 'dns <domain> [A|AAAA|MX|NS|TXT|CNAME]', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const d = ctx.args[0].toLowerCase(); if (!domainOk(d)) throw new Error('Invalid domain.');
    const types = ctx.args[1] ? [ctx.args[1].toUpperCase()] : ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT'];
    if (!types.every((t) => ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SRV', 'SOA'].includes(t))) throw new Error('Unsupported record type.');
    const out = await Promise.all(types.map(async (t) => { const r = await dns.resolve(d, t).catch(() => null); return r?.length ? [t, clip(r.map((x) => typeof x === 'object' ? (x.exchange ? `${x.priority} ${x.exchange}` : JSON.stringify(x)) : Array.isArray(x) ? x.join('') : x).join('\n'), 300)] : null; }));
    return ctx.message.reply(card({ title: `<:link:1461688818297208894> DNS • ${d}`, body: out.filter(Boolean).map(([t, v]) => `**${t}**\n${v}`).join('\n\n') || 'No records found.' }));
  } }),
  H({ name: 'whois', description: 'Domain WHOIS', usage: 'whois <domain>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const d = ctx.args[0].toLowerCase(); if (!domainOk(d)) throw new Error('Invalid domain.');
    let r = await whoisQ('whois.iana.org', d); const ref = r.match(/^refer:\s*(\S+)/im)?.[1];
    if (ref) r = await whoisQ(ref, d);
    return ctx.message.reply(card({ title: `📇 WHOIS • ${d}`, body: '```\n' + clip(r.split('\n').filter((l) => l.trim() && !l.startsWith('%') && !l.startsWith('>>>')).join('\n'), 1800) + '\n```' }));
  } }),
  H({ name: 'ipinfo', aliases: ['ip'], description: 'Location and ISP of an IP or host', usage: 'ipinfo <ip|host>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const { ip } = await safeHost(ctx.args[0]);
    const j = await json(`http://ip-api.com/json/${ip}?fields=status,message,country,regionName,city,isp,org,as,reverse,timezone,hosting`);
    if (j.status !== 'success') throw new Error(j.message);
    return ctx.message.reply(card({ title: `📍 ${ip}`, fields: [['Location', `${j.city}, ${j.regionName}, ${j.country}`], ['ISP', j.isp], ['Org', j.org || '—'], ['ASN', j.as], ['Reverse DNS', j.reverse || '—'], ['Timezone', j.timezone], ['Hosting/Proxy', j.hosting ? 'Yes' : 'No']] }));
  } }),
  H({ name: 'reversedns', aliases: ['rdns'], description: 'Reverse DNS of an IP', usage: 'reversedns <ip>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; if (!net.isIP(ctx.args[0]) || privateIP(ctx.args[0])) throw new Error('Give a public IP address.');
    const r = await dns.reverse(ctx.args[0]).catch(() => []); return ctx.message.reply(card({ title: `<:reset:1461683691813208075> ${ctx.args[0]}`, body: r.join('\n') || 'No PTR record.' }));
  } }),
  H({ name: 'mxlookup', aliases: ['mx'], description: 'Mail servers of a domain', usage: 'mxlookup <domain>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; if (!domainOk(ctx.args[0])) throw new Error('Invalid domain.');
    const r = (await dns.resolveMx(ctx.args[0]).catch(() => [])).sort((a, b) => a.priority - b.priority);
    return ctx.message.reply(card({ title: `✉️ MX • ${ctx.args[0]}`, body: r.map((x) => `${x.priority} — ${x.exchange}`).join('\n') || 'No MX records.' }));
  } }),
  H({ name: 'asnlookup', aliases: ['asn'], description: 'ASN and network owner of an IP/host', usage: 'asnlookup <ip|host>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const { ip } = await safeHost(ctx.args[0]);
    const j = await json(`http://ip-api.com/json/${ip}?fields=status,message,as,asname,isp,org`); if (j.status !== 'success') throw new Error(j.message);
    return ctx.message.reply(card({ title: `<:status:1461683996302901515> ${ip}`, fields: [['ASN', j.as], ['Name', j.asname], ['ISP', j.isp], ['Org', j.org || '—']] }));
  } }),
  H({ name: 'subnet', description: 'IPv4 CIDR calculator', usage: 'subnet <ip/prefix>', async run(ctx) {
    const m = /^(\d{1,3}(?:\.\d{1,3}){3})\/(\d|[12]\d|3[0-2])$/.exec(ctx.args[0] ?? ''); if (!m || !net.isIPv4(m[1])) return ctx.message.reply(usage(ctx.cmd, ctx.prefix));
    const p = +m[2], ip = m[1].split('.').reduce((a, o) => (a << 8n) + BigInt(o), 0n), size = 2n ** BigInt(32 - p), mask = ((2n ** 32n - 1n) << BigInt(32 - p)) & (2n ** 32n - 1n), net0 = ip & mask;
    const s = (n) => [24n, 16n, 8n, 0n].map((b) => (n >> b) & 255n).join('.');
    return ctx.message.reply(card({ title: `🧮 ${m[1]}/${p}`, fields: [['Network', s(net0)], ['Broadcast', s(net0 + size - 1n)], ['Netmask', s(mask)], ['First host', p >= 31 ? '—' : s(net0 + 1n)], ['Last host', p >= 31 ? '—' : s(net0 + size - 2n)], ['Usable hosts', p >= 31 ? String(size) : String(size - 2n)]] }));
  } }),
  H({ name: 'hostping', aliases: ['ping2'], description: 'TCP ping (default port 443)', usage: 'hostping <host> [port]', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const { ip, host } = await safeHost(ctx.args[0]), port = parseInt(ctx.args[1]) || 443, r = [];
    for (let i = 0; i < 4; i++) r.push(await tcp(ip, port, 4000));
    const up = r.filter((x) => x.up).map((x) => x.ms);
    return ctx.message.reply(card({ title: `🏓 ${host}:${port}`, color: up.length ? 'success' : 'error', fields: [['Sent / received', `4 / ${up.length}`], ['Min', up.length ? `${Math.min(...up)}ms` : '—'], ['Avg', up.length ? `${Math.round(up.reduce((a, b) => a + b) / up.length)}ms` : '—'], ['Max', up.length ? `${Math.max(...up)}ms` : '—'], ['IP', ip]] }));
  } }),
  H({ name: 'traceroute', aliases: ['tracert'], description: 'Trace the route to a host (runs from the bot host)', usage: 'traceroute <host>', cooldown: 20, async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const { ip, host } = await safeHost(ctx.args[0]); const m = await ctx.message.reply(card({ title: '🛣️ Tracing…', body: host }));
    execFile('traceroute', ['-n', '-m', '15', '-w', '2', ip], { timeout: 40000 }, (err, out) => {
      if (err && err.code === 'ENOENT') return m.edit(fail('Unavailable', 'The `traceroute` tool is not installed on the bot host.')).catch(() => {});
      m.edit(card({ title: `🛣️ ${host}`, body: '```\n' + clip(out || err?.message, 1800) + '\n```' })).catch(() => {});
    });
  } }),
  H({ name: 'portcheck', aliases: ['port'], description: 'Check if a TCP port is open', usage: 'portcheck <host> <port>', async run(ctx) {
    const port = parseInt(ctx.args[1]); if (!ctx.args[0] || !(port > 0 && port < 65536)) return ctx.message.reply(usage(ctx.cmd, ctx.prefix));
    const { ip, host } = await safeHost(ctx.args[0]), r = await tcp(ip, port, 5000);
    return ctx.message.reply(card({ title: `<:node:1461685228555862097> ${host}:${port}`, color: r.up ? 'success' : 'error', body: r.up ? `**Open** — ${r.ms}ms` : '**Closed or filtered**' }));
  } }),
  H({ name: 'ssl', aliases: ['cert'], description: 'SSL certificate details', usage: 'ssl <host> [port]', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const { ip, host } = await safeHost(ctx.args[0]), port = parseInt(ctx.args[1]) || 443;
    const c = await new Promise((res, rej) => { const s = tls.connect({ host: ip, port, servername: host, rejectUnauthorized: false, timeout: 6000 }, () => { const x = s.getPeerCertificate(); const ok = s.authorized; s.end(); res({ ...x, ok }); }); s.on('error', rej); s.on('timeout', () => { s.destroy(); rej(new Error('TLS timeout')); }); });
    const days = Math.floor((new Date(c.valid_to) - Date.now()) / 864e5);
    return ctx.message.reply(card({ title: `<:lock:1461684070600802314> ${host}`, color: days > 14 ? 'success' : days > 0 ? 'warning' : 'error', fields: [['Subject', c.subject?.CN ?? '—'], ['Issuer', c.issuer?.O ?? c.issuer?.CN ?? '—'], ['Valid from', c.valid_from], ['Expires', `${c.valid_to} (${days} days)`], ['Trusted', c.ok ? 'Yes' : 'No'], ['SANs', clip(c.subjectaltname ?? '—', 200)]] }));
  } }),
  H({ name: 'httpcheck', aliases: ['http'], description: 'HTTP status and response time', usage: 'httpcheck <url>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const h = await followRedirects(/^https?:\/\//i.test(ctx.args[0]) ? ctx.args[0] : `https://${ctx.args[0]}`), l = h.at(-1);
    return ctx.message.reply(card({ title: `<:server:1461685023857053717> ${new URL(l.url).hostname}`, color: l.status < 400 ? 'success' : 'error', fields: [['Status', l.status], ['Time', `${l.ms}ms`], ['Hops', h.length], ['Server', l.headers.get('server') ?? '—'], ['Type', l.headers.get('content-type') ?? '—']] }));
  } }),
  H({ name: 'headers', description: 'HTTP response headers', usage: 'headers <url>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const l = (await followRedirects(/^https?:\/\//i.test(ctx.args[0]) ? ctx.args[0] : `https://${ctx.args[0]}`)).at(-1);
    return ctx.message.reply(card({ title: `<:list:1461683931546910917> ${l.status} • ${new URL(l.url).hostname}`, body: '```\n' + clip([...l.headers].map(([k, v]) => `${k}: ${clip(v, 80)}`).join('\n'), 1800) + '\n```' }));
  } }),
  H({ name: 'redirects', description: 'Follow a URL\'s redirect chain', usage: 'redirects <url>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const h = await followRedirects(/^https?:\/\//i.test(ctx.args[0]) ? ctx.args[0] : `https://${ctx.args[0]}`);
    return ctx.message.reply(card({ title: `↪️ ${h.length} hop(s)`, body: clip(h.map((x, i) => `${i + 1}. **${x.status}** ${clip(x.url, 90)} (${x.ms}ms)`).join('\n'), 1900) }));
  } }),

  // ---- Game servers ----
  H({ name: 'mcstatus', aliases: ['minecraft'], description: 'Minecraft Java server status', usage: 'mcstatus <host[:port]>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; if (!/^[a-z0-9.:-]{3,100}$/i.test(ctx.args[0])) throw new Error('Invalid address.');
    const j = await json(`https://api.mcstatus.io/v2/status/java/${encodeURIComponent(ctx.args[0])}`);
    return ctx.message.reply(card({ title: `⛏️ ${ctx.args[0]}`, color: j.online ? 'success' : 'error', body: j.online ? clip(j.motd?.clean ?? '', 200) : 'Offline', fields: j.online ? [['Players', `${j.players.online}/${j.players.max}`], ['Version', j.version?.name_clean ?? '—'], ['Latency', j.retrieved_at ? 'live' : '—']] : [] }));
  } }),
  H({ name: 'mcplayers', description: 'Players online on a Minecraft server', usage: 'mcplayers <host[:port]>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; if (!/^[a-z0-9.:-]{3,100}$/i.test(ctx.args[0])) throw new Error('Invalid address.');
    const j = await json(`https://api.mcstatus.io/v2/status/java/${encodeURIComponent(ctx.args[0])}`);
    if (!j.online) return ctx.message.reply(fail('Offline', 'The server did not respond.'));
    return ctx.message.reply(card({ title: `<:participants:1461683985762484446> ${j.players.online}/${j.players.max} online`, body: clip(j.players.list?.map((p) => p.name_clean).join(', ') || 'No player list available (server may hide it).', 1800) }));
  } }),
  H({ name: 'fivemstatus', aliases: ['fivem'], description: 'FiveM server status', usage: 'fivemstatus <host[:port]>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const [h, p] = hostPort(ctx.args[0]), { ip } = await safeHost(h), base = `http://${ip}:${p ?? 30120}`;
    const [info, pl] = await Promise.all([json(`${base}/info.json`), json(`${base}/players.json`)]);
    return ctx.message.reply(card({ title: `🚗 ${h}`, color: 'success', fields: [['Players', `${pl.length}/${info.vars?.sv_maxClients ?? '?'}`], ['Server', clip(info.server ?? '—', 60)], ['Name', clip(info.vars?.sv_projectName ?? info.vars?.sv_hostname ?? '—', 80)], ['Resources', info.resources?.length ?? '—']] }));
  } }),
  H({ name: 'ruststatus', aliases: ['a2s'], description: 'Rust / Source-engine server status (query port)', usage: 'ruststatus <host:queryport>', async run(ctx) {
    if (await need(ctx.cmd, ctx)) return; const [h, p] = hostPort(ctx.args[0]); if (!p) throw new Error('Include the query port, e.g. host:28017');
    const { ip } = await safeHost(h), r = await a2s(ip, p);
    return ctx.message.reply(card({ title: `🦀 ${clip(r.name, 80)}`, color: 'success', fields: [['Players', `${r.players}/${r.max}`], ['Map', r.map], ['Address', `${h}:${p}`]] }));
  } }),

  // ---- Monitoring ----
  ...[['vpsadd', 'tcp'], ['monitor', 'http']].map(([name, kind]) => H({ name, description: kind === 'tcp' ? 'Monitor a VPS/host via TCP port' : 'Monitor a website URL', usage: kind === 'tcp' ? 'vpsadd <name> <host> [port=22]' : 'monitor <url> [name]', perms: [P.ManageGuild], async run(ctx) {
    const { message, args, guildRow } = ctx; if (args.length < 2 && kind === 'tcp' || !args[0]) return message.reply(usage(ctx.cmd, ctx.prefix));
    if (db.prepare('SELECT COUNT(*) c FROM monitors WHERE guild=?').get(message.guild.id).c >= 15) throw new Error('Limit reached (15 monitors).');
    let target, port = null, label;
    if (kind === 'tcp') { label = args[0]; target = (await safeHost(args[1])).host; port = parseInt(args[2]) || 22; if (port < 1 || port > 65535) throw new Error('Bad port.'); }
    else { target = /^https?:\/\//i.test(args[0]) ? args[0] : `https://${args[0]}`; await safeHost(new URL(target).hostname); label = args.slice(1).join(' ') || new URL(target).hostname; }
    const r = await check({ kind, host: target, port });
    db.prepare('INSERT INTO monitors(guild,name,kind,host,port,state,since,ms) VALUES (?,?,?,?,?,?,?,?)').run(message.guild.id, clip(label, 40), kind, target, port, r.up ? 'up' : 'down', Date.now(), r.ms);
    return message.reply(ok('Monitor added', `**${label}** is currently ${r.up ? '<:enabled:1461688785589895333> up' : '<:disabled:1461688795819937837> down'}. Set an alert channel with \`monitoralerts\`.`));
  } })),
  ...[['vpsremove', 'tcp'], ['monitorremove', 'http']].map(([name, kind]) => H({ name, description: 'Remove a monitor by name or ID', usage: `${name} <name|id>`, perms: [P.ManageGuild], async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix)); const q = args.join(' ');
    const r = db.prepare('DELETE FROM monitors WHERE guild=? AND kind=? AND (id=? OR name=?)').run(message.guild.id, kind, /^\d+$/.test(q) ? +q : -1, q);
    return message.reply(r.changes ? ok('Monitor removed') : fail('Not found', 'No monitor with that name/ID.'));
  } })),
  ...[['vpslist', 'tcp'], ['monitors', 'http']].map(([name, kind]) => H({ name, description: `List ${kind === 'tcp' ? 'VPS' : 'website'} monitors`, usage: name, async run({ message }) {
    const rows = db.prepare('SELECT * FROM monitors WHERE guild=? AND kind=?').all(message.guild.id, kind);
    return message.reply(card({ title: kind === 'tcp' ? '<:server:1461685023857053717> VPS monitors' : '<:server:1461685023857053717> Website monitors', body: rows.map((m) => `${m.state === 'up' ? '<:enabled:1461688785589895333>' : m.state === 'down' ? '<:disabled:1461688795819937837>' : '⚪'} \`${m.id}\` **${m.name}** — ${m.kind === 'tcp' ? `${m.host}:${m.port}` : clip(m.host, 50)}${m.ms ? ` (${m.ms}ms)` : ''}`).join('\n') || 'None yet.' }));
  } })),
  H({ name: 'vpsstatus', description: 'Live status of all monitors', usage: 'vpsstatus', async run({ message }) {
    const rows = db.prepare('SELECT * FROM monitors WHERE guild=?').all(message.guild.id);
    await message.channel.sendTyping().catch(() => {}); const res = await Promise.all(rows.map((m) => check(m)));
    return message.reply(card({ title: '<:status:1461683996302901515> Live status', body: rows.map((m, i) => `${res[i].up ? '<:enabled:1461688785589895333>' : '<:disabled:1461688795819937837>'} **${m.name}** ${res[i].ms ? `${res[i].ms}ms` : 'down'}`).join('\n') || 'No monitors. Add one with `vpsadd` or `monitor`.' }));
  } }),
  ...[['statuspage', 'status_channel', 'Auto-updating status page channel'], ['monitoralerts', 'alert_channel', 'Channel for up/down alerts']].map(([name, col, d]) => H({ name, description: d, usage: `${name} <#channel|off>`, perms: [P.ManageGuild], async run({ message, args, prefix, cmd }) {
    const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix));
    db.prepare('INSERT OR IGNORE INTO monitor_cfg(guild) VALUES (?)').run(message.guild.id);
    db.prepare(`UPDATE monitor_cfg SET ${col}=?${col === 'status_channel' ? ', status_message=NULL' : ''} WHERE guild=?`).run(c?.id ?? null, message.guild.id);
    return message.reply(ok(name, c ? `<#${c.id}>` : 'Disabled'));
  } })),
];
