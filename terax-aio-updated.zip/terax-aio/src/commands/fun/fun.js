import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { card, ok, fail, warn, usage, eph } from '../../core/ui.js';
import { pick, rnd } from '../../core/eco.js';
import { getMember, clip } from '../../core/util.js';

const F = (o) => ({ category: 'fun', cooldown: 3, ...o });
const list = (name, desc, title, items, aliases = []) => F({ name, aliases, description: desc, usage: name, run: ({ message }) => message.reply(card({ title, body: pick(items) })) });
const json = async (url) => { const r = await fetch(url, { signal: AbortSignal.timeout(8000) }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); };
const imageCmd = (name, desc, getUrl, title) => F({ name, description: desc, usage: name, cooldown: 5, async run({ message }) {
  try { const url = await getUrl(); return message.reply(card({ title, image: url })); } catch { return message.reply(fail('Unavailable', 'The image service did not respond. Try again later.')); }
} });
const action = (name, verb, emoji, self) => F({ name, description: `${name[0].toUpperCase() + name.slice(1)} someone`, usage: `${name} <member>`, async run({ message, args }) {
  const t = await getMember(message, args[0]);
  return message.reply(card({ title: `${emoji} ${name}`, body: t && t.id !== message.author.id ? `**${message.member.displayName}** ${verb} **${t.displayName}**!` : self.replace('{u}', `**${message.member.displayName}**`) }));
} });
const solo = (name, text, emoji) => F({ name, description: `Express: ${name}`, usage: name, run: ({ message }) => message.reply(card({ title: `${emoji} ${name}`, body: text.replace('{u}', `**${message.member.displayName}**`) })) });
const waitMsg = (message, filter, time = 20000) => message.channel.awaitMessages({ filter: (m) => !m.author.bot && filter(m), max: 1, time, errors: ['time'] }).then((c) => c.first(), () => null);
const shuffle = (s) => [...s].sort(() => Math.random() - 0.5).join('');

const EIGHT = ['It is certain.', 'Without a doubt.', 'Yes, definitely.', 'Most likely.', 'Signs point to yes.', 'Ask again later.', 'Cannot predict now.', "Don't count on it.", 'My sources say no.', 'Very doubtful.'];
const TRIVIA = [['What is the capital of Australia?', 'Canberra', ['Sydney', 'Melbourne', 'Perth']], ['How many bits are in a byte?', '8', ['4', '16', '32']], ['Which planet is known as the Red Planet?', 'Mars', ['Venus', 'Jupiter', 'Saturn']], ['What does HTTP stand for?', 'HyperText Transfer Protocol', ['High Transfer Text Protocol', 'Host Terminal Transfer Protocol', 'Hyper Tool Transport Package']], ['Which language runs in web browsers?', 'JavaScript', ['Rust', 'COBOL', 'Fortran']], ['What is the largest ocean?', 'Pacific', ['Atlantic', 'Indian', 'Arctic']], ['Port 22 is used by which protocol?', 'SSH', ['FTP', 'SMTP', 'DNS']], ['Who created Linux?', 'Linus Torvalds', ['Bill Gates', 'Steve Jobs', 'Dennis Ritchie']]];
const WORDS = ['server', 'discord', 'network', 'hosting', 'firewall', 'terminal', 'database', 'javascript', 'developer', 'keyboard', 'minecraft', 'dragon'];
const WL = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];

export default [
  F({ name: '8ball', aliases: ['8b'], description: 'Ask the magic 8-ball', usage: '8ball <question>', run: ({ message, args, prefix, cmd }) => args.length ? message.reply(card({ title: '🎱 8-Ball', body: `**${clip(args.join(' '), 150)}**\n${pick(EIGHT)}` })) : message.reply(usage(cmd, prefix)) }),
  list('joke', 'Random joke', '😂 Joke', ['Why do programmers prefer dark mode? Because light attracts bugs.', 'I would tell you a UDP joke, but you might not get it.', 'There are 10 kinds of people: those who understand binary and those who do not.', 'A SQL query walks into a bar, sees two tables and asks: "Can I join you?"', 'Why did the server go to therapy? Too many unresolved connections.', '!false — it is funny because it is true.']),
  list('dadjoke', 'Random dad joke', '👨 Dad joke', ['I only know 25 letters of the alphabet. I do not know y.', 'I used to hate facial hair, but then it grew on me.', 'Did you hear about the restaurant on the moon? Great food, no atmosphere.', 'I am reading a book on anti-gravity. It is impossible to put down.', 'What do you call fake spaghetti? An impasta.']),
  list('fact', 'Random fact', '🧠 Fact', ['Honey never spoils; edible honey was found in ancient tombs.', 'Octopuses have three hearts.', 'The first computer bug was an actual moth found in a relay in 1947.', 'A day on Venus is longer than its year.', 'Bananas are berries, but strawberries are not.', 'The first domain name ever registered was symbolics.com.']),
  list('quote', 'Inspirational quote', '<:channel:1461684716036947999> Quote', ['"The best way to predict the future is to invent it." — Alan Kay', '"Simplicity is prerequisite for reliability." — Edsger Dijkstra', '"Make it work, make it right, make it fast." — Kent Beck', '"First, solve the problem. Then, write the code." — John Johnson', '"Talk is cheap. Show me the code." — Linus Torvalds']),
  F({ name: 'roast', description: 'Playfully roast someone', usage: 'roast [member]', async run({ message, args }) { const t = (await getMember(message, args[0])) ?? message.member; return message.reply(card({ title: '<:fire:1461684981184069798> Roast', body: `${t.displayName}, ${pick(['you are the reason the "Are you sure?" prompt exists.', 'your code works on the first try about as often as a Windows update.', 'you bring everyone so much joy when you leave the room.', 'if laziness were an Olympic sport, you would send a friend to compete.'])}` })); } }),
  F({ name: 'compliment', description: 'Compliment someone', usage: 'compliment [member]', async run({ message, args }) { const t = (await getMember(message, args[0])) ?? message.member; return message.reply(card({ title: '<:heart:1461684959285874884> Compliment', body: `${t.displayName}, ${pick(['you make this server better.', 'your energy is contagious.', 'you are smarter than you give yourself credit for.', 'you are a great teammate.'])}` })); } }),
  list('pickupline', 'Cheesy pickup line', '😏 Pickup line', ['Are you a firewall? Because you are blocking me out.', 'Are you a 404? Because I cannot find anyone like you.', 'Is your name Wi-Fi? Because I am feeling a connection.']),
  F({ name: 'riddle', description: 'Solve a riddle (30s)', usage: 'riddle', cooldown: 10, async run({ message }) {
    const [q, a] = pick([['What has keys but cannot open locks?', 'keyboard'], ['What gets wetter the more it dries?', 'towel'], ['What has to be broken before you can use it?', 'egg'], ['I speak without a mouth and hear without ears. What am I?', 'echo']]);
    await message.reply(card({ title: '🧩 Riddle', body: `${q}\n-# You have 30 seconds. Just type your answer.` })); const r = await waitMsg(message, (m) => m.content.toLowerCase().includes(a), 30000);
    return message.channel.send(r ? ok('Correct!', `<@${r.author.id}> got it: **${a}**`) : warn('Time is up', `The answer was **${a}**.`));
  } }),
  list('fortune', 'Your fortune', '🔮 Fortune', ['A pleasant surprise is waiting for you.', 'Your hard work will soon pay off.', 'Someone is thinking of you.', 'Be careful what you deploy on a Friday.', 'A new opportunity is coming.']),
  F({ name: 'horoscope', description: 'Daily horoscope', usage: 'horoscope <sign>', run: ({ message, args, prefix, cmd }) => ['aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo', 'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'].includes(args[0]?.toLowerCase()) ? message.reply(card({ title: `♈ ${args[0].toLowerCase()}`, body: pick(['Today favors bold decisions.', 'Take a break; you earned it.', 'Expect good news before evening.', 'A conversation will clear things up.']) })) : message.reply(usage(cmd, prefix)) }),
  F({ name: 'truthordare', aliases: ['tod'], description: 'Truth or dare', usage: 'truthordare', run: ({ message }) => message.reply(card({ title: '<:autoreact:1461688622485995699> Truth or Dare', body: pick(['**Truth:** What is your most embarrassing moment?', '**Truth:** What is the last thing you searched online?', '**Dare:** Change your nickname to "potato" for an hour.', '**Dare:** Send the 5th emoji in your recent list.'])})) }),
  list('wouldyourather', 'Would you rather?', '🤔 Would you rather', ['Be able to fly or be invisible?', 'Have unlimited bandwidth or unlimited storage?', 'Never use a keyboard again or never use a mouse again?', 'Always be 10 minutes late or 20 minutes early?'], ['wyr']),
  list('neverhaveiever', 'Never have I ever', '<:hide:1461684091429589043> Never have I ever', ['...stayed up all night gaming.', '...forgotten to save my work.', '...rage quit a game.', '...pretended to be offline.'], ['nhie']),
  F({ name: 'choose', description: 'Pick between options separated by |', usage: 'choose <a | b | c>', run: ({ message, args, prefix, cmd }) => { const o = args.join(' ').split('|').map((x) => x.trim()).filter(Boolean); return o.length < 2 ? message.reply(usage(cmd, prefix)) : message.reply(card({ title: '<:game:1461684938264018944> I choose', body: `**${clip(pick(o), 200)}**` })); } }),
  F({ name: 'flip', description: 'Flip a coin', usage: 'flip', run: ({ message }) => message.reply(card({ title: '<:premium:1461685250034892912> Coin flip', body: `**${pick(['Heads', 'Tails'])}**` })) }),
  F({ name: 'rolldice', aliases: ['roll'], description: 'Roll a die', usage: 'rolldice [sides]', run: ({ message, args }) => { const s = Math.min(Math.max(parseInt(args[0]) || 6, 2), 1000); return message.reply(card({ title: `<:dice:1461684948879544516> d${s}`, body: `You rolled **${rnd(1, s)}**` })); } }),
  F({ name: 'reverse', description: 'Reverse text', usage: 'reverse <text>', run: ({ message, args, prefix, cmd }) => args.length ? message.reply(card({ title: '<:reset:1461683691813208075> Reversed', body: clip([...args.join(' ')].reverse().join(''), 1500) })) : message.reply(usage(cmd, prefix)) }),
  F({ name: 'mock', description: 'SpOnGeBoB mocking text', usage: 'mock <text>', run: ({ message, args, prefix, cmd }) => args.length ? message.reply(card({ title: '🧽 Mock', body: clip([...args.join(' ').toLowerCase()].map((c, i) => (i % 2 ? c.toUpperCase() : c)).join(''), 1500) })) : message.reply(usage(cmd, prefix)) }),
  F({ name: 'clap', description: 'Add 👏 between words', usage: 'clap <text>', run: ({ message, args, prefix, cmd }) => args.length ? message.reply(card({ title: '👏', body: clip(args.join(' 👏 '), 1500) })) : message.reply(usage(cmd, prefix)) }),
  F({ name: 'emojify', description: 'Turn text into emoji letters', usage: 'emojify <text>', run: ({ message, args, prefix, cmd }) => args.length ? message.reply(card({ title: 'Emojify', body: clip([...args.join(' ').toLowerCase()].map((c) => (/[a-z]/.test(c) ? `:regional_indicator_${c}:` : c === ' ' ? '   ' : c)).join(' '), 1500) })) : message.reply(usage(cmd, prefix)) }),
  F({ name: 'ship', description: 'Compatibility between two members', usage: 'ship <member> [member]', async run({ message, args, prefix, cmd }) {
    const a = await getMember(message, args[0]), b = (await getMember(message, args[1])) ?? message.member; if (!a) return message.reply(usage(cmd, prefix));
    const pct = [...[a.id, b.id].sort().join('')].reduce((x, c) => (x * 31 + c.charCodeAt(0)) % 101, 7);
    return message.reply(card({ title: `<:heart:1461684959285874884> ${a.displayName} × ${b.displayName}`, body: `**${pct}%** — \`${'█'.repeat(Math.round(pct / 10))}${'░'.repeat(10 - Math.round(pct / 10))}\`` }));
  } }),
  F({ name: 'rate', description: 'Rate anything out of 10', usage: 'rate <thing>', run: ({ message, args, prefix, cmd }) => args.length ? message.reply(card({ title: '<:star:1461684992026611917> Rating', body: `I rate **${clip(args.join(' '), 100)}** a **${[...args.join(' ').toLowerCase()].reduce((x, c) => (x * 17 + c.charCodeAt(0)) % 11, 3)}/10**` })) : message.reply(usage(cmd, prefix)) }),
  F({ name: 'rps', description: 'Rock paper scissors', usage: 'rps <rock|paper|scissors>', run: ({ message, args, prefix, cmd }) => {
    const m = { r: 'rock', p: 'paper', s: 'scissors' }[args[0]?.[0]?.toLowerCase()]; if (!m) return message.reply(usage(cmd, prefix)); const b = pick(['rock', 'paper', 'scissors']);
    const win = m === b ? 'It is a tie!' : ({ rock: 'scissors', paper: 'rock', scissors: 'paper' }[m] === b ? 'You win!' : 'I win!'); return message.reply(card({ title: '✂️ RPS', body: `You: **${m}** • Me: **${b}**\n${win}` }));
  } }),
  F({ name: 'guessnumber', aliases: ['gtn'], description: 'Guess a number 1-100 in 6 tries', usage: 'guessnumber', cooldown: 15, async run({ message }) {
    const n = rnd(1, 100); await message.reply(card({ title: '<:total:1461688742401020138> Guess the number', body: 'I picked a number from 1 to 100. You have 6 tries — type your guesses!' }));
    for (let i = 1; i <= 6; i++) { const r = await waitMsg(message, (m) => m.author.id === message.author.id && /^\d+$/.test(m.content), 30000); if (!r) return message.channel.send(warn('Time is up', `It was **${n}**.`)); const g = +r.content;
      if (g === n) return message.channel.send(ok('You got it!', `**${n}** in ${i} ${i === 1 ? 'try' : 'tries'}.`)); await message.channel.send(card({ title: g < n ? '⬆️ Higher' : '⬇️ Lower', body: `${6 - i} tries left.`, foot: false })); }
    return message.channel.send(fail('Out of tries', `It was **${n}**.`));
  } }),
  F({ name: 'mathquiz', description: 'Quick math question (15s)', usage: 'mathquiz', cooldown: 10, async run({ message }) {
    const a = rnd(2, 20), b = rnd(2, 20), op = pick(['+', '-', '*']), ans = op === '+' ? a + b : op === '-' ? a - b : a * b;
    await message.reply(card({ title: '<:add:1461683681088372747> Math quiz', body: `What is **${a} ${op} ${b}**?` })); const r = await waitMsg(message, (m) => m.content.trim() === String(ans), 15000);
    return message.channel.send(r ? ok('Correct!', `<@${r.author.id}> answered **${ans}** first.`) : warn('Time is up', `The answer was **${ans}**.`));
  } }),
  F({ name: 'typerace', description: 'First to type the phrase wins', usage: 'typerace', cooldown: 15, async run({ message }) {
    const p = pick(['the quick brown fox jumps over the lazy dog', 'never gonna let your server down', 'sudo make me a sandwich', 'it works on my machine']), t = Date.now();
    await message.reply(card({ title: '⌨️ Type race', body: `Type this exactly:\n**${p}**` })); const r = await waitMsg(message, (m) => m.content.toLowerCase() === p, 30000);
    return message.channel.send(r ? ok('Winner!', `<@${r.author.id}> finished in **${((Date.now() - t) / 1000).toFixed(2)}s**`) : warn('Nobody finished in time'));
  } }),
  F({ name: 'scramble', description: 'Unscramble the word', usage: 'scramble', cooldown: 10, async run({ message }) {
    const w = pick(WORDS); let s = shuffle(w); while (s === w) s = shuffle(w);
    await message.reply(card({ title: '🔤 Unscramble', body: `**${s}**\n-# 20 seconds` })); const r = await waitMsg(message, (m) => m.content.toLowerCase() === w, 20000);
    return message.channel.send(r ? ok('Correct!', `<@${r.author.id}> solved it: **${w}**`) : warn('Time is up', `The word was **${w}**.`));
  } }),
  F({ name: 'hangman', description: 'Play hangman', usage: 'hangman', cooldown: 20, async run({ message }) {
    const w = pick(WORDS), seen = new Set(); let lives = 6;
    const show = () => [...w].map((c) => (seen.has(c) ? c : '_')).join(' ');
    await message.reply(card({ title: '🪢 Hangman', body: `\`${show()}\`\nLives: ${lives}\n-# Type one letter at a time.` }));
    while (lives > 0 && [...w].some((c) => !seen.has(c))) {
      const r = await waitMsg(message, (m) => m.author.id === message.author.id && /^[a-z]$/i.test(m.content), 40000); if (!r) return message.channel.send(warn('Game over', `Too slow. The word was **${w}**.`));
      const l = r.content.toLowerCase(); if (seen.has(l)) continue; seen.add(l); if (!w.includes(l)) lives--;
      await message.channel.send(card({ title: '🪢 Hangman', body: `\`${show()}\`\nLives: ${'<:heart:1461684959285874884>'.repeat(lives) || '<:skull:1461684970056847524>'}\nTried: ${[...seen].join(' ')}`, foot: false }));
    }
    return message.channel.send(lives > 0 ? ok('You won!', `The word was **${w}**.`) : fail('You lost', `The word was **${w}**.`));
  } }),
  F({ name: 'trivia', description: 'Answer a trivia question', usage: 'trivia', cooldown: 10, async run({ message }) {
    const [q, a, wrong] = pick(TRIVIA), opts = [a, ...wrong].sort(() => Math.random() - 0.5);
    const row = new ActionRowBuilder().addComponents(opts.map((o, i) => new ButtonBuilder().setCustomId(`tr:${i}`).setLabel(clip(o, 80)).setStyle(ButtonStyle.Primary)));
    const m = await message.reply(card({ title: '🧠 Trivia', body: `**${q}**\n-# 20 seconds — first correct answer wins`, rows: [row] }));
    const c = m.createMessageComponentCollector({ time: 20000 }); let done = false;
    c.on('collect', async (i) => { if (done) return; if (opts[+i.customId.split(':')[1]] === a) { done = true; await i.update(card({ title: '🧠 Trivia', body: `<:check:1461683648834306130> <@${i.user.id}> got it: **${a}**`, color: 'success' })); c.stop(); } else await i.reply(eph(fail('Wrong', 'Try again!'))); });
    c.on('end', () => { if (!done) m.edit(card({ title: '🧠 Trivia', body: `<:remind:1461684133737791663> Time is up. The answer was **${a}**.`, color: 'warning' })).catch(() => {}); });
  } }),
  F({ name: 'tictactoe', aliases: ['ttt'], description: 'Play tic-tac-toe', usage: 'tictactoe <member>', cooldown: 15, async run({ message, args, prefix, cmd }) {
    const o = await getMember(message, args[0]); if (!o || o.user.bot || o.id === message.author.id) return message.reply(usage(cmd, prefix));
    const players = [message.author.id, o.id], b = Array(9).fill(null); let turn = 0;
    const grid = (end) => [0, 1, 2].map((r) => new ActionRowBuilder().addComponents([0, 1, 2].map((c) => { const i = r * 3 + c; return new ButtonBuilder().setCustomId(`ttt:${i}`).setLabel(b[i] ?? '\u200b').setStyle(b[i] === 'X' ? ButtonStyle.Primary : b[i] === 'O' ? ButtonStyle.Danger : ButtonStyle.Secondary).setDisabled(!!b[i] || end); })));
    const view = (t, end, color) => card({ title: '⭕ Tic-Tac-Toe', body: t, rows: grid(end), color: color ?? 'info' });
    const m = await message.reply(view(`<@${players[0]}> (X) vs <@${players[1]}> (O)\n<@${players[turn]}>'s turn`));
    const col = m.createMessageComponentCollector({ time: 180000 });
    col.on('collect', async (i) => {
      if (!players.includes(i.user.id)) return i.reply(eph(fail('Not your game')));
      if (i.user.id !== players[turn]) return i.reply(eph(warn('Wait for your turn')));
      b[+i.customId.split(':')[1]] = turn ? 'O' : 'X';
      if (WL.some((l) => l.every((x) => b[x] === (turn ? 'O' : 'X')))) { col.stop('done'); return i.update(view(`<a:trophy:1461683963298058283> <@${players[turn]}> wins!`, true, 'success')); }
      if (b.every(Boolean)) { col.stop('done'); return i.update(view("It's a draw!", true)); }
      turn ^= 1; return i.update(view(`<@${players[0]}> (X) vs <@${players[1]}> (O)\n<@${players[turn]}>'s turn`));
    });
    col.on('end', (_, r) => { if (r !== 'done') m.edit(view('Game timed out.', true, 'warning')).catch(() => {}); });
  } }),
  action('hug', 'hugs', '🤗', '{u} hugs themselves... have a hug from me!'), action('kiss', 'kisses', '😘', '{u} blows a kiss!'), action('pat', 'pats', '👋', '{u} pats themselves. Good job!'), action('slap', 'slaps', '✋', '{u} slaps the air.'),
  action('cuddle', 'cuddles', '🥰', '{u} cuddles a pillow.'), action('poke', 'pokes', '👉', '{u} pokes the void.'), action('bite', 'bites', '😬', '{u} bites the air.'),
  solo('cry', '{u} is crying...', '😭'), solo('dance', '{u} is dancing! 💃', '💃'), solo('laugh', '{u} is laughing out loud!', '😂'),
  F({ name: 'cookie', description: 'Give someone a cookie', usage: 'cookie <member>', async run({ message, args }) { const t = await getMember(message, args[0]); return message.reply(card({ title: '🍪 Cookie', body: t ? `**${message.member.displayName}** gave **${t.displayName}** a cookie!` : `Here is a cookie, **${message.member.displayName}**!` })); } }),
  imageCmd('cat', 'Random cat picture', async () => (await json('https://api.thecatapi.com/v1/images/search'))[0].url, '🐱 Cat'),
  imageCmd('dog', 'Random dog picture', async () => (await json('https://dog.ceo/api/breeds/image/random')).message, '🐶 Dog'),
  imageCmd('fox', 'Random fox picture', async () => (await json('https://randomfox.ca/floof/')).image, '🦊 Fox'),
  imageCmd('meme', 'Random meme', async () => { const j = await json('https://meme-api.com/gimme'); if (j.nsfw) throw new Error('nsfw'); return j.url; }, '😹 Meme'),
];
