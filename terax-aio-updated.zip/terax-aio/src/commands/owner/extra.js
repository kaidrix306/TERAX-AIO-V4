import { config, saveConfig, isAllowed } from '../../core/config.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { confirm } from '../../core/ptero.js';
import { clip, idOf } from '../../core/util.js';

const O = { category: 'owner', ownerOnly: true };
export default [
  { ...O, name: 'broadcast', aliases: ['announce'], description: 'Send an announcement to every whitelisted server', usage: 'broadcast <text>', async run({ client, message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); const text = clip(args.join(' '), 1500);
    if (!(await confirm(message, `Send this to every whitelisted server's system channel?\n\n${text}`))) return; let n = 0;
    for (const g of client.guilds.cache.values()) { if (!isAllowed(g.id)) continue; const c = g.systemChannel ?? g.channels.cache.find((x) => x.isTextBased() && x.permissionsFor(g.members.me)?.has('SendMessages')); if (c) await c.send(card({ title: `<:channel:1461684716036947999> ${config.branding.botName} announcement`, body: text })).then(() => n++).catch(() => {}); }
    return message.channel.send(ok('Broadcast sent', `${n} server(s).`));
  } },
  { ...O, name: 'addowner', description: 'Add a bot owner', usage: 'addowner <userId>', async run({ message, args, prefix, cmd }) {
    const id = idOf(args[0]); if (!/^\d{15,22}$/.test(id)) return message.reply(usage(cmd, prefix)); if (!config.ownerIds.includes(id)) { config.ownerIds.push(id); saveConfig(); } return message.reply(ok('Owner added', `<@${id}> now has full owner access. Only add people you fully trust.`));
  } },
  { ...O, name: 'removeowner', description: 'Remove a bot owner', usage: 'removeowner <userId>', async run({ message, args, prefix, cmd }) {
    const id = idOf(args[0]); if (!id) return message.reply(usage(cmd, prefix)); if (config.ownerIds.length <= 1) return message.reply(fail('Cannot', 'There must be at least one owner.')); config.ownerIds = config.ownerIds.filter((x) => x !== id); saveConfig(); return message.reply(ok('Owner removed'));
  } },
  { ...O, name: 'noprefix', description: 'Let a user run commands without the prefix', usage: 'noprefix <add|remove|list> [userId]', async run({ message, args, prefix, cmd }) {
    config.noPrefixUsers ??= []; const id = idOf(args[1]);
    if (args[0] === 'list') return message.reply(card({ title: 'No-prefix users', body: config.noPrefixUsers.map((x) => `<@${x}>`).join('\n') || 'None' }));
    if (!/^\d{15,22}$/.test(id) || !['add', 'remove'].includes(args[0])) return message.reply(usage(cmd, prefix));
    config.noPrefixUsers = args[0] === 'add' ? [...new Set([...config.noPrefixUsers, id])] : config.noPrefixUsers.filter((x) => x !== id); saveConfig(); return message.reply(ok('No-prefix updated', `<@${id}> ${args[0] === 'add' ? 'can now' : 'can no longer'} run commands without a prefix.`));
  } },
  { ...O, name: 'shards', description: 'Shard info', usage: 'shards', async run({ client, message }) { return message.reply(card({ title: '🧩 Shards', body: `Single process • ${client.guilds.cache.size} server(s) • ping ${client.ws.ping}ms` })); } },
  { ...O, name: 'botlogs', description: 'Set the channel for join/leave logs', usage: 'botlogs <channelId|off>', async run({ message, args, prefix, cmd }) {
    if (!args[0]) return message.reply(usage(cmd, prefix)); config.botLogChannel = args[0] === 'off' ? '' : idOf(args[0]); saveConfig(); return message.reply(ok('Bot logs', config.botLogChannel ? `<#${config.botLogChannel}>` : 'Disabled'));
  } },
  { ...O, name: 'setbanner', description: 'Change the bot profile banner (URL or attachment)', usage: 'setbanner <url>', async run({ client, message, args, prefix, cmd }) {
    const url = args[0] || message.attachments.first()?.url; if (!url) return message.reply(usage(cmd, prefix)); await client.user.setBanner(url); return message.reply(ok('Banner updated'));
  } },
  { ...O, name: 'cache', description: 'Show or clear caches', usage: 'cache [clear]', async run({ client, message, args }) {
    if (args[0] === 'clear') { client.channels.cache.forEach((c) => c.messages?.cache.clear()); client.users.cache.sweep((u) => !client.guilds.cache.some((g) => g.members.cache.has(u.id))); }
    return message.reply(card({ title: '<:folder:1461683703120924826> Cache', fields: [['Users', client.users.cache.size], ['Channels', client.channels.cache.size], ['Guilds', client.guilds.cache.size], ['Cooldowns', client.cooldowns.size]] }));
  } },
];
