import { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits as P } from 'discord.js';
import { db } from '../../core/db.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { acct, add, cooldown, parseAmt, fmt, rnd, pick, invAdd, invQty, coin } from '../../core/eco.js';
import { getMember, fmtDuration, clip, ts } from '../../core/util.js';

const E = (o) => ({ category: 'economy', cooldown: 3, ...o });
const wait = (ms) => `<:timer:1461683899972321300> Try again in **${fmtDuration(ms)}**.`;
// Parse + validate a bet against the wallet; replies on error.
async function bet(message, arg) {
  const a = acct(message.guild.id, message.author.id), n = parseAmt(arg, a.wallet);
  if (!n) { await message.reply(fail('Invalid bet', 'Give a number, `half` or `all`.')); return null; }
  if (n > a.wallet) { await message.reply(fail('Not enough coins', `You only have ${fmt(a.wallet)} in your wallet.`)); return null; }
  if (n > 1e6) { await message.reply(fail('Bet too high', 'Maximum bet is 1,000,000.')); return null; }
  return n;
}
const g = (m) => m.guild.id, u = (m) => m.author.id;
const reward = (name, ms, lo, hi, desc, msgs) => E({ name, description: desc, usage: name, async run({ message }) {
  const w = cooldown(g(message), u(message), name, ms); if (w) return message.reply(warn('Cooldown', wait(w)));
  const n = rnd(lo, hi); add(g(message), u(message), 'wallet', n);
  return message.reply(ok(name[0].toUpperCase() + name.slice(1), `${pick(msgs).replace('{n}', fmt(n))}`));
} });
const activity = (name, ms, desc, table) => E({ name, description: desc, usage: name, async run({ message }) {
  const w = cooldown(g(message), u(message), name, ms); if (w) return message.reply(warn('Cooldown', wait(w)));
  const [label, lo, hi] = pick(table); const n = rnd(lo, hi); if (n > 0) add(g(message), u(message), 'wallet', n);
  return message.reply(n > 0 ? ok(name[0].toUpperCase() + name.slice(1), `You caught/found **${label}** worth ${fmt(n)}.`) : warn(name[0].toUpperCase() + name.slice(1), `You found ${label}. Nothing worth selling.`));
} });
const card21 = () => { const v = rnd(1, 13); return v > 10 ? 10 : v; };
const total = (h) => { let t = h.reduce((a, b) => a + b, 0), aces = h.filter((x) => x === 1).length; while (aces-- > 0 && t + 10 <= 21) t += 10; return t; };
const admin = { perms: [P.ManageGuild] };

export default [
  E({ name: 'balance', aliases: ['bal', 'wallet'], description: 'Check a balance', usage: 'balance [member]', async run({ message, args }) {
    const m = (await getMember(message, args[0])) ?? message.member, a = acct(g(message), m.id);
    return message.reply(card({ title: `${coin} ${m.user.username}`, fields: [['Wallet', fmt(a.wallet)], ['Bank', fmt(a.bank)], ['Total', fmt(a.wallet + a.bank)]], thumb: m.displayAvatarURL() }));
  } }),
  reward('daily', 864e5, 400, 700, 'Claim your daily coins', ['You claimed your daily reward: {n}', 'Daily bonus received: {n}']),
  reward('weekly', 6048e5, 3000, 5000, 'Claim your weekly coins', ['Weekly reward: {n}']),
  reward('monthly', 2592e6, 12000, 20000, 'Claim your monthly coins', ['Monthly reward: {n}']),
  reward('work', 36e5, 80, 260, 'Work for coins (1h)', ['You worked a shift and earned {n}', 'You fixed some servers and got {n}', 'You delivered packages for {n}']),
  E({ name: 'beg', description: 'Beg for coins (1 min)', usage: 'beg', async run({ message }) {
    const w = cooldown(g(message), u(message), 'beg', 6e4); if (w) return message.reply(warn('Cooldown', wait(w)));
    if (Math.random() < 0.3) return message.reply(warn('Beg', pick(['Nobody gave you anything.', 'A stranger ignored you.'])));
    const n = rnd(5, 60); add(g(message), u(message), 'wallet', n); return message.reply(ok('Beg', `Someone gave you ${fmt(n)}.`));
  } }),
  E({ name: 'crime', description: 'Risky crime (2h)', usage: 'crime', async run({ message }) {
    const w = cooldown(g(message), u(message), 'crime', 72e5); if (w) return message.reply(warn('Cooldown', wait(w)));
    if (Math.random() < 0.5) { const n = rnd(250, 700); add(g(message), u(message), 'wallet', n); return message.reply(ok('Crime paid off', `You pulled it off and got ${fmt(n)}.`)); }
    const f = Math.min(rnd(100, 350), acct(g(message), u(message)).wallet); add(g(message), u(message), 'wallet', -f); return message.reply(fail('Busted', `You were caught and fined ${fmt(f)}.`));
  } }),
  activity('fish', 18e5, 'Go fishing (30m)', [['an old boot', 0, 0], ['a small fish', 20, 60], ['a trout', 60, 140], ['a salmon', 120, 260], ['a golden fish', 400, 800]]),
  activity('hunt', 18e5, 'Go hunting (30m)', [['nothing', 0, 0], ['a rabbit', 25, 70], ['a deer', 100, 250], ['a boar', 150, 320], ['a rare stag', 450, 900]]),
  activity('mine', 27e5, 'Go mining (45m)', [['rocks', 0, 0], ['coal', 30, 80], ['iron', 90, 200], ['gold', 200, 450], ['a diamond', 500, 1000]]),
  E({ name: 'rob', description: 'Try to rob someone (1h)', usage: 'rob <member>', async run({ message, args, prefix, cmd }) {
    const v = await getMember(message, args[0]); if (!v || v.user.bot || v.id === u(message)) return message.reply(usage(cmd, prefix));
    const va = acct(g(message), v.id); if (va.wallet < 200) return message.reply(fail('Not worth it', 'That member has less than 200 coins in their wallet.'));
    const w = cooldown(g(message), u(message), 'rob', 36e5); if (w) return message.reply(warn('Cooldown', wait(w)));
    if (invQty(g(message), v.id, 'padlock') > 0) { invAdd(g(message), v.id, 'padlock', -1); return message.reply(fail('Blocked', `**${v.user.username}** had a padlock. It broke, and you got nothing.`)); }
    if (Math.random() < 0.4) { const n = Math.floor(va.wallet * (rnd(10, 30) / 100)); add(g(message), v.id, 'wallet', -n); add(g(message), u(message), 'wallet', n); return message.reply(ok('Robbery success', `You stole ${fmt(n)} from **${v.user.username}**.`)); }
    const f = Math.min(rnd(100, 300), acct(g(message), u(message)).wallet); add(g(message), u(message), 'wallet', -f); return message.reply(fail('Caught', `You were caught and paid ${fmt(f)} in fines.`));
  } }),
  E({ name: 'deposit', aliases: ['dep'], description: 'Move coins to your bank', usage: 'deposit <amount|all>', async run({ message, args }) {
    const a = acct(g(message), u(message)), n = parseAmt(args[0], a.wallet); if (!n || n > a.wallet) return message.reply(fail('Invalid amount', `Wallet: ${fmt(a.wallet)}`));
    add(g(message), u(message), 'wallet', -n); add(g(message), u(message), 'bank', n); return message.reply(ok('Deposited', fmt(n)));
  } }),
  E({ name: 'withdraw', aliases: ['with'], description: 'Move coins to your wallet', usage: 'withdraw <amount|all>', async run({ message, args }) {
    const a = acct(g(message), u(message)), n = parseAmt(args[0], a.bank); if (!n || n > a.bank) return message.reply(fail('Invalid amount', `Bank: ${fmt(a.bank)}`));
    add(g(message), u(message), 'bank', -n); add(g(message), u(message), 'wallet', n); return message.reply(ok('Withdrew', fmt(n)));
  } }),
  E({ name: 'pay', aliases: ['give'], description: 'Send coins to someone', usage: 'pay <member> <amount>', async run({ message, args, prefix, cmd }) {
    const t = await getMember(message, args[0]); if (!t || t.user.bot || t.id === u(message)) return message.reply(usage(cmd, prefix));
    const a = acct(g(message), u(message)), n = parseAmt(args[1], a.wallet); if (!n || n > a.wallet) return message.reply(fail('Invalid amount', `Wallet: ${fmt(a.wallet)}`));
    add(g(message), u(message), 'wallet', -n); add(g(message), t.id, 'wallet', n); return message.reply(ok('Payment sent', `${fmt(n)} <:right:1461683867835564201> **${t.user.username}**`));
  } }),
  E({ name: 'shop', description: 'View the item shop', usage: 'shop', async run({ message }) {
    const r = db.prepare('SELECT * FROM shop WHERE guild=? ORDER BY price').all(g(message));
    return message.reply(card({ title: '🛒 Shop', body: r.map((x) => `**${x.item}** — ${fmt(x.price)}${x.descr ? `\n-# ${clip(x.descr, 80)}` : ''}`).join('\n') || 'The shop is empty. Admins can use `additem`.' }));
  } }),
  E({ name: 'buy', description: 'Buy an item', usage: 'buy <item> [qty]', async run({ message, args, prefix, cmd }) {
    const item = args[0]?.toLowerCase(), q = parseInt(args[1]) || 1, s = item && db.prepare('SELECT * FROM shop WHERE guild=? AND item=?').get(g(message), item);
    if (!item) return message.reply(usage(cmd, prefix)); if (!s) return message.reply(fail('No such item')); if (q < 1 || q > 100) return message.reply(fail('Quantity must be 1-100'));
    const cost = s.price * q, a = acct(g(message), u(message)); if (a.wallet < cost) return message.reply(fail('Not enough coins', `You need ${fmt(cost)}.`));
    add(g(message), u(message), 'wallet', -cost); invAdd(g(message), u(message), item, q); return message.reply(ok('Purchased', `${q}× **${item}** for ${fmt(cost)}`));
  } }),
  E({ name: 'sell', description: 'Sell an item for 50% of its price', usage: 'sell <item> [qty]', async run({ message, args, prefix, cmd }) {
    const item = args[0]?.toLowerCase(), q = parseInt(args[1]) || 1, s = item && db.prepare('SELECT * FROM shop WHERE guild=? AND item=?').get(g(message), item);
    if (!item) return message.reply(usage(cmd, prefix)); if (!s || invQty(g(message), u(message), item) < q || q < 1) return message.reply(fail('Cannot sell', 'You do not have enough of that item.'));
    const n = Math.floor(s.price * q * 0.5); invAdd(g(message), u(message), item, -q); add(g(message), u(message), 'wallet', n); return message.reply(ok('Sold', `${q}× **${item}** for ${fmt(n)}`));
  } }),
  E({ name: 'inventory', aliases: ['inv'], description: 'View an inventory', usage: 'inventory [member]', async run({ message, args }) {
    const m = (await getMember(message, args[0])) ?? message.member, r = db.prepare('SELECT item, qty FROM inventory WHERE guild=? AND user=?').all(g(message), m.id);
    return message.reply(card({ title: `🎒 ${m.user.username}'s inventory`, body: r.map((x) => `**${x.item}** × ${x.qty}`).join('\n') || 'Empty.' }));
  } }),
  E({ name: 'use', description: 'Use an item', usage: 'use <item>', async run({ message, args, prefix, cmd }) {
    const item = args[0]?.toLowerCase(); if (!item) return message.reply(usage(cmd, prefix));
    if (invQty(g(message), u(message), item) < 1) return message.reply(fail('You do not own that item'));
    if (item === 'padlock') return message.reply(warn('Padlock', 'It protects you automatically against the next robbery. No need to use it.'));
    invAdd(g(message), u(message), item, -1); return message.reply(ok('Item used', `You used **${item}**.`));
  } }),
  E({ name: 'richest', aliases: ['lb', 'baltop'], description: 'Richest members', usage: 'richest', async run({ message }) {
    const r = db.prepare('SELECT user, wallet+bank t FROM eco WHERE guild=? ORDER BY t DESC LIMIT 10').all(g(message));
    return message.reply(card({ title: '<a:trophy:1461683963298058283> Richest', body: r.map((x, i) => `**${i + 1}.** <@${x.user}> — ${fmt(x.t)}`).join('\n') || 'Nobody yet.' }));
  } }),
  E({ name: 'slots', description: 'Spin the slot machine', usage: 'slots <bet>', async run({ message, args }) {
    const b = await bet(message, args[0]); if (!b) return; const s = ['🍒', '🍋', '🍇', '🔔', '<:premium:1461685250034892912>', '7️⃣'], r = [pick(s), pick(s), pick(s)];
    const mult = r[0] === r[1] && r[1] === r[2] ? (r[0] === '7️⃣' ? 10 : r[0] === '<:premium:1461685250034892912>' ? 6 : 4) : (r[0] === r[1] || r[1] === r[2] || r[0] === r[2]) ? 1.5 : 0;
    const win = Math.floor(b * mult) - b; add(g(message), u(message), 'wallet', win);
    return message.reply(card({ title: `🎰 ${r.join(' | ')}`, color: win > 0 ? 'success' : 'error', body: win > 0 ? `You won ${fmt(win + b)} (net ${fmt(win)})` : `You lost ${fmt(b)}` }));
  } }),
  E({ name: 'coinflip', aliases: ['cf'], description: 'Flip a coin', usage: 'coinflip <bet> <heads|tails>', async run({ message, args, prefix, cmd }) {
    const side = args[1]?.toLowerCase(); if (!['heads', 'tails', 'h', 't'].includes(side)) return message.reply(usage(cmd, prefix));
    const b = await bet(message, args[0]); if (!b) return; const res = Math.random() < 0.5 ? 'heads' : 'tails', won = res[0] === side[0];
    add(g(message), u(message), 'wallet', won ? b : -b); return message.reply(card({ title: `<:premium:1461685250034892912> ${res}`, color: won ? 'success' : 'error', body: won ? `You won ${fmt(b)}!` : `You lost ${fmt(b)}.` }));
  } }),
  E({ name: 'bet', description: '50/50 double or nothing', usage: 'bet <amount>', async run({ message, args }) {
    const b = await bet(message, args[0]); if (!b) return; const won = Math.random() < 0.48; add(g(message), u(message), 'wallet', won ? b : -b);
    return message.reply(card({ title: won ? '<:check:1461683648834306130> You won' : '<:cross:1461683670212542484> You lost', color: won ? 'success' : 'error', body: `${won ? '+' : '-'}${fmt(b)}` }));
  } }),
  E({ name: 'dice', description: 'Roll against the bot', usage: 'dice <bet>', async run({ message, args }) {
    const b = await bet(message, args[0]); if (!b) return; const y = rnd(1, 6), c = rnd(1, 6), net = y > c ? b : y < c ? -b : 0; add(g(message), u(message), 'wallet', net);
    return message.reply(card({ title: `<:dice:1461684948879544516> You ${y} — Bot ${c}`, color: net > 0 ? 'success' : net < 0 ? 'error' : 'info', body: net > 0 ? `You won ${fmt(b)}!` : net < 0 ? `You lost ${fmt(b)}.` : 'Tie. Your bet is returned.' }));
  } }),
  E({ name: 'roulette', description: 'Bet on red, black, green or a number 0-36', usage: 'roulette <bet> <red|black|green|0-36>', async run({ message, args, prefix, cmd }) {
    const c = args[1]?.toLowerCase(); const num = /^\d+$/.test(c ?? '') && +c <= 36 ? +c : null; if (!['red', 'black', 'green'].includes(c) && num === null) return message.reply(usage(cmd, prefix));
    const b = await bet(message, args[0]); if (!b) return; const n = rnd(0, 36), reds = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36], col = n === 0 ? 'green' : reds.includes(n) ? 'red' : 'black';
    const mult = num !== null ? (n === num ? 35 : 0) : c === col ? (col === 'green' ? 14 : 2) : 0, net = b * mult - b; add(g(message), u(message), 'wallet', net);
    return message.reply(card({ title: `🎡 ${n} ${col}`, color: net > 0 ? 'success' : 'error', body: net > 0 ? `You won ${fmt(b * mult)}!` : `You lost ${fmt(b)}.` }));
  } }),
  E({ name: 'crash', description: 'Pick a cash-out multiplier; win if the rocket gets past it', usage: 'crash <bet> <multiplier 1.1-10>', async run({ message, args, prefix, cmd }) {
    const t = parseFloat(args[1]); if (!(t >= 1.1 && t <= 10)) return message.reply(usage(cmd, prefix));
    const b = await bet(message, args[0]); if (!b) return; const r = Math.max(1, 0.97 / (1 - Math.random())), won = r >= t, net = won ? Math.floor(b * t) - b : -b; add(g(message), u(message), 'wallet', net);
    return message.reply(card({ title: `🚀 Crashed at ${Math.min(r, 100).toFixed(2)}×`, color: won ? 'success' : 'error', body: won ? `Cashed out at ${t}× — won ${fmt(net)}` : `It crashed before ${t}×. Lost ${fmt(b)}.` }));
  } }),
  E({ name: 'scratch', description: 'Buy a scratch ticket for 100 coins', usage: 'scratch', async run({ message }) {
    const a = acct(g(message), u(message)); if (a.wallet < 100) return message.reply(fail('Not enough coins', 'A ticket costs 100.'));
    const prize = pick([0, 0, 0, 50, 100, 200, 500, 2000]); add(g(message), u(message), 'wallet', prize - 100);
    return message.reply(card({ title: '🎟️ Scratch ticket', color: prize > 100 ? 'success' : 'error', body: prize ? `You won ${fmt(prize)}!` : 'Nothing this time.' }));
  } }),
  E({ name: 'blackjack', aliases: ['bj'], description: 'Play blackjack', usage: 'blackjack <bet>', cooldown: 8, async run({ message, args }) {
    const b = await bet(message, args[0]); if (!b) return; add(g(message), u(message), 'wallet', -b);
    const you = [card21(), card21()], dealer = [card21(), card21()];
    const row = (off) => new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('bj:hit').setLabel('Hit').setStyle(ButtonStyle.Primary).setDisabled(off), new ButtonBuilder().setCustomId('bj:stand').setLabel('Stand').setStyle(ButtonStyle.Secondary).setDisabled(off));
    const view = (hide, note, off, color = 'info') => card({ title: '🃏 Blackjack', color, body: `**You** (${total(you)}): ${you.join(' ')}\n**Dealer** (${hide ? '?' : total(dealer)}): ${hide ? dealer[0] + ' ?' : dealer.join(' ')}${note ? `\n\n${note}` : ''}`, rows: [row(off)] });
    const m = await message.reply(view(true, '', false));
    const finish = async (i, result) => {
      const pay = { win: b * 2, push: b, blackjack: Math.floor(b * 2.5), lose: 0 }[result]; add(g(message), u(message), 'wallet', pay);
      const txt = { win: `You won ${fmt(b)}!`, push: 'Push. Bet returned.', blackjack: `Blackjack! You won ${fmt(pay - b)}!`, lose: `You lost ${fmt(b)}.` }[result];
      const p = view(false, txt, true, result === 'lose' ? 'error' : result === 'push' ? 'info' : 'success'); return i ? i.update(p) : m.edit(p);
    };
    if (total(you) === 21) return finish(null, total(dealer) === 21 ? 'push' : 'blackjack');
    let last = null;
    for (;;) {
      let i; try { i = await m.awaitMessageComponent({ filter: (x) => x.user.id === message.author.id && x.customId.startsWith('bj:'), time: 45000 }); } catch { return finish(null, 'lose'); }
      last = i;
      if (i.customId === 'bj:hit') { you.push(card21()); if (total(you) > 21) return finish(i, 'lose'); if (total(you) === 21) break; await i.update(view(true, '', false)); continue; }
      break;
    }
    while (total(dealer) < 17) dealer.push(card21());
    const yt = total(you), dt = total(dealer); return finish(last, dt > 21 || yt > dt ? 'win' : yt === dt ? 'push' : 'lose');
  } }),
  E({ name: 'heist', description: 'Risky solo heist (3h)', usage: 'heist', async run({ message }) {
    if (acct(g(message), u(message)).wallet < 300) return message.reply(fail('Need 300 coins', 'You need at least 300 coins to fund a heist.'));
    const w = cooldown(g(message), u(message), 'heist', 108e5); if (w) return message.reply(warn('Cooldown', wait(w)));
    if (Math.random() < 0.35) { const n = rnd(800, 3000); add(g(message), u(message), 'wallet', n); return message.reply(ok('Heist successful', `You got away with ${fmt(n)}!`)); }
    add(g(message), u(message), 'wallet', -300); return message.reply(fail('Heist failed', `You were caught and lost ${fmt(300)}.`));
  } }),
  E({ name: 'bank', description: 'Bank information', usage: 'bank', async run({ message }) {
    const a = acct(g(message), u(message)), l = db.prepare('SELECT amount FROM loans WHERE guild=? AND user=?').get(g(message), u(message));
    return message.reply(card({ title: '🏦 Bank', fields: [['Wallet', fmt(a.wallet)], ['Bank', fmt(a.bank)], ['Loan owed', fmt(l?.amount ?? 0)]], body: 'Banked coins cannot be robbed. Use `deposit`, `withdraw`, `loan` and `repay`.' }));
  } }),
  E({ name: 'loan', description: 'Borrow up to 5,000 (10% interest)', usage: 'loan <amount>', async run({ message, args }) {
    const cur = db.prepare('SELECT amount FROM loans WHERE guild=? AND user=?').get(g(message), u(message))?.amount ?? 0, n = parseAmt(args[0], 5000);
    if (!n || n > 5000 || cur > 0) return message.reply(fail('Cannot borrow', cur > 0 ? `Repay your ${fmt(cur)} loan first.` : 'Pick 1 to 5,000.'));
    db.prepare('INSERT OR REPLACE INTO loans VALUES (?,?,?)').run(g(message), u(message), Math.ceil(n * 1.1)); add(g(message), u(message), 'wallet', n);
    return message.reply(ok('Loan granted', `You received ${fmt(n)} and owe ${fmt(Math.ceil(n * 1.1))}.`));
  } }),
  E({ name: 'repay', description: 'Repay your loan', usage: 'repay <amount|all>', async run({ message, args }) {
    const l = db.prepare('SELECT amount FROM loans WHERE guild=? AND user=?').get(g(message), u(message)); if (!l) return message.reply(fail('No loan'));
    const w = acct(g(message), u(message)).wallet, n = Math.min(parseAmt(args[0], Math.min(w, l.amount)) ?? 0, w, l.amount); if (!n) return message.reply(fail('Invalid amount', `Owed ${fmt(l.amount)}, wallet ${fmt(w)}.`));
    add(g(message), u(message), 'wallet', -n); l.amount - n <= 0 ? db.prepare('DELETE FROM loans WHERE guild=? AND user=?').run(g(message), u(message)) : db.prepare('UPDATE loans SET amount=? WHERE guild=? AND user=?').run(l.amount - n, g(message), u(message));
    return message.reply(ok('Repaid', `${fmt(n)} • remaining ${fmt(Math.max(0, l.amount - n))}`));
  } }),
  E({ name: 'gift', description: 'Gift an item to someone', usage: 'gift <member> <item> [qty]', async run({ message, args, prefix, cmd }) {
    const t = await getMember(message, args[0]), item = args[1]?.toLowerCase(), q = parseInt(args[2]) || 1; if (!t || t.user.bot || t.id === u(message) || !item) return message.reply(usage(cmd, prefix));
    if (q < 1 || invQty(g(message), u(message), item) < q) return message.reply(fail('You do not have enough of that item'));
    invAdd(g(message), u(message), item, -q); invAdd(g(message), t.id, item, q); return message.reply(ok('Gift sent', `${q}× **${item}** <:right:1461683867835564201> ${t.user.username}`));
  } }),
  E({ ...admin, name: 'additem', description: 'Add or update a shop item', usage: 'additem <name> <price> [description]', async run({ message, args, prefix, cmd }) {
    const price = parseInt(args[1]); if (!args[0] || !(price >= 1)) return message.reply(usage(cmd, prefix));
    db.prepare('INSERT OR REPLACE INTO shop VALUES (?,?,?,?)').run(g(message), args[0].toLowerCase(), price, args.slice(2).join(' ') || null); return message.reply(ok('Shop updated', `**${args[0].toLowerCase()}** — ${fmt(price)}`));
  } }),
  E({ ...admin, name: 'removeitem', description: 'Remove a shop item', usage: 'removeitem <name>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM shop WHERE guild=? AND item=?').run(g(message), (args[0] ?? '').toLowerCase()); return message.reply(r.changes ? ok('Item removed') : fail('No such item'));
  } }),
  ...['addmoney', 'removemoney'].map((name) => E({ ...admin, name, description: `${name === 'addmoney' ? 'Give' : 'Take'} coins (admin)`, usage: `${name} <member> <amount>`, async run({ message, args, prefix, cmd }) {
    const t = await getMember(message, args[0]), n = parseInt(args[1]); if (!t || !(n >= 1)) return message.reply(usage(cmd, prefix));
    add(g(message), t.id, 'wallet', name === 'addmoney' ? n : -n); return message.reply(ok(name, `${fmt(n)} • ${t.user.username}`));
  } })),
  E({ ...admin, name: 'resetbal', description: 'Reset a member\'s balance (admin)', usage: 'resetbal <member>', async run({ message, args, prefix, cmd }) {
    const t = await getMember(message, args[0]); if (!t) return message.reply(usage(cmd, prefix));
    db.prepare('UPDATE eco SET wallet=0, bank=0 WHERE guild=? AND user=?').run(g(message), t.id); return message.reply(ok('Balance reset', t.user.username));
  } }),
  E({ name: 'cooldowns', aliases: ['cds'], description: 'Your active cooldowns', usage: 'cooldowns', async run({ message }) {
    const r = db.prepare('SELECT k, until FROM eco_cd WHERE guild=? AND user=? AND until>?').all(g(message), u(message), Date.now());
    return message.reply(card({ title: '<:timer:1461683899972321300> Cooldowns', body: r.map((x) => `**${x.k}** — ready ${ts(x.until)}`).join('\n') || 'Everything is ready!' }));
  } }),
  E({ name: 'networth', aliases: ['nw'], description: 'Wallet + bank + items', usage: 'networth [member]', async run({ message, args }) {
    const m = (await getMember(message, args[0])) ?? message.member, a = acct(g(message), m.id);
    const items = db.prepare('SELECT SUM(i.qty * s.price) v FROM inventory i JOIN shop s ON s.guild=i.guild AND s.item=i.item WHERE i.guild=? AND i.user=?').get(g(message), m.id)?.v ?? 0;
    return message.reply(card({ title: `<:premium:1461685250034892912> ${m.user.username}`, fields: [['Wallet + bank', fmt(a.wallet + a.bank)], ['Items', fmt(items)], ['Net worth', fmt(a.wallet + a.bank + items)]] }));
  } }),
];
