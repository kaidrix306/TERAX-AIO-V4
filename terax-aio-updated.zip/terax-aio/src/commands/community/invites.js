import { PermissionFlagsBits as P } from 'discord.js';
import { db } from '../../core/db.js';
import { card, ok } from '../../core/ui.js';
import { confirm } from '../../core/ptero.js';
import { getMember } from '../../core/util.js';

const C = { category: 'community', cooldown: 4 };
export default [
  { ...C, name: 'invites', aliases: ['invitecount'], description: 'How many people someone invited', usage: 'invites [member]', async run({ message, args }) {
    const m = (await getMember(message, args[0])) ?? message.member, rows = db.prepare('SELECT user FROM invite_log WHERE guild=? AND inviter=?').all(message.guild.id, m.id), still = rows.filter((r) => message.guild.members.cache.has(r.user)).length;
    return message.reply(card({ title: `<:ticketSupport:1461684906177597557> ${m.displayName}`, fields: [['Total joins', rows.length], ['Still here', still], ['Left', rows.length - still]], body: 'Tracks joins that happened while I was online and could read invites (needs Manage Server).' }));
  } },
  { ...C, name: 'invleaderboard', aliases: ['invlb'], description: 'Top inviters', usage: 'invleaderboard', async run({ message }) {
    const r = db.prepare('SELECT inviter, COUNT(*) n FROM invite_log WHERE guild=? AND inviter IS NOT NULL GROUP BY inviter ORDER BY n DESC LIMIT 10').all(message.guild.id);
    return message.reply(card({ title: '<a:trophy:1461683963298058283> Top inviters', body: r.map((x, i) => `**${i + 1}.** <@${x.inviter}> — ${x.n}`).join('\n') || 'No invite data yet.' }));
  } },
  { ...C, name: 'resetinvites', description: 'Clear all invite data', usage: 'resetinvites', perms: [P.ManageGuild], async run({ message }) {
    if (!(await confirm(message, 'Delete all invite tracking data for this server?'))) return; db.prepare('DELETE FROM invite_log WHERE guild=?').run(message.guild.id); return message.channel.send(ok('Invite data cleared'));
  } },
];
