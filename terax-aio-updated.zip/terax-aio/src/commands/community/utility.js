import crypto from 'node:crypto';
import { PermissionFlagsBits as P, PermissionsBitField } from 'discord.js';
import { db, kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { dmWithNotice } from '../../core/dm.js';
import { parseDuration, fmtDuration, getMember, getChannel, clip, ts } from '../../core/util.js';

const U = (o) => ({ category: 'utility', cooldown: 4, ...o });
const json = async (url) => { const r = await fetch(url, { signal: AbortSignal.timeout(8000) }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); };
const emojiUrl = (s) => { const m = /<(a?):(\w+):(\d+)>/.exec(s ?? ''); return m ? { url: `https://cdn.discordapp.com/emojis/${m[3]}.${m[1] ? 'gif' : 'png'}?size=256`, name: m[2], id: m[3], animated: !!m[1] } : null; };
const need = (ctx, ...a) => !a.every(Boolean) && ctx.message.reply(usage(ctx.cmd, ctx.prefix));

export default [
  U({ name: 'remind', aliases: ['remindme'], description: 'Set a reminder', usage: 'remind <10m|2h|1d> <text>', async run(ctx) {
    const { message, args } = ctx, ms = parseDuration(args[0]), text = clip(args.slice(1).join(' '), 300); if (await need(ctx, ms, text)) return;
    if (ms < 10000 || ms > 2592e6) return message.reply(fail('Invalid time', 'Between 10 seconds and 30 days.'));
    if (db.prepare('SELECT COUNT(*) c FROM reminders WHERE user=?').get(message.author.id).c >= 20) return message.reply(fail('Limit reached', 'Max 20 reminders.'));
    const id = db.prepare('INSERT INTO reminders(guild,channel,user,at,text) VALUES (?,?,?,?,?)').run(message.guild.id, message.channel.id, message.author.id, Date.now() + ms, text).lastInsertRowid;
    return message.reply(ok('Reminder set', `\`${id}\` in ${fmtDuration(ms)}: ${text}\n-# I will remind you in this channel.`));
  } }),
  U({ name: 'reminders', description: 'Your reminders', usage: 'reminders', run: ({ message }) => message.reply(card({ title: '<:remind:1461684133737791663> Reminders', body: db.prepare('SELECT * FROM reminders WHERE user=? ORDER BY at').all(message.author.id).map((r) => `\`${r.id}\` ${ts(r.at)} — ${clip(r.text, 60)}`).join('\n') || 'None.' })) }),
  U({ name: 'delremind', description: 'Delete a reminder', usage: 'delremind <id>', run: ({ message, args }) => message.reply(db.prepare('DELETE FROM reminders WHERE id=? AND user=?').run(parseInt(args[0]), message.author.id).changes ? ok('Reminder deleted') : fail('Not found')) }),
  U({ name: 'suggestchannel', description: 'Set the suggestions channel', usage: 'suggestchannel <#channel|off>', perms: [P.ManageGuild], async run({ message, args, prefix, cmd }) {
    const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, 'suggest_channel', c?.id ?? null); return message.reply(ok('Suggestion channel', c ? `<#${c.id}>` : 'Disabled'));
  } }),
  U({ name: 'suggest', description: 'Post a suggestion', usage: 'suggest <text>', cooldown: 30, async run(ctx) {
    const { message, args } = ctx, t = clip(args.join(' '), 1500), ch = kvGet(message.guild.id, 'suggest_channel'); if (await need(ctx, t)) return; if (!ch) return message.reply(fail('Not set up', 'An admin must run `suggestchannel`.'));
    const c = await message.client.channels.fetch(ch).catch(() => null); const m = await c?.send(card({ title: '💡 Suggestion', body: t, fields: [['By', `<@${message.author.id}>`]] })); if (!m) return message.reply(fail('Could not post'));
    kvSet(message.guild.id, `sug:${m.id}`, t); await m.react('👍'); await m.react('👎'); return message.reply(ok('Suggestion sent', `<#${ch}> • ID \`${m.id}\``));
  } }),
  U({ name: 'calc', aliases: ['math'], description: 'Calculator', usage: 'calc <expression>', async run(ctx) {
    const e = ctx.args.join(' ').replace(/\^/g, '**'); if (await need(ctx, e)) return; if (!/^[0-9+\-*/().%\s*]+$/.test(e) || e.length > 80) return ctx.message.reply(fail('Invalid expression', 'Use numbers and + - * / % ^ ( ) only.'));
    try { const r = Function(`"use strict"; return (${e})`)(); return ctx.message.reply(card({ title: '🧮 Calculator', body: `\`${clip(e, 80)}\` = **${Number.isFinite(r) ? r : 'undefined'}**` })); } catch { return ctx.message.reply(fail('Invalid expression')); }
  } }),
  U({ name: 'qr', description: 'Generate a QR code', usage: 'qr <text>', async run(ctx) { const t = clip(ctx.args.join(' '), 500); if (await need(ctx, t)) return; return ctx.message.reply(card({ title: '🔳 QR code', image: `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(t)}` })); } }),
  U({ name: 'weather', description: 'Current weather', usage: 'weather <city>', async run(ctx) {
    const q = ctx.args.join(' '); if (await need(ctx, q)) return;
    try { const j = await json(`https://wttr.in/${encodeURIComponent(q)}?format=j1`), c = j.current_condition[0], a = j.nearest_area[0];
      return ctx.message.reply(card({ title: `🌤️ ${a.areaName[0].value}, ${a.country[0].value}`, body: c.weatherDesc[0].value, fields: [['Temp', `${c.temp_C}°C / ${c.temp_F}°F`], ['Feels like', `${c.FeelsLikeC}°C`], ['Humidity', `${c.humidity}%`], ['Wind', `${c.windspeedKmph} km/h`]] }));
    } catch { return ctx.message.reply(fail('Not found', 'Could not get weather for that place.')); }
  } }),
  U({ name: 'time', description: 'Time in a timezone', usage: 'time [Area/City e.g. Asia/Kolkata]', run: ({ message, args }) => { try { const tz = args[0] ?? 'UTC'; return message.reply(card({ title: `<:timer:1461683899972321300> ${tz}`, body: `**${new Intl.DateTimeFormat('en-GB', { dateStyle: 'full', timeStyle: 'medium', timeZone: tz }).format(new Date())}**` })); } catch { return message.reply(fail('Unknown timezone', 'Use an IANA name like `Europe/London`.')); } } }),
  U({ name: 'color', aliases: ['colour'], description: 'Preview a hex color', usage: 'color <#hex>', run: (ctx) => { const h = ctx.args[0]?.replace('#', ''); return /^[0-9a-f]{6}$/i.test(h ?? '') ? ctx.message.reply(card({ title: `<:pfp:1461685109538160650> #${h.toUpperCase()}`, color: `#${h}`, image: `https://singlecolorimage.com/get/${h}/200x80`, body: `RGB: ${[0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)).join(', ')}` })) : ctx.message.reply(usage(ctx.cmd, ctx.prefix)); } }),
  U({ name: 'enlarge', description: 'Enlarge a custom emoji', usage: 'enlarge <emoji>', run: (ctx) => { const e = emojiUrl(ctx.args[0]); return e ? ctx.message.reply(card({ title: `:${e.name}:`, image: e.url })) : ctx.message.reply(fail('Custom emoji only', 'Use a custom server emoji.')); } }),
  U({ name: 'stealemoji', description: 'Add a custom emoji to this server', usage: 'stealemoji <emoji> [name]', perms: [P.ManageGuildExpressions], botPerms: [P.ManageGuildExpressions], async run(ctx) {
    const e = emojiUrl(ctx.args[0]); if (!e) return ctx.message.reply(usage(ctx.cmd, ctx.prefix));
    try { const n = await ctx.message.guild.emojis.create({ attachment: e.url, name: (ctx.args[1] ?? e.name).replace(/\W/g, '_').slice(0, 32) }); return ctx.message.reply(ok('Emoji added', `${n} :${n.name}:`)); } catch (x) { return ctx.message.reply(fail('Could not add emoji', clip(x.message, 150))); }
  } }),
  U({ name: 'firstmessage', aliases: ['firstmsg'], description: 'Jump to the first message in this channel', usage: 'firstmessage', async run({ message }) { const m = (await message.channel.messages.fetch({ after: '0', limit: 1 }).catch(() => null))?.first(); return message.reply(m ? card({ title: '📍 First message', body: `[Jump to it](${m.url})` }) : fail('Could not find it')); } }),
  U({ name: 'define', description: 'Dictionary definition', usage: 'define <word>', async run(ctx) {
    if (await need(ctx, ctx.args[0])) return; try { const j = await json(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(ctx.args[0])}`), m = j[0].meanings[0];
      return ctx.message.reply(card({ title: `<:list:1461683931546910917> ${j[0].word}`, body: `*${m.partOfSpeech}* — ${clip(m.definitions[0].definition, 400)}` })); } catch { return ctx.message.reply(fail('No definition found')); }
  } }),
  U({ name: 'wiki', description: 'Wikipedia summary', usage: 'wiki <topic>', async run(ctx) {
    const q = ctx.args.join(' '); if (await need(ctx, q)) return; try { const s = await json(`https://en.wikipedia.org/w/rest.php/v1/search/title?q=${encodeURIComponent(q)}&limit=1`), p = s.pages[0]; if (!p) throw 0; const j = await json(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(p.key)}`);
      return ctx.message.reply(card({ title: `<:list:1461683931546910917> ${j.title}`, body: `${clip(j.extract, 500)}\n[Read more](${j.content_urls.desktop.page})`, thumb: j.thumbnail?.source })); } catch { return ctx.message.reply(fail('No article found')); }
  } }),
  U({ name: 'base64', aliases: ['b64'], description: 'Encode or decode base64', usage: 'base64 <encode|decode> <text>', run: (ctx) => { const [m, ...t] = ctx.args, s = t.join(' '); if (!['encode', 'decode'].includes(m) || !s) return ctx.message.reply(usage(ctx.cmd, ctx.prefix)); return ctx.message.reply(card({ title: '🔠 Base64', body: '```\n' + clip(m === 'encode' ? Buffer.from(s).toString('base64') : Buffer.from(s, 'base64').toString('utf8'), 1500) + '\n```' })); } }),
  U({ name: 'hash', description: 'Hash text (md5, sha1, sha256, sha512)', usage: 'hash <algo> <text>', run: (ctx) => { const [a, ...t] = ctx.args; if (!['md5', 'sha1', 'sha256', 'sha512'].includes(a) || !t.length) return ctx.message.reply(usage(ctx.cmd, ctx.prefix)); return ctx.message.reply(card({ title: `#️⃣ ${a}`, body: '```\n' + crypto.createHash(a).update(t.join(' ')).digest('hex') + '\n```' })); } }),
  U({ name: 'password', aliases: ['genpass'], description: 'Generate a strong password (sent by DM)', usage: 'password [length 8-64]', async run({ message, args }) {
    const n = Math.min(Math.max(parseInt(args[0]) || 20, 8), 64), set = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*-_', pw = Array.from({ length: n }, () => set[crypto.randomInt(set.length)]).join('');
    return dmWithNotice(message, message.author, card({ title: '<:lock:1461684070600802314> Your password', body: `\`${pw}\`\nGenerated locally by the bot and not stored.`, color: 'success' }), 'Your password was sent privately.');
  } }),
  U({ name: 'bookmark', aliases: ['bm'], description: 'Save a message to your DMs (reply to it)', usage: 'bookmark (reply to a message)', async run({ message }) {
    const r = message.reference && await message.fetchReference().catch(() => null); if (!r) return message.reply(fail('Reply to a message', 'Reply to the message you want to save.'));
    return dmWithNotice(message, message.author, card({ title: '🔖 Bookmarked message', body: `${clip(r.content || '*(no text)*', 1500)}\n\n[Jump to message](${r.url})` }), 'Bookmark saved to your DMs.');
  } }),
  U({ name: 'say', description: 'Make the bot say something', usage: 'say <text>', perms: [P.ManageMessages], async run(ctx) { const t = ctx.args.join(' '); if (await need(ctx, t)) return; await ctx.message.delete().catch(() => {}); return ctx.message.channel.send(card({ title: '\u200b', body: clip(t, 1800), foot: false })); } }),
  U({ name: 'embed', description: 'Send a styled card (title | text)', usage: 'embed <title> | <text>', perms: [P.ManageMessages], async run(ctx) { const [t, ...d] = ctx.args.join(' ').split('|'); if (await need(ctx, t?.trim(), d.join('|').trim())) return; await ctx.message.delete().catch(() => {}); return ctx.message.channel.send(card({ title: clip(t.trim(), 100), body: clip(d.join('|').trim(), 1800) })); } }),
  U({ name: 'permissions', aliases: ['perms'], description: 'Permissions of a member', usage: 'permissions [member]', async run({ message, args }) { const m = (await getMember(message, args[0])) ?? message.member; return message.reply(card({ title: `<:lock:1461684070600802314> ${m.displayName}`, body: clip(m.permissions.has(P.Administrator) ? '**Administrator** (all permissions)' : m.permissions.toArray().map((p) => `\`${p}\``).join(' '), 1800) })); } }),
  U({ name: 'shardinfo', description: 'Shard information', usage: 'shardinfo', run: ({ client, message }) => message.reply(card({ title: '🧩 Shards', body: `Running as a single process.\nWebSocket ping: **${client.ws.ping}ms**` })) }),
  U({ name: 'vanity', description: 'Server vanity URL', usage: 'vanity', run: ({ message }) => message.reply(message.guild.vanityURLCode ? card({ title: '<:link:1461688818297208894> Vanity URL', body: `discord.gg/${message.guild.vanityURLCode}` }) : fail('No vanity URL', 'This server does not have one.')) }),
  U({ name: 'emojis', description: 'Server emojis', usage: 'emojis', run: ({ message }) => message.reply(card({ title: `😀 Emojis (${message.guild.emojis.cache.size})`, body: clip(message.guild.emojis.cache.map((e) => `${e}`).join(' ') || 'None', 1800) })) }),
  U({ name: 'emojiinfo', description: 'Info about a custom emoji', usage: 'emojiinfo <emoji>', run: (ctx) => { const e = emojiUrl(ctx.args[0]); return e ? ctx.message.reply(card({ title: `:${e.name}:`, image: e.url, fields: [['ID', e.id], ['Animated', e.animated ? 'Yes' : 'No']] })) : ctx.message.reply(fail('Custom emoji only')); } }),
  U({ name: 'memberlist', aliases: ['members'], description: 'Members with a role', usage: 'memberlist <@role>', run: async ({ message, args }) => { const r = message.mentions.roles.first() ?? message.guild.roles.cache.get(args[0]); if (!r) return message.reply(fail('Mention a role')); await message.guild.members.fetch().catch(() => {}); return message.reply(card({ title: `<:participants:1461683985762484446> ${r.name} (${r.members.size})`, body: clip(r.members.map((m) => m.user.username).slice(0, 60).join(', ') || 'None', 1800) })); } }),
  U({ name: 'rolelist', description: 'All server roles', usage: 'rolelist', run: ({ message }) => message.reply(card({ title: `<:badge:1461685260122198089> Roles (${message.guild.roles.cache.size})`, body: clip(message.guild.roles.cache.sort((a, b) => b.position - a.position).filter((r) => r.id !== message.guild.id).map((r) => `<@&${r.id}>`).join(' ') || 'None', 1800) })) }),
  U({ name: 'boosters', description: 'Server boosters', usage: 'boosters', run: async ({ message }) => { await message.guild.members.fetch().catch(() => {}); const b = message.guild.members.cache.filter((m) => m.premiumSince); return message.reply(card({ title: `🚀 Boosters (${b.size})`, body: b.map((m) => `<@${m.id}> — ${ts(m.premiumSinceTimestamp, 'd')}`).join('\n') || 'No boosters yet.' })); } }),
  U({ name: 'serverbanner', description: 'Server banner', usage: 'serverbanner', run: ({ message }) => { const u = message.guild.bannerURL({ size: 1024 }); return message.reply(u ? card({ title: `<:banner:1461685088059134136> ${message.guild.name}`, image: u }) : fail('No banner', 'This server has no banner.')); } }),
];
