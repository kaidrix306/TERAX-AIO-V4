import { PermissionFlagsBits as P, ChannelType, AttachmentBuilder } from 'discord.js';
import { db } from '../../core/db.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { createTicket, closeTicket, getTicket, getCfg, isStaff, panelPayload, buildTranscript } from '../../core/tickets.js';
import { clip, getMember, getChannel, getRole, ts, idOf } from '../../core/util.js';

const T = { category: 'ticket' };
// Resolve the ticket for this channel; optionally require staff.
async function ctx(message, { staff = false } = {}) {
  const t = getTicket(message.channel.id);
  if (!t) { await message.reply(fail('Not a ticket', 'Use this inside an open ticket channel.')); return null; }
  const cfg = getCfg(t.guild);
  if (staff && !isStaff(message.member, cfg)) { await message.reply(fail('Staff only', 'Only ticket staff can do that.')); return null; }
  return { t, cfg };
}

export default [
  { ...T, name: 'ticketsetup', aliases: ['tsetup'], description: 'Configure tickets', usage: 'ticketsetup [category <id> | role <@role> | log <#channel> | max <1-5>]', perms: [P.ManageGuild],
    async run({ message, args, prefix }) {
      const gid = message.guild.id, [sub, ...rest] = args, val = rest.join(' ');
      db.prepare('INSERT OR IGNORE INTO ticket_cfg(guild) VALUES (?)').run(gid);
      if (sub === 'category') {
        const c = message.guild.channels.cache.get(idOf(val));
        if (c?.type !== ChannelType.GuildCategory) return message.reply(fail('Invalid category', 'Give the ID of a category (right-click it <:right:1461683867835564201> Copy ID).'));
        db.prepare('UPDATE ticket_cfg SET category=? WHERE guild=?').run(c.id, gid); return message.reply(ok('Ticket category set', c.name));
      }
      if (sub === 'role') {
        const r = getRole(message, val); if (!r) return message.reply(fail('Invalid role', 'Mention a role or give its ID.'));
        db.prepare('UPDATE ticket_cfg SET staff_role=? WHERE guild=?').run(r.id, gid); return message.reply(ok('Staff role set', r.name));
      }
      if (sub === 'log') {
        const c = getChannel(message, val); if (!c?.isTextBased()) return message.reply(fail('Invalid channel', 'Mention a text channel.'));
        db.prepare('UPDATE ticket_cfg SET log_channel=? WHERE guild=?').run(c.id, gid); return message.reply(ok('Ticket log set', `<#${c.id}>`));
      }
      if (sub === 'max') {
        const n = parseInt(val, 10); if (!n || n < 1 || n > 5) return message.reply(fail('Invalid number', 'Pick 1 to 5.'));
        db.prepare('UPDATE ticket_cfg SET max_open=? WHERE guild=?').run(n, gid); return message.reply(ok('Max open tickets', `${n} per user`));
      }
      const c = getCfg(gid);
      return message.reply(card({ title: '<:ticket:1461684796181708800> Ticket setup', body: `Run \`${prefix}ticketsetup category|role|log|max <value>\`, then \`${prefix}ticketpanel\`.`, fields: [
        ['Category', c.category ? `<#${c.category}>` : 'Not set'], ['Staff role', c.staff_role ? `<@&${c.staff_role}>` : 'Not set'],
        ['Log channel', c.log_channel ? `<#${c.log_channel}>` : 'Not set'], ['Max open per user', c.max_open]] }));
    } },
  { ...T, name: 'ticketpanel', aliases: ['panel'], description: 'Send the ticket panel with a Create Ticket button', usage: 'ticketpanel [#channel]', perms: [P.ManageGuild],
    async run({ message, args }) {
      const c = getChannel(message, args[0]) ?? message.channel;
      if (!getCfg(message.guild.id)?.category) return message.reply(warn('Set up first', 'Run `ticketsetup category <id>` before sending the panel.'));
      await c.send(panelPayload()); if (c.id !== message.channel.id) return message.reply(ok('Panel sent', `<#${c.id}>`));
    } },
  { ...T, name: 'ticket', aliases: ['new', 'open'], description: 'Open a ticket', usage: 'ticket [topic]',
    async run({ message, args }) {
      const r = await createTicket(message.guild, message.member, clip(args.join(' ') || 'No topic given', 200));
      return message.reply(r.error ? fail('Cannot open ticket', r.error) : ok('Ticket created', `<#${r.channel.id}>`));
    } },
  { ...T, name: 'close', description: 'Close this ticket', usage: 'close [reason]',
    async run({ message, args }) {
      const x = await ctx(message); if (!x) return;
      if (message.author.id !== x.t.owner && !isStaff(message.member, x.cfg)) return message.reply(fail('Not allowed', 'Only staff or the ticket owner can close this.'));
      await closeTicket(message.channel, message.author, clip(args.join(' ') || 'No reason given', 300));
    } },
  { ...T, name: 'delete', description: 'Close and delete this ticket (staff)', usage: 'delete',
    async run({ message }) { const x = await ctx(message, { staff: true }); if (!x) return; await closeTicket(message.channel, message.author, 'Deleted by staff'); } },
  { ...T, name: 'claim', description: 'Claim this ticket (turns the AI off)', usage: 'claim',
    async run({ message }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      if (x.t.claimed_by) return message.reply(warn('Already claimed', `Claimed by <@${x.t.claimed_by}>.`));
      db.prepare('UPDATE tickets SET claimed_by=?, ai_on=0 WHERE channel=?').run(message.author.id, x.t.channel);
      return message.reply(ok('Ticket claimed', `<@${message.author.id}> is handling this ticket.`));
    } },
  { ...T, name: 'unclaim', description: 'Release your claim', usage: 'unclaim',
    async run({ message }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      db.prepare('UPDATE tickets SET claimed_by=NULL WHERE channel=?').run(x.t.channel); return message.reply(ok('Ticket unclaimed'));
    } },
  { ...T, name: 'add', description: 'Add a member to this ticket', usage: 'add <member>',
    async run({ message, args, prefix, cmd }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      const m = await getMember(message, args[0]); if (!m) return message.reply(usage(cmd, prefix));
      await message.channel.permissionOverwrites.edit(m.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
      return message.reply(ok('Member added', `<@${m.id}>`));
    } },
  { ...T, name: 'remove', description: 'Remove a member from this ticket', usage: 'remove <member>',
    async run({ message, args, prefix, cmd }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      const m = await getMember(message, args[0]); if (!m) return message.reply(usage(cmd, prefix));
      if (m.id === x.t.owner) return message.reply(fail('Cannot', 'You cannot remove the ticket owner.'));
      await message.channel.permissionOverwrites.delete(m.id); return message.reply(ok('Member removed', m.user.username));
    } },
  { ...T, name: 'rename', description: 'Rename this ticket channel', usage: 'rename <name>',
    async run({ message, args, prefix, cmd }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      const n = args.join('-').toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 90);
      if (!n) return message.reply(usage(cmd, prefix));
      await message.channel.setName(n); return message.reply(ok('Renamed', n));
    } },
  { ...T, name: 'transfer', description: 'Transfer the ticket to another staff member', usage: 'transfer <staff member>',
    async run({ message, args, prefix, cmd }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      const m = await getMember(message, args[0]);
      if (!m || !isStaff(m, x.cfg)) return message.reply(m ? fail('Not staff', 'That member is not ticket staff.') : usage(cmd, prefix));
      db.prepare('UPDATE tickets SET claimed_by=?, ai_on=0 WHERE channel=?').run(m.id, x.t.channel);
      return message.reply(ok('Ticket transferred', `Now handled by <@${m.id}>.`));
    } },
  { ...T, name: 'priority', description: 'Set ticket priority', usage: 'priority <low|normal|high|urgent>',
    async run({ message, args, prefix, cmd }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      const p = args[0]?.toLowerCase(); if (!['low', 'normal', 'high', 'urgent'].includes(p)) return message.reply(usage(cmd, prefix));
      db.prepare('UPDATE tickets SET priority=? WHERE channel=?').run(p, x.t.channel);
      await message.channel.setName(`${{ low: '🟢', normal: '🟡', high: '🟠', urgent: '🔴' }[p]}-${message.channel.name.replace(/^[^a-z0-9]+-?/, '')}`.slice(0, 100)).catch(() => {});
      return message.reply(ok('Priority set', p));
    } },
  { ...T, name: 'transcript', description: 'Generate a transcript of this ticket', usage: 'transcript',
    async run({ message }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      const text = await buildTranscript(message.channel);
      await message.reply({ files: [new AttachmentBuilder(Buffer.from(text || 'Empty ticket.'), { name: `transcript-${message.channel.name}.txt` })] });
    } },
  { ...T, name: 'human', aliases: ['staff'], description: 'Turn off the AI and call staff', usage: 'human',
    async run({ message }) {
      const x = await ctx(message); if (!x) return;
      if (message.author.id !== x.t.owner && !isStaff(message.member, x.cfg)) return message.reply(fail('Not allowed', 'Only the ticket owner or staff can do this.'));
      db.prepare('UPDATE tickets SET ai_on=0 WHERE channel=?').run(x.t.channel);
      return message.reply({ ...warn('Human requested', `AI replies are off. ${x.cfg?.staff_role ? `<@&${x.cfg.staff_role}>` : 'Staff'} will be with you soon.`), allowedMentions: { roles: x.cfg?.staff_role ? [x.cfg.staff_role] : [] } });
    } },
  { ...T, name: 'ai', description: 'Turn the AI on or off in this ticket', usage: 'ai <on|off>',
    async run({ message, args, prefix, cmd }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      if (!['on', 'off'].includes(args[0])) return message.reply(usage(cmd, prefix));
      db.prepare('UPDATE tickets SET ai_on=? WHERE channel=?').run(args[0] === 'on' ? 1 : 0, x.t.channel);
      return message.reply(ok('Ticket AI', args[0] === 'on' ? 'On' : 'Off'));
    } },
  { ...T, name: 'ticketnote', aliases: ['tnote'], description: 'Add or view private staff notes (shown via DM-safe delete)', usage: 'ticketnote [text]',
    async run({ message, args }) {
      const x = await ctx(message, { staff: true }); if (!x) return;
      if (args.length) {
        db.prepare('INSERT INTO ticket_notes(channel,mod,text,at) VALUES (?,?,?,?)').run(x.t.channel, message.author.id, clip(args.join(' '), 400), Date.now());
        await message.delete().catch(() => {});
        const m = await message.channel.send(ok('Note saved', 'Notes are only shown in the staff log when the ticket closes.')); setTimeout(() => m.delete().catch(() => {}), 4000); return;
      }
      const n = db.prepare('SELECT COUNT(*) c FROM ticket_notes WHERE channel=?').get(x.t.channel).c;
      return message.reply(warn('Notes', `${n} note(s) saved. Add one with the command plus text.`));
    } },
  { ...T, name: 'tickets', description: 'List open tickets', usage: 'tickets', perms: [P.ManageMessages],
    async run({ message }) {
      const rows = db.prepare("SELECT * FROM tickets WHERE guild=? AND status='open' ORDER BY created DESC LIMIT 20").all(message.guild.id);
      return message.reply(card({ title: `<:ticket:1461684796181708800> Open tickets (${rows.length})`, body: rows.map((r) => `<#${r.channel}> • <@${r.owner}> • ${r.priority} • ${ts(r.created)}${r.claimed_by ? ` • <@${r.claimed_by}>` : ''}`).join('\n') || 'No open tickets.' }));
    } },
  { ...T, name: 'ticketstats', aliases: ['tstats'], description: 'Ticket statistics', usage: 'ticketstats', perms: [P.ManageMessages],
    async run({ message }) {
      const g = message.guild.id, c = (w) => db.prepare(`SELECT COUNT(*) c FROM tickets WHERE guild=? ${w}`).get(g).c;
      const top = db.prepare('SELECT claimed_by u, COUNT(*) n FROM tickets WHERE guild=? AND claimed_by IS NOT NULL GROUP BY claimed_by ORDER BY n DESC LIMIT 3').all(g);
      return message.reply(card({ title: '<:status:1461683996302901515> Ticket stats', fields: [['Open', c("AND status='open'")], ['Closed', c("AND status='closed'")], ['Total', c('')],
        ['Top claimers', top.map((t) => `<@${t.u}> (${t.n})`).join(', ') || 'None yet']] }));
    } },
];
