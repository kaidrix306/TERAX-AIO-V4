import { PermissionFlagsBits as P } from 'discord.js';
import { kvSet, kvGet } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { aiMem } from '../../core/aimem.js';
import { clip, getChannel } from '../../core/util.js';

const A = { category: 'ai', cooldown: 3, perms: [P.ManageGuild] };
export default [
  { ...A, name: 'aipersona', description: 'Give the AI a personality/role (used by AI commands and the AI channel)', usage: 'aipersona <text|show|reset>', async run({ message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); const g = message.guild.id;
    if (args[0] === 'show') return message.reply(card({ title: '<:autoreact:1461688622485995699> AI persona', body: kvGet(g, 'ai_persona') ?? 'Default assistant.' }));
    if (args[0] === 'reset') { kvSet(g, 'ai_persona', null); return message.reply(ok('Persona reset')); }
    kvSet(g, 'ai_persona', clip(args.join(' '), 600)); return message.reply(ok('Persona saved', clip(args.join(' '), 200)));
  } },
  { ...A, name: 'aichannel', description: 'Let the AI chat with everyone in one channel', usage: 'aichannel <#channel|off>', async run({ message, args, prefix, cmd }) {
    const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix));
    kvSet(message.guild.id, 'ai_channel', c?.id ?? null); return message.reply(ok('AI channel', c ? `<#${c.id}> — I will answer messages there. Do not share private info; replies come from Google Gemini.` : 'Disabled'));
  } },
  { ...A, perms: [], name: 'aireset', description: 'Clear the AI\'s memory of your conversation here', usage: 'aireset', async run({ message }) {
    aiMem.delete(`${message.channel.id}:${message.author.id}`); return message.reply(ok('AI memory cleared'));
  } },
];
