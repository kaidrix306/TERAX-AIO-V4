import { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits as P } from 'discord.js';
import { db, kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { queues, connect, advance, destroy, resolveQuery, fmtTime, applyFilters, musicOnline } from '../../core/music.js';
import { config } from '../../core/config.js';
import { clip, getRole, getChannel, idOf } from '../../core/util.js';

const M = (o) => ({ category: 'music', cooldown: 2, ...o });
const isDJ = (m) => { const r = kvGet(m.guild.id, 'dj_role'); return !r || m.member.roles.cache.has(r) || m.member.permissions.has(P.ManageGuild); };
const reqOf = (q) => q.current?.requester;

// Common checks. join: create the player if needed. dj: DJ role required.
async function ctx(message, { join = false, dj = false, playing = false } = {}) {
  const client = message.client, g = message.guild.id;
  if (!musicOnline(client)) { await message.reply(fail('Music is offline', 'No Lavalink node is connected right now.')); return null; }
  const mc = kvGet(g, 'music_channel');
  if (mc && message.channel.id !== mc && !message.member.permissions.has(P.ManageGuild)) { await message.reply(fail('Wrong channel', `Use music commands in <#${mc}>.`)); return null; }
  const vc = message.member.voice.channel;
  if (!vc) { await message.reply(fail('Join a voice channel', 'Join a voice channel first.')); return null; }
  let q = queues.get(g);
  if (!q) {
    if (!join) { await message.reply(fail('Nothing is playing')); return null; }
    const me = message.guild.members.me, perms = vc.permissionsFor(me);
    if (!perms.has([P.Connect, P.Speak])) { await message.reply(fail('Missing permissions', 'I need Connect and Speak in that voice channel.')); return null; }
    q = await connect(client, message.guild, vc.id, message.channel);
  } else if (q.voiceId !== vc.id && message.guild.members.me.voice.channelId !== vc.id) { await message.reply(fail('Wrong voice channel', 'You must be in my voice channel.')); return null; }
  q.text = message.channel;
  if (dj && !isDJ(message)) { await message.reply(fail('DJ only', 'You need the DJ role (or Manage Server) for this.')); return null; }
  if (playing && !q.current) { await message.reply(fail('Nothing is playing')); return null; }
  return q;
}
const track = (t) => `[${clip(t.info.title, 55)}](${t.info.uri}) \`${t.info.isStream ? 'LIVE' : fmtTime(t.info.length)}\``;
const num = (s, max) => { const n = parseInt(s); return n >= 1 && n <= max ? n : null; };
const parseTime = (s) => { const p = String(s ?? '').split(':').map(Number); if (!p.length || p.some((x) => isNaN(x) || x < 0) || p.length > 3) return null; return p.reduce((a, x) => a * 60 + x, 0) * 1000; };
const filter = (name, desc, data) => M({ name, description: desc, usage: name, async run({ message }) {
  const q = await ctx(message, { dj: true, playing: true }); if (!q) return;
  const on = !q.filters[name]; if (on) q.filters[name] = data; else delete q.filters[name];
  await applyFilters(q); return message.reply(ok(name, on ? 'Enabled (takes a moment to apply).' : 'Disabled.'));
} });
const eq = (...b) => b.map(([band, gain]) => ({ band, gain }));
async function addTracks(client, q, items, message) {
  if (q.tracks.length + items.length > config.music.maxQueue) return message.reply(fail('Queue is full', `Max ${config.music.maxQueue} tracks.`));
  const was = !!q.current; q.tracks.push(...items);
  if (!q.current) await advance(client, q);
  return was ? message.reply(ok('Added to queue', items.length === 1 ? track(items[0]) : `${items.length} tracks`)) : null;
}

export default [
  M({ name: 'play', aliases: ['p'], description: 'Play a song or add it to the queue', usage: 'play <name or URL>', cooldown: 3, async run({ client, message, args, prefix, cmd }) {
    const query = args.join(' ') || message.attachments.first()?.url; if (!query) return message.reply(usage(cmd, prefix));
    const q = await ctx(message, { join: true }); if (!q) return;
    let r; try { r = await resolveQuery(client, query); } catch (e) { return message.reply(fail('Could not load that', clip(e.message === 'NO_NODE' ? 'No Lavalink node.' : e.message, 150))); }
    if (r.type === 'error') return message.reply(fail('Load failed', clip(r.error ?? 'The source could not be loaded.', 200)));
    if (!r.tracks.length) return message.reply(fail('No results', 'Nothing matched that search.'));
    const picked = r.type === 'playlist' ? r.tracks.slice(0, 100) : [r.tracks[0]];
    const res = await addTracks(client, q, picked.map((t) => ({ ...t, requester: message.author.id })), message);
    if (r.type === 'playlist' && !res) message.channel.send(ok('Playlist loaded', `**${clip(r.name ?? 'Playlist', 60)}** — ${picked.length} tracks`)).catch(() => {});
  } }),
  M({ name: 'search', description: 'Search and pick a result', usage: 'search <query>', cooldown: 5, async run({ client, message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); const q = await ctx(message, { join: true }); if (!q) return;
    const r = await resolveQuery(client, args.join(' ')).catch(() => null); const list = r?.tracks.slice(0, 5); if (!list?.length) return message.reply(fail('No results'));
    const row = new ActionRowBuilder().addComponents(list.map((_, i) => new ButtonBuilder().setCustomId(`sr:${i}`).setLabel(String(i + 1)).setStyle(ButtonStyle.Primary)));
    const m = await message.reply(card({ title: '🔎 Pick a track', body: list.map((t, i) => `**${i + 1}.** ${track(t)}`).join('\n'), rows: [row] }));
    try { const i = await m.awaitMessageComponent({ filter: (x) => x.user.id === message.author.id, time: 30000 }); await i.update(card({ title: '🔎 Selected', body: track(list[+i.customId.slice(3)]) }));
      await addTracks(client, q, [{ ...list[+i.customId.slice(3)], requester: message.author.id }], message); } catch { m.edit(warn('Search expired')).catch(() => {}); }
  } }),
  M({ name: 'pause', description: 'Pause playback', usage: 'pause', async run({ message }) { const q = await ctx(message, { playing: true }); if (!q) return; await q.player.setPaused(true); return message.reply(ok('Paused')); } }),
  M({ name: 'resume', aliases: ['unpause'], description: 'Resume playback', usage: 'resume', async run({ message }) { const q = await ctx(message, { playing: true }); if (!q) return; await q.player.setPaused(false); return message.reply(ok('Resumed')); } }),
  M({ name: 'stop', aliases: ['disconnect', 'dc'], description: 'Stop and leave', usage: 'stop', async run({ client, message }) { const q = await ctx(message, { dj: true }); if (!q) return; destroy(client, message.guild.id); return message.reply(ok('Stopped', 'Queue cleared and left the channel.')); } }),
  M({ name: 'skip', aliases: ['s', 'next'], description: 'Skip the current song', usage: 'skip', async run({ client, message }) {
    const q = await ctx(message, { playing: true }); if (!q) return;
    if (reqOf(q) !== message.author.id && !isDJ(message)) return message.reply(fail('DJ only', 'Only the requester or a DJ can skip this track.'));
    const t = q.current; await advance(client, q, true); return message.reply(ok('Skipped', track(t)));
  } }),
  M({ name: 'previous', aliases: ['prev', 'back'], description: 'Play the previous song', usage: 'previous', async run({ client, message }) {
    const q = await ctx(message, { dj: true, playing: true }); if (!q) return; const p = q.history.pop(); if (!p) return message.reply(fail('No previous track'));
    if (q.current) q.tracks.unshift(q.current); q.current = null; q.tracks.unshift(p); await advance(client, q, true); return message.reply(ok('Going back'));
  } }),
  M({ name: 'queue', aliases: ['q'], description: 'Show the queue', usage: 'queue [page]', async run({ message, args }) {
    const q = queues.get(message.guild.id); if (!q?.current) return message.reply(fail('Nothing is playing'));
    const page = Math.max(1, parseInt(args[0]) || 1), pages = Math.max(1, Math.ceil(q.tracks.length / 10)), items = q.tracks.slice((page - 1) * 10, page * 10);
    return message.reply(card({ title: `<:list:1461683931546910917> Queue (${q.tracks.length})`, body: `**Now:** ${track(q.current)}\n\n${items.map((t, i) => `**${(page - 1) * 10 + i + 1}.** ${track(t)}`).join('\n') || '*Nothing up next*'}`, fields: [['Page', `${Math.min(page, pages)}/${pages}`], ['Loop', q.loop], ['Autoplay', q.autoplay ? 'on' : 'off']] }));
  } }),
  M({ name: 'nowplaying', aliases: ['np'], description: 'Show the current song', usage: 'nowplaying', async run({ message }) {
    const q = queues.get(message.guild.id); if (!q?.current) return message.reply(fail('Nothing is playing')); const t = q.current.info, pos = q.player.position ?? 0, len = t.length || 1, f = Math.min(15, Math.round((pos / len) * 15));
    return message.reply(card({ title: '<:music:1461683725602525318> Now playing', body: `**[${clip(t.title, 90)}](${t.uri})**\n${t.author}\n\`${'▬'.repeat(f)}🔘${'▬'.repeat(15 - f)}\` ${fmtTime(pos)} / ${t.isStream ? 'LIVE' : fmtTime(t.length)}`, thumb: t.artworkUrl || undefined, fields: [['Requested by', `<@${q.current.requester}>`], ['Volume', `${q.volume}%`], ['Loop', q.loop]] }));
  } }),
  M({ name: 'volume', aliases: ['vol'], description: 'Set the volume (1-150)', usage: 'volume [1-150]', async run({ message, args }) {
    const q = await ctx(message, { playing: true }); if (!q) return; if (!args[0]) return message.reply(card({ title: '<:category_voice:1461683815067156593> Volume', body: `${q.volume}%` }));
    if (!isDJ(message)) return message.reply(fail('DJ only')); const v = num(args[0], 150); if (!v) return message.reply(fail('Pick 1 to 150'));
    q.volume = v; await q.player.setGlobalVolume(v); return message.reply(ok('Volume', `${v}%`));
  } }),
  M({ name: 'loop', aliases: ['repeat'], description: 'Loop off, the track, or the queue', usage: 'loop <off|track|queue>', async run({ message, args, prefix, cmd }) {
    const q = await ctx(message, { dj: true }); if (!q) return; const m = { off: 'off', track: 'track', song: 'track', queue: 'queue', all: 'queue' }[args[0]?.toLowerCase()]; if (!m) return message.reply(usage(cmd, prefix));
    q.loop = m; return message.reply(ok('Loop', m));
  } }),
  M({ name: 'shuffle', description: 'Shuffle the queue', usage: 'shuffle', async run({ message }) {
    const q = await ctx(message, { dj: true }); if (!q) return; if (q.tracks.length < 2) return message.reply(fail('Not enough tracks'));
    for (let i = q.tracks.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [q.tracks[i], q.tracks[j]] = [q.tracks[j], q.tracks[i]]; } return message.reply(ok('Queue shuffled'));
  } }),
  M({ name: 'seek', description: 'Seek to a time (e.g. 1:30)', usage: 'seek <mm:ss|seconds>', async run({ message, args, prefix, cmd }) {
    const q = await ctx(message, { dj: true, playing: true }); if (!q) return; const ms = parseTime(args[0]); if (ms === null) return message.reply(usage(cmd, prefix));
    if (q.current.info.isStream || ms >= q.current.info.length) return message.reply(fail('Cannot seek there')); await q.player.seekTo(ms); return message.reply(ok('Seeked', fmtTime(ms)));
  } }),
  ...[['forward', 1], ['rewind', -1]].map(([name, dir]) => M({ name, aliases: [name === 'forward' ? 'ff' : 'rw'], description: `${name === 'forward' ? 'Skip ahead' : 'Go back'} (default 10s)`, usage: `${name} [seconds]`, async run({ message, args }) {
    const q = await ctx(message, { dj: true, playing: true }); if (!q) return; if (q.current.info.isStream) return message.reply(fail('Cannot seek a live stream'));
    const to = Math.min(Math.max((q.player.position ?? 0) + dir * (parseInt(args[0]) || 10) * 1000, 0), q.current.info.length - 1000); await q.player.seekTo(to); return message.reply(ok(name, fmtTime(to)));
  } })),
  M({ name: 'skipto', description: 'Skip to a queue position', usage: 'skipto <number>', async run({ client, message, args, prefix, cmd }) {
    const q = await ctx(message, { dj: true, playing: true }); if (!q) return; const n = num(args[0], q.tracks.length); if (!n) return message.reply(usage(cmd, prefix));
    q.tracks.splice(0, n - 1); await advance(client, q, true); return message.reply(ok('Skipped ahead', `To position ${n}`));
  } }),
  M({ name: 'removesong', aliases: ['rm'], description: 'Remove a song from the queue', usage: 'removesong <number>', async run({ message, args, prefix, cmd }) {
    const q = await ctx(message, { dj: true }); if (!q) return; const n = num(args[0], q.tracks.length); if (!n) return message.reply(usage(cmd, prefix));
    const [t] = q.tracks.splice(n - 1, 1); return message.reply(ok('Removed', track(t)));
  } }),
  M({ name: 'clearqueue', aliases: ['cq'], description: 'Clear the queue (keeps the current song)', usage: 'clearqueue', async run({ message }) { const q = await ctx(message, { dj: true }); if (!q) return; const n = q.tracks.length; q.tracks = []; return message.reply(ok('Queue cleared', `${n} tracks removed.`)); } }),
  M({ name: 'movesong', aliases: ['move'], description: 'Move a song in the queue', usage: 'movesong <from> <to>', async run({ message, args, prefix, cmd }) {
    const q = await ctx(message, { dj: true }); if (!q) return; const a = num(args[0], q.tracks.length), b = num(args[1], q.tracks.length); if (!a || !b) return message.reply(usage(cmd, prefix));
    const [t] = q.tracks.splice(a - 1, 1); q.tracks.splice(b - 1, 0, t); return message.reply(ok('Moved', `${track(t)} <:right:1461683867835564201> position ${b}`));
  } }),
  M({ name: 'replay', description: 'Restart the current song', usage: 'replay', async run({ message }) { const q = await ctx(message, { dj: true, playing: true }); if (!q) return; await q.player.seekTo(0); return message.reply(ok('Replaying')); } }),
  M({ name: 'lyrics', description: 'Find lyrics for the current (or a named) song', usage: 'lyrics [song]', async run({ message, args }) {
    const q = queues.get(message.guild.id), s = args.join(' ') || (q?.current ? `${q.current.info.author} ${q.current.info.title}` : ''); if (!s) return message.reply(fail('Name a song or play one'));
    return message.reply(card({ title: '<:music:1461683725602525318> Lyrics', body: `The bot does not copy lyrics text (they are copyrighted). Find them here:\n[Genius](https://genius.com/search?q=${encodeURIComponent(s)}) • [Search](https://www.google.com/search?q=${encodeURIComponent(`${s} lyrics`)})` }));
  } }),
  M({ name: 'autoplay', description: 'Keep playing similar songs when the queue ends', usage: 'autoplay', async run({ message }) { const q = await ctx(message, { dj: true }); if (!q) return; q.autoplay = !q.autoplay; return message.reply(ok('Autoplay', q.autoplay ? 'On' : 'Off')); } }),
  filter('bassboost', 'Boost the bass', { equalizer: eq([0, 0.25], [1, 0.25], [2, 0.2], [3, 0.1]) }),
  filter('nightcore', 'Faster, higher pitch', { timescale: { speed: 1.2, pitch: 1.2, rate: 1 } }),
  filter('vaporwave', 'Slower, lower pitch', { timescale: { speed: 0.85, pitch: 0.8, rate: 1 } }),
  filter('8d', '8D rotating audio', { rotation: { rotationHz: 0.2 } }),
  filter('karaoke', 'Reduce vocals', { karaoke: { level: 1, monoLevel: 1, filterBand: 220, filterWidth: 100 } }),
  filter('treble', 'Boost the treble', { equalizer: eq([8, 0.2], [9, 0.25], [10, 0.25], [11, 0.2], [12, 0.15]) }),
  filter('tremolo', 'Tremolo effect', { tremolo: { frequency: 4, depth: 0.75 } }),
  filter('vibrato', 'Vibrato effect', { vibrato: { frequency: 4, depth: 0.75 } }),
  M({ name: 'resetfilters', aliases: ['clearfilters'], description: 'Remove all audio filters', usage: 'resetfilters', async run({ message }) { const q = await ctx(message, { dj: true }); if (!q) return; q.filters = {}; await applyFilters(q); return message.reply(ok('Filters cleared')); } }),

  // ---- Playlists (saved per user) ----
  M({ name: 'playlistcreate', aliases: ['plcreate'], description: 'Create a playlist', usage: 'playlistcreate <name>', async run({ message, args, prefix, cmd }) {
    const n = args.join(' ').toLowerCase().slice(0, 30); if (!n) return message.reply(usage(cmd, prefix));
    if (db.prepare('SELECT COUNT(*) c FROM playlists WHERE user=?').get(message.author.id).c >= 10) return message.reply(fail('Limit reached', 'Max 10 playlists.'));
    try { db.prepare('INSERT INTO playlists(user,name) VALUES (?,?)').run(message.author.id, n); } catch { return message.reply(fail('Already exists')); } return message.reply(ok('Playlist created', n));
  } }),
  M({ name: 'playlistadd', aliases: ['pladd'], description: 'Add the current song or a search to a playlist', usage: 'playlistadd <playlist> [song]', async run({ client, message, args, prefix, cmd }) {
    const pl = db.prepare('SELECT * FROM playlists WHERE user=? AND name=?').get(message.author.id, (args[0] ?? '').toLowerCase()); if (!pl) return message.reply(args[0] ? fail('No such playlist') : usage(cmd, prefix));
    if (db.prepare('SELECT COUNT(*) c FROM playlist_tracks WHERE pid=?').get(pl.id).c >= 100) return message.reply(fail('Playlist full', 'Max 100 tracks.'));
    let t; if (args[1]) { const r = await resolveQuery(client, args.slice(1).join(' ')).catch(() => null); t = r?.tracks[0]; } else t = queues.get(message.guild.id)?.current;
    if (!t) return message.reply(fail('Nothing to add', 'Play a song or give a search.'));
    db.prepare('INSERT INTO playlist_tracks VALUES (?,?,?,?,?)').run(pl.id, Date.now(), t.info.title, t.info.uri, t.info.length); return message.reply(ok('Added', `${track(t)} <:right:1461683867835564201> **${pl.name}**`));
  } }),
  M({ name: 'playlistremove', aliases: ['plremove'], description: 'Remove a track from a playlist', usage: 'playlistremove <playlist> <number>', async run({ message, args, prefix, cmd }) {
    const pl = db.prepare('SELECT * FROM playlists WHERE user=? AND name=?').get(message.author.id, (args[0] ?? '').toLowerCase()); if (!pl) return message.reply(usage(cmd, prefix));
    const rows = db.prepare('SELECT rowid r FROM playlist_tracks WHERE pid=? ORDER BY pos').all(pl.id), n = num(args[1], rows.length); if (!n) return message.reply(fail('Invalid number'));
    db.prepare('DELETE FROM playlist_tracks WHERE rowid=?').run(rows[n - 1].r); return message.reply(ok('Removed', `Track ${n}`));
  } }),
  M({ name: 'playlistplay', aliases: ['plplay'], description: 'Queue a saved playlist', usage: 'playlistplay <playlist>', cooldown: 5, async run({ client, message, args, prefix, cmd }) {
    const pl = db.prepare('SELECT * FROM playlists WHERE user=? AND name=?').get(message.author.id, (args[0] ?? '').toLowerCase()); if (!pl) return message.reply(args[0] ? fail('No such playlist') : usage(cmd, prefix));
    const rows = db.prepare('SELECT * FROM playlist_tracks WHERE pid=? ORDER BY pos').all(pl.id); if (!rows.length) return message.reply(fail('Playlist is empty'));
    const q = await ctx(message, { join: true }); if (!q) return; const items = [];
    for (let i = 0; i < rows.length; i += 5) { const rs = await Promise.all(rows.slice(i, i + 5).map((r) => resolveQuery(client, r.uri).catch(() => null))); for (const r of rs) if (r?.tracks[0]) items.push({ ...r.tracks[0], requester: message.author.id }); }
    if (!items.length) return message.reply(fail('Could not load tracks', 'None of the saved links could be loaded.'));
    const res = await addTracks(client, q, items, message); if (!res) message.channel.send(ok('Playlist queued', `**${pl.name}** — ${items.length} tracks`)).catch(() => {});
  } }),
  M({ name: 'playlists', aliases: ['pls'], description: 'Your playlists', usage: 'playlists', async run({ message }) {
    const r = db.prepare('SELECT p.name, (SELECT COUNT(*) FROM playlist_tracks t WHERE t.pid=p.id) n FROM playlists p WHERE p.user=?').all(message.author.id);
    return message.reply(card({ title: '<:folder:1461683703120924826> Your playlists', body: r.map((x) => `**${x.name}** — ${x.n} tracks`).join('\n') || 'None yet. Create one with `playlistcreate`.' }));
  } }),
  M({ name: 'playlistdelete', aliases: ['pldelete'], description: 'Delete a playlist', usage: 'playlistdelete <playlist>', async run({ message, args, prefix, cmd }) {
    const pl = db.prepare('SELECT * FROM playlists WHERE user=? AND name=?').get(message.author.id, (args[0] ?? '').toLowerCase()); if (!pl) return message.reply(usage(cmd, prefix));
    db.prepare('DELETE FROM playlist_tracks WHERE pid=?').run(pl.id); db.prepare('DELETE FROM playlists WHERE id=?').run(pl.id); return message.reply(ok('Playlist deleted', pl.name));
  } }),
  M({ name: 'savequeue', description: 'Save the current queue as a playlist', usage: 'savequeue <name>', async run({ message, args, prefix, cmd }) {
    const q = queues.get(message.guild.id), n = args.join(' ').toLowerCase().slice(0, 30); if (!q?.current) return message.reply(fail('Nothing is playing')); if (!n) return message.reply(usage(cmd, prefix));
    let pl = db.prepare('SELECT * FROM playlists WHERE user=? AND name=?').get(message.author.id, n);
    if (!pl) { if (db.prepare('SELECT COUNT(*) c FROM playlists WHERE user=?').get(message.author.id).c >= 10) return message.reply(fail('Limit reached', 'Max 10 playlists.')); pl = { id: Number(db.prepare('INSERT INTO playlists(user,name) VALUES (?,?)').run(message.author.id, n).lastInsertRowid), name: n }; }
    const all = [q.current, ...q.tracks].slice(0, 100); all.forEach((t, i) => db.prepare('INSERT INTO playlist_tracks VALUES (?,?,?,?,?)').run(pl.id, Date.now() + i, t.info.title, t.info.uri, t.info.length));
    return message.reply(ok('Queue saved', `${all.length} tracks <:right:1461683867835564201> **${pl.name}**`));
  } }),
  M({ name: 'djrole', description: 'Set the DJ role (off = everyone)', usage: 'djrole <@role|off>', perms: [P.ManageGuild], async run({ message, args, prefix, cmd }) {
    if (args[0] === 'off') { kvSet(message.guild.id, 'dj_role', null); return message.reply(ok('DJ role removed', 'Everyone in the voice channel can control music.')); }
    const r = getRole(message, args.join(' ')); if (!r) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, 'dj_role', r.id); return message.reply(ok('DJ role set', r.name));
  } }),
  M({ name: 'musicchannel', description: 'Restrict music commands to one channel', usage: 'musicchannel <#channel|off>', perms: [P.ManageGuild], async run({ message, args, prefix, cmd }) {
    const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix)); kvSet(message.guild.id, 'music_channel', c?.id ?? null); return message.reply(ok('Music channel', c ? `<#${c.id}>` : 'Any channel'));
  } }),
];
