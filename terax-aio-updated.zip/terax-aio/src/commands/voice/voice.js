import { PermissionFlagsBits as P, ChannelType } from 'discord.js';
import { db } from '../../core/db.js';
import { card, ok, fail, usage } from '../../core/ui.js';
import { clip, getMember, idOf, fmtDuration } from '../../core/util.js';

const V = { category: 'voice', cooldown: 3 };
async function myVC(m, { owner = false } = {}) {
  const ch = m.member.voice.channel;
  if (!ch) { await m.reply(fail('Join a voice channel', 'You must be in a voice channel to use this.')); return null; }
  if (owner) {
    const t = db.prepare('SELECT owner FROM tempvc WHERE channel=?').get(ch.id);
    if (t?.owner !== m.author.id && !m.member.permissions.has(P.ManageChannels)) { await m.reply(fail('Not allowed', 'You need Manage Channels, or to own this temp channel.')); return null; }
  }
  return ch;
}
const target = async (message, args, prefix, cmd) => { const t = await getMember(message, args[0]); if (!t) await message.reply(usage(cmd, prefix)); return t; };
const voiceChan = (message, arg) => { const c = message.guild.channels.cache.get(idOf(arg)); return c && [ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(c.type) ? c : null; };

// Member-level actions on one target (mute/deafen/kick/move/pull)
const one = (name, desc, perms, fn, usageStr = `${name} <member>`) => ({ ...V, name, description: desc, usage: usageStr, perms, botPerms: perms,
  async run({ message, args, prefix, cmd }) {
    const t = await target(message, args, prefix, cmd); if (!t) return;
    if (!t.voice.channel) return message.reply(fail('Not in voice', 'That member is not in a voice channel.'));
    const r = await fn(t, message, args); return message.reply(ok(name, r ?? t.user.username));
  } });
// Actions applied to everyone in your channel
const all = (name, desc, perms, fn, usageStr = name) => ({ ...V, name, description: desc, usage: usageStr, perms, botPerms: perms,
  async run({ message, args, prefix, cmd }) {
    const ch = await myVC(message); if (!ch) return;
    const members = [...ch.members.values()].filter((m) => m.id !== message.author.id);
    const r = await fn(members, ch, message, args); if (r === false) return message.reply(usage(cmd, prefix));
    return message.reply(ok(name, `${members.length} member(s) affected.`));
  } });
const chanOp = (name, desc, fn, usageStr = name) => ({ ...V, name, description: desc, usage: usageStr, botPerms: [P.ManageChannels],
  async run({ message, args, prefix, cmd }) {
    const ch = await myVC(message, { owner: true }); if (!ch) return;
    const r = await fn(ch, args, message); if (r === false) return message.reply(usage(cmd, prefix));
    return message.reply(ok(name, r ?? `#${ch.name}`));
  } });

export default [
  all('vcmoveall', 'Move everyone in your channel to another voice channel', [P.MoveMembers], async (ms, ch, message, args) => { const d = voiceChan(message, args[0]); if (!d) return false; for (const m of ms) await m.voice.setChannel(d).catch(() => {}); }, 'vcmoveall <voice channel ID>'),
  one('vcmove', 'Move a member to a voice channel', [P.MoveMembers], async (t, message, args) => { const d = voiceChan(message, args[1]); if (!d) throw new Error('Give a voice channel ID.'); await t.voice.setChannel(d); return `${t.user.username} <:right:1461683867835564201> #${d.name}`; }, 'vcmove <member> <voice channel ID>'),
  { ...V, name: 'vcpull', description: 'Pull a member into your voice channel', usage: 'vcpull <member>', perms: [P.MoveMembers], botPerms: [P.MoveMembers],
    async run({ message, args, prefix, cmd }) { const ch = await myVC(message); if (!ch) return; const t = await target(message, args, prefix, cmd); if (!t) return; if (!t.voice.channel) return message.reply(fail('Not in voice')); await t.voice.setChannel(ch); return message.reply(ok('Pulled', t.user.username)); } },
  all('vcdisconnectall', 'Disconnect everyone else in your channel', [P.MoveMembers], async (ms) => { for (const m of ms) await m.voice.disconnect().catch(() => {}); }),
  one('vckick', 'Disconnect a member from voice', [P.MoveMembers], (t) => t.voice.disconnect()),
  one('vcmute', 'Server-mute a member in voice', [P.MuteMembers], (t) => t.voice.setMute(true)),
  one('vcunmute', 'Server-unmute a member in voice', [P.MuteMembers], (t) => t.voice.setMute(false)),
  one('vcdeafen', 'Server-deafen a member in voice', [P.DeafenMembers], (t) => t.voice.setDeaf(true)),
  one('vcundeafen', 'Server-undeafen a member in voice', [P.DeafenMembers], (t) => t.voice.setDeaf(false)),
  all('vcmuteall', 'Mute everyone else in your channel', [P.MuteMembers], async (ms) => { for (const m of ms) await m.voice.setMute(true).catch(() => {}); }),
  all('vcunmuteall', 'Unmute everyone in your channel', [P.MuteMembers], async (ms) => { for (const m of ms) await m.voice.setMute(false).catch(() => {}); }),
  chanOp('vclock', 'Lock your voice channel', async (ch, a, m) => { await ch.permissionOverwrites.edit(m.guild.id, { Connect: false }); }),
  chanOp('vcunlock', 'Unlock your voice channel', async (ch, a, m) => { await ch.permissionOverwrites.edit(m.guild.id, { Connect: null }); }),
  chanOp('vchide', 'Hide your voice channel', async (ch, a, m) => { await ch.permissionOverwrites.edit(m.guild.id, { ViewChannel: false }); }),
  chanOp('vcunhide', 'Unhide your voice channel', async (ch, a, m) => { await ch.permissionOverwrites.edit(m.guild.id, { ViewChannel: null }); }),
  chanOp('vclimit', 'Set a user limit (0 = none)', async (ch, a) => { const n = parseInt(a[0]); if (isNaN(n) || n < 0 || n > 99) return false; await ch.setUserLimit(n); return n ? `${n} users` : 'No limit'; }, 'vclimit <0-99>'),
  chanOp('vcrename', 'Rename your voice channel', async (ch, a) => { if (!a.length) return false; await ch.setName(a.join(' ').slice(0, 90)); return a.join(' '); }, 'vcrename <name>'),
  chanOp('vcbitrate', 'Set bitrate in kbps', async (ch, a) => { const n = parseInt(a[0]); if (!(n >= 8)) return false; await ch.setBitrate(n * 1000); return `${n} kbps`; }, 'vcbitrate <kbps>'),
  chanOp('vcregion', 'Set voice region (or auto)', async (ch, a) => { if (!a[0]) return false; await ch.setRTCRegion(a[0] === 'auto' ? null : a[0]); return a[0]; }, 'vcregion <region|auto>'),
  { ...V, name: 'vcinfo', description: 'Info about your voice channel', usage: 'vcinfo',
    async run({ message }) { const ch = await myVC(message); if (!ch) return; const t = db.prepare('SELECT owner FROM tempvc WHERE channel=?').get(ch.id);
      return message.reply(card({ title: `<:category_voice:1461683815067156593> ${ch.name}`, fields: [['ID', ch.id], ['Members', ch.members.size], ['Limit', ch.userLimit || 'None'], ['Bitrate', `${ch.bitrate / 1000} kbps`], ['Region', ch.rtcRegion ?? 'Auto'], ['Temp owner', t ? `<@${t.owner}>` : '—']] })); } },
  { ...V, name: 'vcmembers', description: 'Who is in your voice channel', usage: 'vcmembers',
    async run({ message }) { const ch = await myVC(message); if (!ch) return; return message.reply(card({ title: `<:music:1461683725602525318> ${ch.name} (${ch.members.size})`, body: ch.members.map((m) => `<@${m.id}>${m.voice.mute ? ' <:mute:1461684006553784433>' : ''}${m.voice.deaf ? ' 🙉' : ''}`).join('\n') || 'Empty' })); } },
  { ...V, name: 'vclist', description: 'All voice channels with members', usage: 'vclist',
    async run({ message }) { const l = message.guild.channels.cache.filter((c) => c.type === ChannelType.GuildVoice).map((c) => `<:category_voice:1461683815067156593> **${c.name}** — ${c.members.size}`).join('\n');
      return message.reply(card({ title: 'Voice channels', body: clip(l || 'None', 1900) })); } },
  { ...V, name: 'vcban', description: 'Ban a member from your voice channel', usage: 'vcban <member>', botPerms: [P.ManageChannels, P.MoveMembers],
    async run({ message, args, prefix, cmd }) { const ch = await myVC(message, { owner: true }); if (!ch) return; const t = await target(message, args, prefix, cmd); if (!t || t.id === message.author.id) return;
      await ch.permissionOverwrites.edit(t.id, { Connect: false }); if (t.voice.channelId === ch.id) await t.voice.disconnect().catch(() => {}); return message.reply(ok('Banned from channel', t.user.username)); } },
  { ...V, name: 'vcunban', description: 'Unban a member from your voice channel', usage: 'vcunban <member>', botPerms: [P.ManageChannels],
    async run({ message, args, prefix, cmd }) { const ch = await myVC(message, { owner: true }); if (!ch) return; const t = await target(message, args, prefix, cmd); if (!t) return;
      await ch.permissionOverwrites.delete(t.id).catch(() => {}); return message.reply(ok('Unbanned from channel', t.user.username)); } },
  { ...V, name: 'vcowner', description: 'Show the temp channel owner', usage: 'vcowner',
    async run({ message }) { const ch = await myVC(message); if (!ch) return; const t = db.prepare('SELECT owner FROM tempvc WHERE channel=?').get(ch.id);
      return message.reply(t ? card({ title: '<:owner:1461685173799223489> Channel owner', body: `<@${t.owner}>` }) : fail('Not a temp channel')); } },
  { ...V, name: 'vctransfer', description: 'Give your temp channel to someone in it', usage: 'vctransfer <member>', botPerms: [P.ManageChannels],
    async run({ message, args, prefix, cmd }) { const ch = await myVC(message, { owner: true }); if (!ch) return; const t = await target(message, args, prefix, cmd); if (!t) return;
      if (!db.prepare('SELECT 1 FROM tempvc WHERE channel=?').get(ch.id) || t.voice.channelId !== ch.id) return message.reply(fail('Cannot', 'Must be a temp channel and the member must be inside it.'));
      db.prepare('UPDATE tempvc SET owner=? WHERE channel=?').run(t.id, ch.id); await ch.permissionOverwrites.edit(t.id, { ManageChannels: true, MoveMembers: true }); return message.reply(ok('Ownership transferred', t.user.username)); } },
  { ...V, name: 'vcclaim', description: 'Claim a temp channel whose owner left', usage: 'vcclaim', botPerms: [P.ManageChannels],
    async run({ message }) { const ch = await myVC(message); if (!ch) return; const t = db.prepare('SELECT owner FROM tempvc WHERE channel=?').get(ch.id);
      if (!t) return message.reply(fail('Not a temp channel')); if (ch.members.has(t.owner)) return message.reply(fail('Owner is still here'));
      db.prepare('UPDATE tempvc SET owner=? WHERE channel=?').run(message.author.id, ch.id); await ch.permissionOverwrites.edit(message.author.id, { ManageChannels: true, MoveMembers: true }); return message.reply(ok('Channel claimed')); } },
  { ...V, name: 'voicetop', aliases: ['vtop'], description: 'Voice time leaderboard', usage: 'voicetop',
    async run({ message }) { const r = db.prepare('SELECT user, seconds FROM voice_time WHERE guild=? ORDER BY seconds DESC LIMIT 10').all(message.guild.id);
      return message.reply(card({ title: '<:category_voice:1461683815067156593> Voice leaderboard', body: r.map((x, i) => `**${i + 1}.** <@${x.user}> — ${fmtDuration(x.seconds * 1000)}`).join('\n') || 'No data yet.' })); } },
  { ...V, name: 'voicetime', aliases: ['vtime'], description: 'Time spent in voice', usage: 'voicetime [member]',
    async run({ message, args }) { const m = (await getMember(message, args[0])) ?? message.member; const r = db.prepare('SELECT seconds FROM voice_time WHERE guild=? AND user=?').get(message.guild.id, m.id);
      return message.reply(card({ title: `<:category_voice:1461683815067156593> ${m.user.username}`, body: fmtDuration((r?.seconds ?? 0) * 1000) })); } },
  { ...V, name: 'tempvcsetup', description: 'Set the join-to-create lobby channel', usage: 'tempvcsetup <lobby voice ID|off> [category ID]', perms: [P.ManageChannels], botPerms: [P.ManageChannels, P.MoveMembers],
    async run({ message, args, prefix, cmd }) {
      if (args[0] === 'off') { db.prepare('DELETE FROM tempvc_cfg WHERE guild=?').run(message.guild.id); return message.reply(ok('Temp VCs disabled')); }
      const l = voiceChan(message, args[0]); if (!l) return message.reply(usage(cmd, prefix));
      const cat = message.guild.channels.cache.get(idOf(args[1]));
      db.prepare('INSERT OR REPLACE INTO tempvc_cfg(guild,lobby,category) VALUES (?,?,?)').run(message.guild.id, l.id, cat?.type === ChannelType.GuildCategory ? cat.id : null);
      return message.reply(ok('Temp VCs enabled', `Joining **${l.name}** creates a private room.`)); } },
  { ...V, name: 'tempvc', description: 'Show the temp voice setup', usage: 'tempvc',
    async run({ message }) { const c = db.prepare('SELECT * FROM tempvc_cfg WHERE guild=?').get(message.guild.id); return message.reply(c ? card({ title: '<:category_voice:1461683815067156593> Temp VC', fields: [['Lobby', `<#${c.lobby}>`], ['Category', c.category ? `<#${c.category}>` : 'Same as lobby']] }) : fail('Not set up', 'Run `tempvcsetup`.')); } },
];
