import { ChannelType, PermissionFlagsBits as P } from 'discord.js';
import { db, kvGet, kvSet } from '../../core/db.js';
import { card, ok, fail, warn, usage } from '../../core/ui.js';
import { confirm } from '../../core/ptero.js';
import { clip, getRole, getChannel, idOf } from '../../core/util.js';

const A = { category: 'admin', cooldown: 3, perms: [P.ManageGuild] };
const g = (m) => m.guild.id;
const chSet = (name, key, desc, extra = '') => ({ ...A, name, description: desc, usage: `${name} <#channel|off>`, async run({ message, args, prefix, cmd }) {
  const c = args[0] === 'off' ? null : getChannel(message, args[0]); if (args[0] !== 'off' && !c?.isTextBased()) return message.reply(usage(cmd, prefix));
  kvSet(g(message), key, c?.id ?? null); return message.reply(ok(name, c ? `<#${c.id}>${extra}` : 'Disabled'));
} });
const msgSet = (name, key, desc) => ({ ...A, name, description: `${desc} Placeholders: {user} {username} {server} {count}`, usage: `${name} <text|reset>`, async run({ message, args, prefix, cmd }) {
  if (!args.length) return message.reply(usage(cmd, prefix)); kvSet(g(message), key, args[0] === 'reset' ? null : clip(args.join(' '), 500)); return message.reply(ok(name, 'Saved.'));
} });
const roleSet = (name, key, desc) => ({ ...A, name, description: desc, usage: `${name} <@role|off>`, botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
  if (args[0] === 'off') { kvSet(g(message), key, null); return message.reply(ok(name, 'Disabled')); }
  const r = getRole(message, args.join(' ')); if (!r) return message.reply(usage(cmd, prefix)); if (!r.editable) return message.reply(fail('Cannot', 'That role is above my top role.')); kvSet(g(message), key, r.id); return message.reply(ok(name, r.name));
} });
const emojiKey = (s) => { const m = /<a?:\w+:(\d+)>/.exec(s ?? ''); return m ? m[1] : s; };
const protectedRole = (message, r) => message.author.id !== message.guild.ownerId && r.position >= message.member.roles.highest.position;

function snapshot(guild) {
  return {
    roles: guild.roles.cache.filter((r) => !r.managed && r.id !== guild.id).sort((a, b) => a.position - b.position).map((r) => ({ name: r.name, color: r.color, hoist: r.hoist, mentionable: r.mentionable, permissions: r.permissions.bitfield.toString() })),
    channels: guild.channels.cache.filter((c) => !c.isThread()).sort((a, b) => a.rawPosition - b.rawPosition).map((c) => ({ name: c.name, type: c.type, parent: c.parent?.name ?? null, topic: c.topic ?? null, nsfw: c.nsfw ?? false, rate: c.rateLimitPerUser ?? 0, bitrate: c.bitrate ?? null, limit: c.userLimit ?? null })),
  };
}

export default [
  chSet('welcome', 'welcome_ch', 'Set the welcome channel'), msgSet('welcomemsg', 'welcome_msg', 'Set the welcome message.'),
  chSet('leave', 'leave_ch', 'Set the goodbye channel'), msgSet('leavemsg', 'leave_msg', 'Set the goodbye message.'),
  roleSet('autorole', 'autorole', 'Role given to new members'), roleSet('botautorole', 'botautorole', 'Role given to new bots'),
  { ...A, name: 'reactionrole', aliases: ['rradd'], description: 'Create a reaction role', usage: 'reactionrole <messageId> <emoji> <@role>', botPerms: [P.ManageRoles, P.AddReactions], async run({ message, args, prefix, cmd }) {
    const r = getRole(message, args.slice(2).join(' ')), m = args[0] && await message.channel.messages.fetch(args[0]).catch(() => null); if (!m || !args[1] || !r) return message.reply(usage(cmd, prefix));
    if (!r.editable) return message.reply(fail('Cannot', 'That role is above my top role.')); if (protectedRole(message, r)) return message.reply(fail('Cannot', 'That role is above your top role.'));
    await m.react(args[1]).catch(() => null); db.prepare('INSERT OR REPLACE INTO rr VALUES (?,?,?,?)').run(g(message), m.id, emojiKey(args[1]), r.id); return message.reply(ok('Reaction role added', `${args[1]} → ${r.name}`));
  } },
  { ...A, name: 'rrremove', description: 'Remove a reaction role', usage: 'rrremove <messageId> <emoji>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM rr WHERE guild=? AND message=? AND emoji=?').run(g(message), args[0], emojiKey(args[1])); return message.reply(r.changes ? ok('Removed') : fail('Not found'));
  } },
  { ...A, name: 'rrlist', description: 'List reaction roles', usage: 'rrlist', async run({ message }) {
    const r = db.prepare('SELECT * FROM rr WHERE guild=?').all(g(message)); return message.reply(card({ title: '<:autoreact:1461688622485995699> Reaction roles', body: r.map((x) => `\`${x.message}\` ${/^\d+$/.test(x.emoji) ? `<:e:${x.emoji}>` : x.emoji} <:right:1461683867835564201> <@&${x.role}>`).join('\n') || 'None.' }));
  } },
  { ...A, name: 'customcmd', aliases: ['cc'], description: 'Create a custom command (placeholders: {user} {username} {server} {count})', usage: 'customcmd <name> <response>', async run({ client, message, args, prefix, cmd }) {
    const n = args[0]?.toLowerCase(); if (!n || args.length < 2 || n.length > 30) return message.reply(usage(cmd, prefix));
    if (client.commands.has(n) || client.aliases.has(n)) return message.reply(fail('Name taken', 'That is a built-in command.'));
    if (db.prepare("SELECT COUNT(*) c FROM kv WHERE guild=? AND k LIKE 'cc:%'").get(g(message)).c >= 50) return message.reply(fail('Limit reached', 'Max 50 custom commands.'));
    kvSet(g(message), `cc:${n}`, clip(args.slice(1).join(' '), 1500)); return message.reply(ok('Custom command saved', `\`${prefix}${n}\``));
  } },
  { ...A, name: 'delcustomcmd', aliases: ['delcc'], description: 'Delete a custom command', usage: 'delcustomcmd <name>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM kv WHERE guild=? AND k=?').run(g(message), `cc:${(args[0] ?? '').toLowerCase()}`); return message.reply(r.changes ? ok('Deleted') : fail('Not found'));
  } },
  { ...A, name: 'customcmds', description: 'List custom commands', usage: 'customcmds', perms: [], async run({ message }) {
    const r = db.prepare("SELECT k FROM kv WHERE guild=? AND k LIKE 'cc:%'").all(g(message)); return message.reply(card({ title: '📌 Custom commands', body: r.map((x) => `\`${x.k.slice(3)}\``).join(' ') || 'None.' }));
  } },
  { ...A, name: 'autoresponder', aliases: ['autoreply'], description: 'Reply automatically when a message equals a trigger', usage: 'autoresponder <trigger> | <response>', async run({ message, args, prefix, cmd }) {
    const [t, ...r] = args.join(' ').split('|'); const trig = t?.trim().toLowerCase(), resp = r.join('|').trim(); if (!trig || !resp || trig.length > 60) return message.reply(usage(cmd, prefix));
    if (db.prepare("SELECT COUNT(*) c FROM kv WHERE guild=? AND k LIKE 'ar:%'").get(g(message)).c >= 50) return message.reply(fail('Limit reached', 'Max 50 autoresponders.'));
    kvSet(g(message), `ar:${trig}`, clip(resp, 1500)); return message.reply(ok('Autoresponder saved', `"${trig}"`));
  } },
  { ...A, name: 'delresponder', description: 'Delete an autoresponder', usage: 'delresponder <trigger>', async run({ message, args }) {
    const r = db.prepare('DELETE FROM kv WHERE guild=? AND k=?').run(g(message), `ar:${args.join(' ').toLowerCase()}`); return message.reply(r.changes ? ok('Deleted') : fail('Not found'));
  } },
  { ...A, name: 'responders', description: 'List autoresponders', usage: 'responders', perms: [], async run({ message }) {
    const r = db.prepare("SELECT k FROM kv WHERE guild=? AND k LIKE 'ar:%'").all(g(message)); return message.reply(card({ title: '<:channel:1461684716036947999> Autoresponders', body: r.map((x) => `"${clip(x.k.slice(3), 40)}"`).join('\n') || 'None.' }));
  } },
  { ...A, name: 'backup', description: 'Save/list/delete roles & channels backups', usage: 'backup <create [name]|list|delete <id>>', cooldown: 15, async run({ message, args, prefix, cmd }) {
    if (args[0] === 'create') {
      if (db.prepare('SELECT COUNT(*) c FROM backups WHERE guild=?').get(g(message)).c >= 5) return message.reply(fail('Limit reached', 'Max 5 backups. Delete one first.'));
      const id = db.prepare('INSERT INTO backups(guild,name,data,at) VALUES (?,?,?,?)').run(g(message), clip(args.slice(1).join(' ') || 'backup', 40), JSON.stringify(snapshot(message.guild)), Date.now()).lastInsertRowid;
      return message.reply(ok('Backup saved', `ID \`${id}\` — roles and channels (not messages or members).`));
    }
    if (args[0] === 'list') return message.reply(card({ title: '<:backup:1461685239276507330> Backups', body: db.prepare('SELECT id,name,at FROM backups WHERE guild=?').all(g(message)).map((b) => `\`${b.id}\` **${b.name}** — <t:${Math.floor(b.at / 1000)}:R>`).join('\n') || 'None.' }));
    if (args[0] === 'delete') return message.reply(db.prepare('DELETE FROM backups WHERE id=? AND guild=?').run(parseInt(args[1]), g(message)).changes ? ok('Deleted') : fail('Not found'));
    return message.reply(usage(cmd, prefix));
  } },
  { ...A, name: 'restore', description: 'Re-create missing roles/channels from a backup (never deletes anything)', usage: 'restore <backupId>', cooldown: 30, botPerms: [P.ManageRoles, P.ManageChannels], async run({ message, args, prefix, cmd }) {
    if (message.author.id !== message.guild.ownerId) return message.reply(fail('Owner only', 'Only the server owner can restore a backup.'));
    const b = db.prepare('SELECT * FROM backups WHERE id=? AND guild=?').get(parseInt(args[0]), g(message)); if (!b) return message.reply(args[0] ? fail('Backup not found') : usage(cmd, prefix));
    if (!(await confirm(message, `Restore backup **${b.name}**? Missing roles and channels will be re-created. Existing ones are left untouched.`))) return;
    const d = JSON.parse(b.data); let r = 0, c = 0;
    for (const x of d.roles) if (!message.guild.roles.cache.some((y) => y.name === x.name)) { await message.guild.roles.create({ name: x.name, color: x.color, hoist: x.hoist, mentionable: x.mentionable, permissions: BigInt(x.permissions) }).then(() => r++).catch(() => {}); }
    for (const x of d.channels.filter((y) => y.type === ChannelType.GuildCategory)) if (!message.guild.channels.cache.some((y) => y.name === x.name && y.type === x.type)) await message.guild.channels.create({ name: x.name, type: x.type }).then(() => c++).catch(() => {});
    for (const x of d.channels.filter((y) => y.type !== ChannelType.GuildCategory)) if (!message.guild.channels.cache.some((y) => y.name === x.name && y.type === x.type)) {
      const parent = message.guild.channels.cache.find((y) => y.type === ChannelType.GuildCategory && y.name === x.parent);
      await message.guild.channels.create({ name: x.name, type: x.type, parent: parent?.id, topic: x.topic ?? undefined, nsfw: x.nsfw, rateLimitPerUser: x.rate || undefined, bitrate: x.bitrate ?? undefined, userLimit: x.limit ?? undefined }).then(() => c++).catch(() => {});
    }
    return message.channel.send(ok('Restore finished', `${r} role(s) and ${c} channel(s) re-created. Role/channel permissions are not restored.`));
  } },
  { ...A, name: 'nuke', description: 'Clone this channel and delete the original (wipes messages)', usage: 'nuke', perms: [P.ManageChannels], botPerms: [P.ManageChannels], async run({ message }) {
    if (!(await confirm(message, 'Delete ALL messages in this channel by re-creating it?'))) return;
    const c = await message.channel.clone({ reason: `Nuked by ${message.author.tag}` }); await c.setPosition(message.channel.position).catch(() => {}); await message.channel.delete().catch(() => {});
    return c.send(ok('Channel nuked <:nuke:1461684122832339087>', `By <@${message.author.id}>`));
  } },
  { ...A, name: 'createrole', description: 'Create a role', usage: 'createrole <name> [#hex]', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    if (!args.length) return message.reply(usage(cmd, prefix)); const hex = /^#?[0-9a-f]{6}$/i.test(args.at(-1)) ? args.pop() : null; const r = await message.guild.roles.create({ name: args.join(' ').slice(0, 90), color: hex ? (hex.startsWith('#') ? hex : `#${hex}`) : undefined });
    return message.reply(ok('Role created', `<@&${r.id}>`));
  } },
  { ...A, name: 'deleterole', description: 'Delete a role', usage: 'deleterole <@role>', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const r = getRole(message, args.join(' ')); if (!r) return message.reply(usage(cmd, prefix)); if (!r.editable || protectedRole(message, r)) return message.reply(fail('Cannot', 'That role is above you or me.'));
    if (!(await confirm(message, `Delete role **${r.name}**?`))) return; await r.delete(`By ${message.author.tag}`); return message.channel.send(ok('Role deleted', r.name));
  } },
  { ...A, name: 'rolecolor', description: 'Change a role color', usage: 'rolecolor <@role> <#hex>', perms: [P.ManageRoles], botPerms: [P.ManageRoles], async run({ message, args, prefix, cmd }) {
    const hex = args.at(-1), r = getRole(message, args.slice(0, -1).join(' ')); if (!r || !/^#?[0-9a-f]{6}$/i.test(hex ?? '')) return message.reply(usage(cmd, prefix)); if (!r.editable || protectedRole(message, r)) return message.reply(fail('Cannot', 'That role is above you or me.'));
    await r.setColor(hex.startsWith('#') ? hex : `#${hex}`); return message.reply(ok('Role color updated', r.name));
  } },
  { ...A, name: 'roleall', description: 'Give a role to everyone', usage: 'roleall <@role> [humans|bots|all]', perms: [P.Administrator], botPerms: [P.ManageRoles], cooldown: 60, async run({ message, args, prefix, cmd }) {
    const mode = ['humans', 'bots', 'all'].includes(args.at(-1)) ? args.pop() : 'humans', r = getRole(message, args.join(' ')); if (!r) return message.reply(usage(cmd, prefix));
    if (!r.editable || protectedRole(message, r)) return message.reply(fail('Cannot', 'That role is above you or me.'));
    await message.guild.members.fetch(); const list = message.guild.members.cache.filter((m) => !m.roles.cache.has(r.id) && (mode === 'all' || (mode === 'bots') === m.user.bot)); if (list.size > 1000) return message.reply(fail('Too many members', 'Limit is 1000 at once.'));
    if (!(await confirm(message, `Give **${r.name}** to ${list.size} member(s)?`))) return; let n = 0; for (const m of list.values()) { await m.roles.add(r).then(() => n++).catch(() => {}); }
    return message.channel.send(ok('Done', `${n}/${list.size} members received **${r.name}**.`));
  } },
  { ...A, name: 'createchannel', description: 'Create a channel', usage: 'createchannel <name> [text|voice|category]', perms: [P.ManageChannels], botPerms: [P.ManageChannels], async run({ message, args, prefix, cmd }) {
    const t = { text: ChannelType.GuildText, voice: ChannelType.GuildVoice, category: ChannelType.GuildCategory }[args.at(-1)?.toLowerCase()], type = t ?? ChannelType.GuildText; if (t !== undefined) args.pop(); if (!args.length) return message.reply(usage(cmd, prefix));
    const c = await message.guild.channels.create({ name: args.join('-').slice(0, 90), type }); return message.reply(ok('Channel created', `<#${c.id}>`));
  } },
  { ...A, name: 'deletechannel', description: 'Delete a channel', usage: 'deletechannel <#channel>', perms: [P.ManageChannels], botPerms: [P.ManageChannels], async run({ message, args, prefix, cmd }) {
    const c = getChannel(message, args[0]); if (!c) return message.reply(usage(cmd, prefix)); if (!(await confirm(message, `Delete **#${c.name}**? This cannot be undone.`))) return; const same = c.id === message.channel.id; await c.delete(`By ${message.author.tag}`); if (!same) return message.channel.send(ok('Channel deleted', c.name));
  } },
  { ...A, name: 'clonechannel', description: 'Clone a channel', usage: 'clonechannel [#channel]', perms: [P.ManageChannels], botPerms: [P.ManageChannels], async run({ message, args }) {
    const c = getChannel(message, args[0]) ?? message.channel, n = await c.clone(); return message.reply(ok('Channel cloned', `<#${n.id}>`));
  } },
  { ...A, name: 'disablecmd', description: 'Disable a command in this server', usage: 'disablecmd <command>', async run({ client, message, args, prefix, cmd }) {
    const n = client.commands.get(args[0]?.toLowerCase())?.name ?? client.commands.get(client.aliases.get(args[0]?.toLowerCase()))?.name; if (!n) return message.reply(usage(cmd, prefix));
    if (['disablecmd', 'enablecmd', 'help'].includes(n) || client.commands.get(n).category === 'owner') return message.reply(fail('Cannot disable', 'That command is protected.')); kvSet(g(message), `disabled:${n}`, '1'); return message.reply(ok('Command disabled', n));
  } },
  { ...A, name: 'enablecmd', description: 'Re-enable a command', usage: 'enablecmd <command>', async run({ message, args }) { kvSet(g(message), `disabled:${(args[0] ?? '').toLowerCase()}`, null); return message.reply(ok('Command enabled', args[0] ?? '')); } },
  { ...A, name: 'ignorechannel', description: 'Toggle a channel where the bot ignores commands', usage: 'ignorechannel [#channel]', async run({ message, args }) {
    const c = getChannel(message, args[0]) ?? message.channel, on = !kvGet(g(message), `ignore:${c.id}`); kvSet(g(message), `ignore:${c.id}`, on ? '1' : null); return message.reply(ok('Ignored channel', `<#${c.id}> is now ${on ? 'ignored' : 'active'}.`));
  } },
  { ...A, name: 'resetconfig', description: 'Reset this server\'s bot settings (keeps economy/levels/panel link)', usage: 'resetconfig', async run({ message }) {
    if (message.author.id !== message.guild.ownerId) return message.reply(fail('Owner only'));
    if (!(await confirm(message, 'Reset ALL settings (prefix, automod, tickets, welcome, custom commands, etc.)? Economy, levels and the panel link are kept.'))) return;
    for (const t of ['guild', 'am', 'am_words', 'am_links', 'wl', 'sec_cfg', 'level_cfg', 'level_roles', 'ticket_cfg', 'rr', 'extraowners', 'monitor_cfg', 'tempvc_cfg']) db.prepare(`DELETE FROM ${t} WHERE ${t === 'guild' ? 'id' : 'guild'}=?`).run(g(message));
    db.prepare('DELETE FROM kv WHERE guild=?').run(g(message)); return message.channel.send(ok('Settings reset', 'Back to defaults.'));
  } },
];
