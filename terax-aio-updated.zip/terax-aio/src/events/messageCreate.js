import { PermissionsBitField } from 'discord.js';
import { config, isOwner, isAllowed } from '../core/config.js';
import { db, getGuild } from '../core/db.js';
import { card, fail, warn } from '../core/ui.js';
import { handleTicketMessage } from '../core/tickets.js';
import { ts, fmtDuration } from '../core/util.js';
import { kvGet } from '../core/db.js';
import { runCustom } from '../core/custom.js';

function afk(message) {
  const mine = db.prepare('SELECT * FROM afk WHERE guild=? AND user=?').get(message.guild.id, message.author.id);
  if (mine) {
    db.prepare('DELETE FROM afk WHERE guild=? AND user=?').run(message.guild.id, message.author.id);
    message.reply(card({ title: '👋 Welcome back', body: `AFK removed. You were away for ${fmtDuration(Date.now() - mine.at)}.`, color: 'success' })).catch(() => {});
  }
  for (const u of message.mentions.users.values()) {
    const row = db.prepare('SELECT * FROM afk WHERE guild=? AND user=?').get(message.guild.id, u.id);
    if (row) message.reply(card({ title: '<:afk:1461685056136548529> User is AFK', body: `**${u.username}**: ${row.reason}\nSince ${ts(row.at)}` })).catch(() => {});
  }
}

export default {
  name: 'messageCreate',
  async run(client, message) {
    if (message.author.bot || !message.guild || !message.member) return;
    client.seen ??= new Set(); if (client.seen.has(message.id)) return; client.seen.add(message.id); setTimeout(() => client.seen.delete(message.id), 120000);
    if (!isAllowed(message.guild.id)) return;
    const g = getGuild(message.guild.id);
    const prefix = g.prefix || config.prefix;
    afk(message);

    const mention = message.content.match(new RegExp(`^<@!?${client.user.id}>\\s*`));
    let used = message.content.startsWith(prefix) ? prefix : mention?.[0];
    if (used === undefined && config.noPrefixUsers?.includes(message.author.id)) {
      const first = message.content.trim().split(/\s+/)[0]?.toLowerCase();
      if (client.commands.has(first) || client.aliases.has(first)) used = '';
    }
    if (used === undefined) return handleTicketMessage(client, message, g);
    if (kvGet(message.guild.id, `ignore:${message.channel.id}`) && !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return;
    const rest = message.content.slice(used.length).trim();
    if (!rest) {
      if (mention) message.reply(card({ title: '👋 Hey!', body: `My prefix here is \`${prefix}\`. Try \`${prefix}help\`.` }));
      return;
    }
    const args = rest.split(/\s+/);
    const name = args.shift().toLowerCase();
    const cmd = client.commands.get(name) ?? client.commands.get(client.aliases.get(name));
    if (!cmd) return runCustom(message, name);
    if (kvGet(message.guild.id, `disabled:${cmd.name}`) && !isOwner(message.author.id) && !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return;

    const owner = isOwner(message.author.id);
    if (!owner) {
      if (cmd.ownerOnly) return;
      if (db.prepare('SELECT 1 FROM blacklist WHERE id IN (?,?)').get(message.author.id, message.guild.id)) return;
      if (client.maintenance) return message.reply(warn('Maintenance', 'The bot is under maintenance. Please try again later.'));
    }
    if (cmd.perms?.length && !message.member.permissions.has(cmd.perms)) {
      return message.reply(fail('Missing permissions', `You need: ${new PermissionsBitField(cmd.perms).toArray().join(', ')}`));
    }
    if (cmd.botPerms?.length && !message.guild.members.me.permissions.has(cmd.botPerms)) {
      return message.reply(fail('I am missing permissions', `I need: ${new PermissionsBitField(cmd.botPerms).toArray().join(', ')}`));
    }
    const key = `${cmd.name}:${message.author.id}`, now = Date.now(), cd = (cmd.cooldown ?? 3) * 1000;
    if (!owner && (client.cooldowns.get(key) ?? 0) > now) {
      return message.reply(warn('Slow down', `Wait ${((client.cooldowns.get(key) - now) / 1000).toFixed(1)}s before using \`${cmd.name}\` again.`));
    }
    client.cooldowns.set(key, now + cd);
    setTimeout(() => client.cooldowns.delete(key), cd);

    try { await cmd.run({ client, message, args, prefix, cmd, guildRow: g }); }
    catch (e) {
      console.error(`[cmd:${cmd.name}]`, e);
      message.reply(fail('Something went wrong', 'The command failed. Please try again.')).catch(() => {});
    }
  },
};
