// Receives Pterodactyl API keys in DMs (pteroset / pterorotate / pterolink). Keys are validated, encrypted, and never echoed.
import { db } from '../core/db.js';
import { enc } from '../core/crypto.js';
import { api, pending, cfgOf } from '../core/ptero.js';
import { card } from '../core/ui.js';

export default {
  name: 'messageCreate',
  async run(client, message) {
    if (message.guild || message.author.bot) return;
    const p = pending.get(message.author.id);
    if (!p || p.until < Date.now()) { pending.delete(message.author.id); return; }
    const key = message.content.trim().replace(/^(app|client)\s+/i, '');
    const reply = (t, b, c = 'info') => message.reply(card({ title: t, body: b, color: c }));
    try {
      if (key.startsWith('ptla_') && p.mode === 'owner') {
        await api(p.guild, 'app', 'GET', '/nodes?per_page=1', null, key);
        db.prepare('UPDATE ptero_cfg SET app_key=? WHERE guild=?').run(enc(key), p.guild);
        return reply('<:check:1461683648834306130> Application key saved', 'Encrypted and stored. Send a `ptlc_` client key too if you have not yet.', 'success');
      }
      if (key.startsWith('ptlc_')) {
        await api(p.guild, 'client', 'GET', '/?per_page=1', null, key);
        if (p.mode === 'owner') db.prepare('UPDATE ptero_cfg SET client_key=? WHERE guild=?').run(enc(key), p.guild);
        else db.prepare('INSERT OR REPLACE INTO ptero_links(guild,user,client_key) VALUES (?,?,?)').run(p.guild, message.author.id, enc(key));
        pending.delete(message.author.id);
        return reply('<:check:1461683648834306130> Client key saved', p.mode === 'owner' ? 'Encrypted and stored.' : 'Your panel account is linked. Use `pteromyservers`.', 'success');
      }
      return reply('Unrecognized key', p.mode === 'owner' ? 'Send an Application key (`ptla_…`) or a Client key (`ptlc_…`).' : 'Send your Client API key (`ptlc_…`) from Account <:right:1461683867835564201> API Credentials.', 'warning');
    } catch (e) {
      return reply('<:cross:1461683670212542484> Key rejected', `The panel did not accept that key: ${String(e.message).slice(0, 150)}`, 'error');
    }
  },
};
