import { config, isAllowed } from '../core/config.js';
import { startStatus } from '../core/status.js';
import { rejoin247 } from '../core/music.js';
import { startMonitors } from '../core/monitor.js';
import { startScheduler } from '../core/scheduler.js';

export default {
  name: 'clientReady', once: true,
  async run(client) {
    startStatus(client); rejoin247(client).catch(() => {});
    for (const g of client.guilds.cache.values()) {
      if (!isAllowed(g.id)) { console.log(`Leaving unlisted server ${g.name} (${g.id})`); await g.leave().catch(() => {}); }
    }
    startMonitors(client); startScheduler(client);
    console.log(`Online as ${client.user.tag} in ${client.guilds.cache.size} allowed server(s)`);
  },
};
