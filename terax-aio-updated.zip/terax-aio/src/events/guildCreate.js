import { isAllowed } from '../core/config.js';
import { botlog } from '../core/botlog.js';

export default [
  { name: 'guildCreate', async run(client, guild) {
    if (!isAllowed(guild.id)) { console.log(`Blocked join: ${guild.name} (${guild.id})`); botlog(client, '<:blacklist:1461685185027248260> Blocked server', `${guild.name} (\`${guild.id}\`) — not whitelisted, left.`, 'warning'); await guild.leave().catch(() => {}); return; }
    botlog(client, '<:check:1461683648834306130> Joined server', `${guild.name} (\`${guild.id}\`) • ${guild.memberCount} members`, 'success');
  } },
  { name: 'guildDelete', async run(client, guild) { botlog(client, '👋 Left server', `${guild.name ?? 'Unknown'} (\`${guild.id}\`)`, 'warning'); } },
];
