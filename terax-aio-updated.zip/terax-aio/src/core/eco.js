import { db } from './db.js';

export const coin = '<:premium:1461685250034892912>';
export const fmt = (n) => `${coin} ${Number(n).toLocaleString()}`;
export const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
export const pick = (a) => a[Math.floor(Math.random() * a.length)];
export function acct(g, u) {
  db.prepare('INSERT OR IGNORE INTO eco(guild,user) VALUES (?,?)').run(g, u);
  return db.prepare('SELECT * FROM eco WHERE guild=? AND user=?').get(g, u);
}
export function add(g, u, field, n) {
  if (!['wallet', 'bank'].includes(field)) throw new Error('bad field');
  acct(g, u); db.prepare(`UPDATE eco SET ${field}=MAX(0, ${field}+?) WHERE guild=? AND user=?`).run(Math.trunc(n), g, u);
}
// Returns remaining ms if on cooldown, else 0 and starts the cooldown.
export function cooldown(g, u, k, ms) {
  const r = db.prepare('SELECT until FROM eco_cd WHERE guild=? AND user=? AND k=?').get(g, u, k), now = Date.now();
  if (r && r.until > now) return r.until - now;
  db.prepare('INSERT OR REPLACE INTO eco_cd VALUES (?,?,?,?)').run(g, u, k, now + ms); return 0;
}
export function parseAmt(s, max) {
  s = String(s ?? '').toLowerCase();
  if (s === 'all' || s === 'max') return max > 0 ? max : null;
  if (s === 'half') return max > 1 ? Math.floor(max / 2) : null;
  const m = /^(\d+(?:\.\d+)?)([km])?$/.exec(s); if (!m) return null;
  const n = Math.floor(+m[1] * ({ k: 1e3, m: 1e6 }[m[2]] ?? 1)); return n >= 1 ? n : null;
}
export const invAdd = (g, u, item, q) => {
  db.prepare('INSERT INTO inventory(guild,user,item,qty) VALUES (?,?,?,?) ON CONFLICT(guild,user,item) DO UPDATE SET qty=qty+excluded.qty').run(g, u, item, q);
  db.prepare('DELETE FROM inventory WHERE qty<=0').run();
};
export const invQty = (g, u, item) => db.prepare('SELECT qty FROM inventory WHERE guild=? AND user=? AND item=?').get(g, u, item)?.qty ?? 0;
