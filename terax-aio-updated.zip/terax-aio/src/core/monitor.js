import net from 'node:net';
import { db } from './db.js';
import { card } from './ui.js';
import { safeHost } from './netguard.js';
import { isAllowed } from './config.js';
import { ts } from './util.js';

export const tcp = (ip, port, timeout = 5000) => new Promise((res) => {
  const t = Date.now(), s = net.connect({ host: ip, port, timeout });
  s.once('connect', () => { s.destroy(); res({ up: true, ms: Date.now() - t }); });
  s.once('timeout', () => { s.destroy(); res({ up: false, ms: null }); });
  s.once('error', () => res({ up: false, ms: null }));
});
export async function check(m) {
  try {
    if (m.kind === 'tcp') return await tcp((await safeHost(m.host)).ip, m.port);
    await safeHost(new URL(m.host).hostname);
    const t = Date.now(), r = await fetch(m.host, { redirect: 'manual', signal: AbortSignal.timeout(8000) });
    return { up: r.status < 500, ms: Date.now() - t };
  } catch { return { up: false, ms: null }; }
}
async function updateStatus(client, c) {
  const rows = db.prepare('SELECT * FROM monitors WHERE guild=? ORDER BY id').all(c.guild);
  const payload = card({ title: '<:status:1461683996302901515> Status', body: rows.map((m) => `${m.state === 'up' ? '<:enabled:1461688785589895333>' : m.state === 'down' ? '<:disabled:1461688795819937837>' : '⚪'} **${m.name}** — ${m.state}${m.ms ? ` (${m.ms}ms)` : ''}`).join('\n') || 'No monitors yet.', fields: [['Updated', ts(Date.now())]] });
  const ch = await client.channels.fetch(c.status_channel).catch(() => null); if (!ch) return;
  const msg = c.status_message && await ch.messages.fetch(c.status_message).catch(() => null);
  if (msg) return msg.edit(payload).catch(() => {});
  const sent = await ch.send(payload).catch(() => null);
  if (sent) db.prepare('UPDATE monitor_cfg SET status_message=? WHERE guild=?').run(sent.id, c.guild);
}
export function startMonitors(client) {
  const tick = async () => {
    const rows = db.prepare('SELECT * FROM monitors').all().filter((m) => isAllowed(m.guild));
    await Promise.all(rows.map(async (m) => {
      const r = await check(m), state = r.up ? 'up' : 'down';
      if (state === m.state) return db.prepare('UPDATE monitors SET ms=? WHERE id=?').run(r.ms, m.id);
      db.prepare('UPDATE monitors SET state=?, since=?, ms=? WHERE id=?').run(state, Date.now(), r.ms, m.id);
      const cfg = db.prepare('SELECT alert_channel FROM monitor_cfg WHERE guild=?').get(m.guild);
      if (m.state !== 'unknown' && cfg?.alert_channel) {
        const ch = await client.channels.fetch(cfg.alert_channel).catch(() => null);
        ch?.send(card({ title: state === 'up' ? `<:enabled:1461688785589895333> ${m.name} is back up` : `<:disabled:1461688795819937837> ${m.name} is DOWN`, body: m.kind === 'tcp' ? `${m.host}:${m.port}` : m.host, color: state === 'up' ? 'success' : 'error' })).catch(() => {});
      }
    }));
    for (const c of db.prepare('SELECT * FROM monitor_cfg WHERE status_channel IS NOT NULL').all()) if (isAllowed(c.guild)) await updateStatus(client, c);
  };
  setInterval(() => tick().catch((e) => console.error('[monitor]', e)), 60000);
}
