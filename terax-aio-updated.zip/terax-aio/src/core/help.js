import { ActionRowBuilder, StringSelectMenuBuilder } from 'discord.js';
import { card } from './ui.js';
import { clip } from './util.js';

export const CAT = {
  owner: ['<:owner:1461685173799223489>', 'Owner'], admin: ['⚙️', 'Admin'], moderation: ['<:category_moderation:1461683846990004296>', 'Moderation'], ticket: ['<:category_ticket:1461683804463825067>', 'Tickets'],
  ai: ['<:aerox:1461688862874009682>', 'AI'], info: ['<:category_info:1461683836298596464>', 'Info'], hosting: ['<:server:1461685023857053717>', 'Hosting & Pterodactyl'], voice: ['<:category_voice:1461683815067156593>', 'Voice'], economy: ['<:premium:1461685250034892912>', 'Economy'], leveling: ['<:star:1461684992026611917>', 'Leveling'], fun: ['<:category_fun:1461683746586759280>', 'Fun & Games'], security: ['<:lock:1461684070600802314>', 'Automod & Security'], community: ['<:category_giveaway:1461683825863299194>', 'Community'], utility: ['<:category_utility:1461683857039425610>', 'Utility'],
};
export function categories(client, showOwner) {
  const out = {};
  for (const c of client.commands.values()) {
    if (c.category === 'owner' && !showOwner) continue;
    (out[c.category] ??= []).push(c);
  }
  return out;
}
const menu = (cats) => new ActionRowBuilder().addComponents(
  new StringSelectMenuBuilder().setCustomId('help:menu').setPlaceholder('Choose a category')
    .addOptions(Object.keys(cats).map((k) => ({ label: CAT[k]?.[1] ?? k, value: k, emoji: CAT[k]?.[0] ?? '<:folder:1461683703120924826>', description: `${cats[k].length} commands` }))));

export function helpHome(client, prefix, showOwner) {
  const cats = categories(client, showOwner);
  const total = Object.values(cats).flat().length;
  return card({
    title: '<:list:1461683931546910917> Help', body: `Prefix: \`${prefix}\` • **${total}** commands\nUse \`${prefix}help <command>\` for details, or pick a category below.`,
    fields: Object.entries(cats).map(([k, v]) => [`${CAT[k]?.[0] ?? '<:folder:1461683703120924826>'} ${CAT[k]?.[1] ?? k}`, `${v.length} commands`]),
    rows: [menu(cats)],
  });
}
export function helpCategory(client, key, prefix, showOwner) {
  const cats = categories(client, showOwner);
  const list = (cats[key] ?? []).map((c) => `\`${c.name}\``).join(' ');
  return card({ title: `${CAT[key]?.[0] ?? '<:folder:1461683703120924826>'} ${CAT[key]?.[1] ?? key}`, body: clip(list || 'Nothing here.', 2000) + `\n\n-# ${prefix}help <command> for details`, rows: [menu(cats)] });
}
