import { db } from './db.js';
import { card } from './ui.js';

export const need = (L) => 5 * L * L + 50 * L + 100;
export function lcfg(g) {
  db.prepare('INSERT OR IGNORE INTO level_cfg(guild) VALUES (?)').run(g);
  return db.prepare('SELECT * FROM level_cfg WHERE guild=?').get(g);
}
export const lrow = (g, u) => {
  db.prepare('INSERT OR IGNORE INTO levels(guild,user) VALUES (?,?)').run(g, u);
  return db.prepare('SELECT * FROM levels WHERE guild=? AND user=?').get(g, u);
};
export async function grantRoles(guild, userId, lvl) {
  const roles = db.prepare('SELECT role FROM level_roles WHERE guild=? AND level<=?').all(guild.id, lvl);
  if (!roles.length) return;
  const m = await guild.members.fetch(userId).catch(() => null);
  for (const r of roles) if (m && !m.roles.cache.has(r.role)) await m.roles.add(r.role).catch(() => {});
}
export async function addXp(client, guildId, userId, amount, channel) {
  const cfg = lcfg(guildId), mult = cfg.multiplier * (cfg.boost_until > Date.now() ? cfg.boost_mult : 1);
  const row = lrow(guildId, userId);
  let xp = row.xp + Math.round(amount * mult), lvl = row.level, up = false;
  while (xp >= need(lvl)) { xp -= need(lvl); lvl++; up = true; }
  db.prepare('UPDATE levels SET xp=?, level=? WHERE guild=? AND user=?').run(xp, lvl, guildId, userId);
  if (!up) return;
  const guild = client.guilds.cache.get(guildId); if (!guild) return;
  await grantRoles(guild, userId, lvl);
  if (!cfg.announce) return;
  const ch = (cfg.channel && guild.channels.cache.get(cfg.channel)) || channel; if (!ch?.isTextBased()) return;
  const text = (cfg.msg || '<a:tada:1461683974542725303> {user} reached **level {level}**!').replace('{user}', `<@${userId}>`).replace('{level}', lvl);
  ch.send({ ...card({ title: '⬆️ Level up', body: text, color: 'success' }), allowedMentions: { users: [userId] } }).catch(() => {});
}
