// DM policy: nothing is DM-only. If we DM, we ALSO post a short, non-sensitive notice in chat.
import { card } from './ui.js';

export async function tryDM(user, payload) {
  try { await user.send(payload); return true; } catch { return false; }
}
export async function dmWithNotice(message, user, payload, notice = 'I sent you a DM.') {
  const sent = await tryDM(user, payload);
  await message.channel.send(sent
    ? card({ title: '<:ticketOpen:1461684807837945938> Check your DMs', body: notice, color: 'info' })
    : card({ title: '<:ticketClose:1461684818655055894> Could not DM you', body: 'Your DMs look closed. Open them and run the command again.', color: 'warning' }));
  return sent;
}
