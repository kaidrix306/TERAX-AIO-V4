import { db, kvGet, kvSet } from './db.js';
import { closeTicket } from './tickets.js';
import { card } from './ui.js';
import { isAllowed } from './config.js';

export async function endGiveaway(client, id) {
  const g = db.prepare('SELECT * FROM giveaways WHERE id=?').get(id);
  if (!g) return null;
  const users = db.prepare('SELECT user FROM gw_entries WHERE gid=?').all(id).map((r) => r.user);
  const winners = [...users].sort(() => Math.random() - 0.5).slice(0, g.winners);
  db.prepare('UPDATE giveaways SET ended=1 WHERE id=?').run(id);
  const ch = await client.channels.fetch(g.channel).catch(() => null);
  if (ch) {
    const list = winners.map((w) => `<@${w}>`).join(', ');
    const msg = await ch.messages.fetch(g.message).catch(() => null);
    await msg?.edit(card({ title: `<a:tada:1461683974542725303> ${g.prize}`, body: winners.length ? `Winner(s): ${list}` : 'No valid entries.', fields: [['Hosted by', `<@${g.host}>`], ['Entries', users.length]], color: 'success' })).catch(() => {});
    await ch.send({ ...card({ title: '<a:tada:1461683974542725303> Giveaway ended', body: winners.length ? `Congratulations ${list}! You won **${g.prize}**.` : `No one entered **${g.prize}**.`, color: 'success' }), allowedMentions: { users: winners } }).catch(() => {});
  }
  return winners;
}
async function autoClose(client) {
  for (const t of db.prepare("SELECT * FROM tickets WHERE status='open'").all()) {
    if (!isAllowed(t.guild)) continue;
    const hrs = +(kvGet(t.guild, 'tk_autoclose') || 0); if (!hrs) continue;
    const ch = await client.channels.fetch(t.channel).catch(() => null);
    if (!ch) { db.prepare("UPDATE tickets SET status='closed' WHERE channel=?").run(t.channel); continue; }
    const limit = hrs * 36e5, w = kvGet(t.guild, `tkwarn:${t.channel}`);
    if (w) { const [mid, at] = w.split(':'); if (ch.lastMessageId !== mid) kvSet(t.guild, `tkwarn:${t.channel}`, null); else if (Date.now() - +at >= limit * 0.25) await closeTicket(ch, client.user, `Auto-closed after ${hrs}h of inactivity`); continue; }
    const last = ch.lastMessageId ? Number((BigInt(ch.lastMessageId) >> 22n) + 1420070400000n) : t.created;
    if (Date.now() - last >= limit * 0.75) {
      const m = await ch.send({ ...card({ title: '<:timer:1461683899972321300> Inactive ticket', body: `<@${t.owner}>, this ticket will close automatically if nobody replies.`, color: 'warning' }), allowedMentions: { users: [t.owner] } }).catch(() => null);
      if (m) kvSet(t.guild, `tkwarn:${t.channel}`, `${m.id}:${Date.now()}`);
    }
  }
}
let ticks = 0;
export function startScheduler(client) {
  setInterval(async () => {
    try {
      const now = Date.now();
      if (++ticks % 40 === 0) await autoClose(client);
      for (const g of db.prepare('SELECT id, guild FROM giveaways WHERE ended=0 AND ends<=?').all(now)) if (isAllowed(g.guild)) await endGiveaway(client, g.id);
      for (const t of db.prepare('SELECT * FROM tempbans WHERE until<=?').all(now)) {
        db.prepare('DELETE FROM tempbans WHERE guild=? AND user=?').run(t.guild, t.user);
        if (isAllowed(t.guild)) await client.guilds.cache.get(t.guild)?.members.unban(t.user, 'Tempban expired').catch(() => {});
      }
      for (const r of db.prepare('SELECT * FROM reminders WHERE at<=?').all(now)) {
        db.prepare('DELETE FROM reminders WHERE id=?').run(r.id);
        const ch = await client.channels.fetch(r.channel).catch(() => null);
        ch?.send({ ...card({ title: '<:remind:1461684133737791663> Reminder', body: `<@${r.user}> ${r.text}` }), allowedMentions: { users: [r.user] } }).catch(() => {});
      }
    } catch (e) { console.error('[scheduler]', e); }
  }, 15000);
}
