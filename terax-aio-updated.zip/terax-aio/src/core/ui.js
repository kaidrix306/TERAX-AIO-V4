// Components V2 helpers: every bot reply is built from these cards.
import {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  SectionBuilder, ThumbnailBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder, MessageFlags,
} from 'discord.js';
import { config } from './config.js';
import { clip } from './util.js';

const PALETTE = { info: '#010101', mod: '#010101', warning: '#D3D3D3', success: '#00FF00', error: '#FF0000' };
const hex = (c) => parseInt(String(PALETTE[c] ?? PALETTE.info).replace('#', ''), 16);
export const footerText = () => `-# ${config.branding.owner} • Lead Dev: ${config.branding.leadDev}`;
const txt = (s) => new TextDisplayBuilder().setContent(String(s));
const sep = (divider = true) => new SeparatorBuilder().setDivider(divider).setSpacing(SeparatorSpacingSize.Small);

// NOTE: Discord caps total text in one V2 message at 4000 chars, so body/fields are clipped.
export function card({ title, body, fields, color = 'info', thumb, image, rows = [], foot = true, mentions } = {}) {
  const c = new ContainerBuilder().setAccentColor(hex(color));
  const head = txt(`## ${clip(title, 120)}${body ? `\n${clip(body, 2200)}` : ''}`);
  if (thumb) {
    c.addSectionComponents(new SectionBuilder().addTextDisplayComponents(head)
      .setThumbnailAccessory(new ThumbnailBuilder({ media: { url: thumb } })));
  } else c.addTextDisplayComponents(head);
  if (fields?.length) {
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(clip(fields.map(([k, v]) => `**${k}:** ${v}`).join('\n'), 1300)));
  }
  if (image) c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(image)));
  for (const r of rows) c.addActionRowComponents(r);
  if (foot) { c.addSeparatorComponents(sep(false)); c.addTextDisplayComponents(txt(footerText())); }
  return { components: [c], flags: MessageFlags.IsComponentsV2, allowedMentions: mentions ?? { parse: [] } };
}
export const ok = (title, body, extra = {}) => card({ title: `<:check:1461683648834306130> ${title}`, body, color: 'success', ...extra });
export const fail = (title, body, extra = {}) => card({ title: `<:cross:1461683670212542484> ${title}`, body, color: 'error', ...extra });
export const warn = (title, body, extra = {}) => card({ title: `<:warn:1461684027206664330> ${title}`, body, color: 'warning', ...extra });
export const usage = (cmd, prefix) => fail('Invalid usage', `Usage: \`${prefix}${cmd.usage || cmd.name}\``);
export const eph = (p) => ({ ...p, flags: p.flags | MessageFlags.Ephemeral });
